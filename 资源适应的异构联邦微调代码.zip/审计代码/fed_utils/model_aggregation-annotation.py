# 此代码用于学习研究具体是如何实现LoRA矩阵聚合的
# 包含尽可能详细的注释

from peft import (
    set_peft_model_state_dict,
)
import torch
import os
from torch.nn.functional import normalize
from torch.nn import ZeroPad2d

def FedAvg(model, selected_clients_set, output_dir, local_dataset_len_dict, epoch, stacking, lora_r, heter, local_ranks, zero_padding, full):
    """
    selected_clients_set：要聚合的客户端集合
    local_ranks：记录所有客户端的LoRA秩
    """
    # 根据客户端的数据量，计算其在聚合中的权重比例
    weights_array = normalize(
        torch.tensor([local_dataset_len_dict[client_id] for client_id in selected_clients_set],
                     dtype=torch.float32),
        p=1, dim=0)
    print("Weights:", weights_array)

    # 遍历每个选中的客户端，加载对应的本地模型权重文件
    for k, client_id in enumerate(selected_clients_set):
        # 拼接出权重的路径
        single_output_dir = os.path.join(output_dir, str(epoch), "local_output_{}".format(client_id),
                                         "pytorch_model.bin")
        # 加载路径，存放与CPU，因为使用CPU实现这个聚合
        single_weights = torch.load(single_output_dir, map_location = 'cpu')

        x = 0       # 似乎是一个flag

        # 【重要】其中 weighted_single_weights 是一个关键变量，作为一个权重副本用于执行参数的加权平均
        # 【重要】weighted_single_weights本质为字典

        # 如果是全微调（非LoRA），直接将参数加权平均
        if full:
            # 第一个客户端权重先乘上比例赋值给 weighted_single_weights ，后续客户端权重依次累加。
            if k == 0:
                weighted_single_weights = single_weights
                for key in weighted_single_weights.keys():
                    weighted_single_weights[key] = weighted_single_weights[key] * (weights_array[k])
            else:
                for key in single_weights.keys():
                    weighted_single_weights[key] += single_weights[key] * (weights_array[k])

        else:       # 其他情况
            if stacking:        # 堆叠
                if zero_padding:    # 堆叠 + 零填充
                    max_lora = max(local_ranks)
                    if k == 0:      # 第一个客户端
                        weighted_single_weights = single_weights
                        for key in weighted_single_weights.keys():
                            # 通过查询每一层的矩阵大小， 看其是否为Rank的大小，来判断是否为LoRA矩阵
                            # 确认QV矩阵后，则对这个层的权重进行加权平均
                            # 而其他参数层则不进行改动。
                            # 例如此处，维度0为Rank大小，那么可能是Q矩阵
                            if single_weights[key].shape[0] == local_ranks[client_id]:
                                # 下侧补零
                                # 其中 pad 本质上是一个函数，可被调用来为权重矩阵补零
                                pad = ZeroPad2d(padding=(0, 0, 0, max_lora-local_ranks[client_id]))
                                weighted_single_weights[key] = pad(weighted_single_weights[key]) * (weights_array[k])
                            # 例如此处，维度1为Rank大小，那么可能是V矩阵
                            elif single_weights[key].shape[1] == local_ranks[client_id]:
                                # 右侧补零
                                pad = ZeroPad2d(padding=(0, max_lora-local_ranks[client_id], 0, 0))
                                weighted_single_weights[key] = pad(weighted_single_weights[key]) * (weights_array[k])
                    else:
                        for key in single_weights.keys():
                            #print(single_weights[key].shape)
                            if single_weights[key].shape[0] == local_ranks[client_id]:
                                pad = ZeroPad2d(padding=(0, 0, 0, max_lora-local_ranks[client_id]))
                                single_weights[key] = pad(single_weights[key]) * (weights_array[k])
                                weighted_single_weights[key] += single_weights[key]
                            elif single_weights[key].shape[1] == local_ranks[client_id]:
                                pad = ZeroPad2d(padding=(0, max_lora-local_ranks[client_id], 0, 0))
                                single_weights[key] = pad(single_weights[key]) * (weights_array[k])
                                #print(single_weights[key][255,32])
                                weighted_single_weights[key] += single_weights[key]
                        
                else:       # 堆叠 + 不使用0填充
                    if k == 0:
                        weighted_single_weights = single_weights
                        for key in weighted_single_weights.keys():
                            #weighted_single_weights[key] = weighted_single_weights[key] * (weights_array[k])
                            #print(weighted_single_weights[key].shape)
                            if heter:       # 堆叠 + 异构
                                x += 1
                                if weighted_single_weights[key].shape[0] == local_ranks[client_id]:
                                    weighted_single_weights[key] = weighted_single_weights[key] * (weights_array[k] * 1)
                            else:       # 堆叠 + 同构
                                if weighted_single_weights[key].shape[0] == lora_r:
                                    weighted_single_weights[key] = weighted_single_weights[key] * (weights_array[k] * 1)

                    else:
                        for key in single_weights.keys():
                            # 堆叠 + 异构
                            # 对于Q矩阵
                            if heter:
                                x += 1
                                if single_weights[key].shape[0] == local_ranks[client_id]:
                                    # 只需要在Q矩阵或V矩阵当中的一个添加加权因子即可，否则将重复加权
                                    new = [weighted_single_weights[key], single_weights[key] * (weights_array[k]) * 1]
                                    weighted_single_weights[key] = torch.cat(new, dim=0)        # 沿着维度0进行拼接（例如横向）
                            else:
                                if single_weights[key].shape[0] == lora_r:
                                    new = [weighted_single_weights[key], single_weights[key] * (weights_array[k]) * 1]
                                    weighted_single_weights[key] = torch.cat(new, dim=0)
                            # 对于V矩阵
                            if heter:
                                if single_weights[key].shape[1] == local_ranks[client_id]:
                                    # 只需要在Q矩阵或V矩阵当中的一个添加加权因子即可，否则将重复加权
                                    new = [weighted_single_weights[key], single_weights[key]]#  * (weights_array[k])]
                                    weighted_single_weights[key] = torch.cat(new, dim=1)        # 沿着维度1进行拼接（例如纵向）
                            else:
                                if single_weights[key].shape[1] == lora_r:
                                    new = [weighted_single_weights[key], single_weights[key]]#  * (weights_array[k])]
                                    weighted_single_weights[key] = torch.cat(new, dim=1)

            else:       # 不堆叠
                if zero_padding:
                    max_lora = max(local_ranks)
                    if k == 0:
                        weighted_single_weights = single_weights
                        for key in weighted_single_weights.keys():
                            if single_weights[key].shape[0] == local_ranks[client_id]:
                                pad = ZeroPad2d(padding=(0, 0, 0, max_lora-local_ranks[client_id]))
                                weighted_single_weights[key] = pad(weighted_single_weights[key]) * (weights_array[k])
                            elif single_weights[key].shape[1] == local_ranks[client_id]:
                                pad = ZeroPad2d(padding=(0, max_lora-local_ranks[client_id], 0, 0))
                                weighted_single_weights[key] = pad(weighted_single_weights[key]) * (weights_array[k])
                    else:
                        for key in single_weights.keys():
                            #print(single_weights[key].shape)
                            if single_weights[key].shape[0] == local_ranks[client_id]:
                                pad = ZeroPad2d(padding=(0, 0, 0, max_lora-local_ranks[client_id]))
                                single_weights[key] = pad(single_weights[key]) * (weights_array[k])
                                weighted_single_weights[key] += single_weights[key]
                            elif single_weights[key].shape[1] == local_ranks[client_id]:
                                pad = ZeroPad2d(padding=(0, max_lora-local_ranks[client_id], 0, 0))
                                single_weights[key] = pad(single_weights[key]) * (weights_array[k])
                                #print(single_weights[key][255,32])
                                weighted_single_weights[key] += single_weights[key]
                else:
                    if k == 0:
                        weighted_single_weights = {key: single_weights[key] * (weights_array[k]) for key in
                                            single_weights.keys()}
                    else:
                        weighted_sindgle_weights = {key: weighted_single_weights[key] + single_weights[key] * (weights_array[k])
                                            for key in
                                            single_weights.keys()}


    # 堆叠，则返回包含LoRA矩阵的全部模型参数
    if stacking:
        torch.save(weighted_single_weights, os.path.join(output_dir, str(epoch), "adapter_model.bin"))
        return model
    # 全微调，则返回聚合后全部原始模型的参数，无LoRA
    elif full:
        torch.save(weighted_single_weights, os.path.join(output_dir, str(epoch), "pytorch_model.bin"))
        model.load_state_dict(weighted_single_weights)
        return model
    # 使用LoRA且不堆叠，不保存而是直接更新模型的LoRA适配器参数
    else:
        set_peft_model_state_dict(model, weighted_single_weights, "default")
        return model
