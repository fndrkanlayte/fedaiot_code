"""
Configuration file for the multi-modal semantic communication task offloading system
修改：使用Udacity数据集和IoU指标
"""
import torch

class Config:
    # Device configuration
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # MADDPG parameters (优化以提高收敛性)
    MADDPG = {
        'actor_lr': 1e-4,
        'critic_lr': 3e-4,
        'gamma': 0.99,
        'tau': 0.005,  # 0.01 → 0.005 (更慢的目标网络更新)
        'buffer_size': 100000,
        'batch_size': 256,
        'update_frequency': 2,
        'noise_std': 0.2,
        'noise_decay': 0.999,  # 0.999 → 0.9998
        'min_noise': 0.05,
        'action_dim': 6,
        'max_steps': 20
    }

    # Diffusion model parameters
    DIFFUSION = {
        'num_timesteps': 1000,
        'beta_start': 0.0001,
        'beta_end': 0.02,
        'beta_schedule': 'linear',
        'prediction_type': 'epsilon',
        'loss_type': 'mse'
    }

    # Semantic communication parameters
    SEMANTIC = {
        'text_embedding_dim': 768,
        'image_embedding_dim': 512,
        'semantic_dim': 256,
        'compression_ratio': 0.1,
        'channel_noise_std': 0.1,
        'min_compression_rate': 0.1,
        'max_compression_rate': 0.5,
        'initial_snr_db': 20.0,
    }

    # Resource allocation parameters
    RESOURCE = {
        'min_compute_allocation': 0.3,
        'max_compute_allocation': 1.0,
        'min_comm_allocation': 0.3,
        'max_comm_allocation': 1.0,
        'base_compute_capacity': 100,
        'base_comm_capacity': 10,
    }

    # Vehicle network parameters
    VEHICLE = {
        'num_vehicles': 5,
        'num_edge_servers': 3,
        'communication_range': 200,
        'max_velocity': 30,
        'task_arrival_rate': 0.1,
        'max_task_size': 10,
        'computation_capacity': 1000,
        'energy_capacity': 100,
    }

    # Reward function weights
    REWARD = {
        'text_similarity_weight': 2.0,
        'image_similarity_weight': 2.0,
        'nli_accuracy_weight': 2.0,
        'detection_iou_weight': 2.0,  # ✨ 使用IoU替代分类精度
        'time_weight': 0.5,
        'energy_weight': 0.5,
        'compression_weight': 1.0,
    }

    # Training parameters
    TRAINING = {
        'num_episodes': 1000,
        'max_steps_per_episode': 20,
        'warmup_steps': 2000,
        'save_frequency': 25,
        'eval_frequency': 25,
        'log_frequency': 1,
    }

    # Dataset parameters - ✨ 修改为Udacity
    DATASET = {
        'text_dataset': 'snli',
        'image_dataset': 'udacity_detection',  # ✨ 从cifar10改为udacity
        'max_text_length': 128,
        'image_size': 256,  # ✨ 从32改为256
        'num_classes': 3,
        'num_image_classes': 5,  # ✨ 从10改为5（Udacity类别数）
        'auto_download': True,
        'use_subset': True,
        'subset_size': 5000,
        'min_box_size': 20,  # ✨ 新增：最小边界框尺寸
    }

    # Evaluation metrics - ✨ 启用IoU评估
    EVALUATION = {
        'enable_text_similarity': True,
        'enable_nli_accuracy': True,
        'enable_image_similarity': True,
        'enable_detection_iou': True,  # ✨ 从enable_classification_accuracy改为enable_detection_iou
        'text_similarity_model': 'bert-base-uncased',
        'nli_model': 'roberta-large-mnli',
        'image_similarity_model': 'ssim',  # ✨ 从clip改为ssim
        'detection_iou_threshold': 0.5,  # ✨ 新增：IoU阈值
        'similarity_threshold': 0.7,
        'accuracy_threshold': 0.8,
    }

    # Paths
    PATHS = {
        'data_dir': './data',
        'model_dir': './models',
        'log_dir': './logs',
        'result_dir': './results'
    }

    # Ablation study settings
    ABLATION = {
        'disable_modality_conversion': False,
        'disable_semantic_compression': False,
        'disable_diffusion_recovery': False,
        'disable_pretrained_enhancement': False,
    }