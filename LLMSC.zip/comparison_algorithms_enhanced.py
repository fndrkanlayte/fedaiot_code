# -*- coding: utf-8 -*-
"""
comparison_algorithms_enhanced.py
统一所有对比算法的参数来源与训练范式，使其与 run_enhanced_system.py/Config 保持一致。
包含：DDPG / SAC / MADDPG / MAPPO 及对应的 NoSemantic* 版本（仅关闭语义特征的使用标志）。
"""
from __future__ import annotations

import math
import random
from collections import deque
from typing import Deque, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# 统一配置来源
try:
    from config import Config
except Exception:
    # 兜底：若外部未提供Config，给出一个最小可用的默认配置
    class Config:  # type: ignore
        def __init__(self):
            self.MADDPG = dict(
                actor_lr=3e-4, critic_lr=3e-4, gamma=0.99, tau=0.005,
                buffer_size=100000, batch_size=32,
                noise_std=0.2, noise_decay=0.999, min_noise=0.05
            )
            self.TRAINING = dict(
                max_episodes=30, max_steps_per_episode=128
            )

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# -------------------------
# 通用模块
# -------------------------
class ReplayBuffer:
    def __init__(self, capacity: int, state_dim: int, action_dim: int):
        self.capacity = int(capacity)
        self.ptr = 0
        self.full = False
        self.state = np.zeros((self.capacity, state_dim), dtype=np.float32)
        self.action = np.zeros((self.capacity, action_dim), dtype=np.float32)
        self.reward = np.zeros((self.capacity, 1), dtype=np.float32)
        self.next_state = np.zeros((self.capacity, state_dim), dtype=np.float32)
        self.done = np.zeros((self.capacity, 1), dtype=np.float32)

    def add(self, s, a, r, s2, d):
        idx = self.ptr
        self.state[idx] = s
        self.action[idx] = a
        self.reward[idx] = r
        self.next_state[idx] = s2
        self.done[idx] = d
        self.ptr = (self.ptr + 1) % self.capacity
        if self.ptr == 0:
            self.full = True

    def sample(self, batch_size: int):
        size = self.capacity if self.full else self.ptr
        batch = np.random.randint(0, size, size=batch_size)
        s = torch.tensor(self.state[batch]).to(DEVICE)
        a = torch.tensor(self.action[batch]).to(DEVICE)
        r = torch.tensor(self.reward[batch]).to(DEVICE)
        ns = torch.tensor(self.next_state[batch]).to(DEVICE)
        d = torch.tensor(self.done[batch]).to(DEVICE)
        return s, a, r, ns, d

    def __len__(self):
        return self.capacity if self.full else self.ptr


def mlp(in_dim: int, out_dim: int, hidden: int = 256, out_act: Optional[nn.Module] = None) -> nn.Module:
    layers = [
        nn.Linear(in_dim, hidden), nn.ReLU(inplace=True),
        nn.Linear(hidden, hidden), nn.ReLU(inplace=True),
        nn.Linear(hidden, out_dim),
    ]
    net = nn.Sequential(*layers)
    if out_act is not None:
        net.add_module("out_act", out_act)
    return net


# -------------------------
# DDPG
# -------------------------
class DDPG:
    """DDPG（含语义通信标志），参数默认来自 Config().MADDPG"""

    def __init__(self,
                 state_dim: int,
                 action_dim: int = 6,
                 lr_actor: Optional[float] = None,
                 lr_critic: Optional[float] = None,
                 gamma: Optional[float] = None,
                 tau: Optional[float] = None,
                 buffer_size: Optional[int] = None,
                 batch_size: Optional[int] = None,
                 hidden_dim: int = 256,
                 config: Optional[Config] = None,
                 use_semantic: bool = True):
        cfg = (config.MADDPG if config is not None else Config().MADDPG)
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.gamma = float(gamma if gamma is not None else cfg["gamma"])
        self.tau = float(tau if tau is not None else cfg["tau"])
        self.batch_size = int(batch_size if batch_size is not None else cfg["batch_size"])
        self.use_semantic = use_semantic

        self.actor = mlp(self.state_dim, self.action_dim, hidden_dim, out_act=nn.Tanh()).to(DEVICE)
        self.actor_target = mlp(self.state_dim, self.action_dim, hidden_dim, out_act=nn.Tanh()).to(DEVICE)
        self.critic = mlp(self.state_dim + self.action_dim, 1, hidden_dim).to(DEVICE)
        self.critic_target = mlp(self.state_dim + self.action_dim, 1, hidden_dim).to(DEVICE)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

        self.actor_opt = torch.optim.Adam(self.actor.parameters(),
                                          lr=(lr_actor if lr_actor is not None else cfg["actor_lr"]))
        self.critic_opt = torch.optim.Adam(self.critic.parameters(),
                                           lr=(lr_critic if lr_critic is not None else cfg["critic_lr"]))

        self.buffer = ReplayBuffer(
            capacity=int(buffer_size if buffer_size is not None else cfg["buffer_size"]),
            state_dim=self.state_dim, action_dim=self.action_dim
        )

        # 探索噪声策略
        self.noise_scale = float(cfg.get("noise_std", 0.2))
        self.noise_decay = float(cfg.get("noise_decay", 0.999))
        self.min_noise = float(cfg.get("min_noise", 0.05))
        self.update_counter = 0

    @torch.no_grad()
    def select_action(self, state: np.ndarray) -> np.ndarray:
        state_t = torch.tensor(state, dtype=torch.float32, device=DEVICE).unsqueeze(0)
        action = self.actor(state_t).squeeze(0).cpu().numpy()
        # 加噪声探索
        noise = np.random.normal(0.0, self.noise_scale, size=action.shape).astype(np.float32)
        action = np.clip(action + noise, -1.0, 1.0)
        return action.astype(np.float32)

    def store_transition(self, s, a, r, s2, d):
        self.buffer.add(s, a, r, s2, d)

    def _soft_update(self, net: nn.Module, target: nn.Module):
        with torch.no_grad():
            for p, tp in zip(net.parameters(), target.parameters()):
                tp.data.mul_(1.0 - self.tau).add_(p.data, alpha=self.tau)

    def train_step(self):
        if len(self.buffer) < max(self.batch_size, 64):
            return

        s, a, r, ns, d = self.buffer.sample(self.batch_size)
        with torch.no_grad():
            next_a = self.actor_target(ns)
            q_target = self.critic_target(torch.cat([ns, next_a], dim=-1))
            y = r + (1.0 - d) * self.gamma * q_target

        q = self.critic(torch.cat([s, a], dim=-1))
        critic_loss = F.mse_loss(q, y)
        self.critic_opt.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 5.0)
        self.critic_opt.step()

        a_pred = self.actor(s)
        actor_loss = -self.critic(torch.cat([s, a_pred], dim=-1)).mean()
        self.actor_opt.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 5.0)
        self.actor_opt.step()

        self._soft_update(self.actor, self.actor_target)
        self._soft_update(self.critic, self.critic_target)

        # 衰减噪声
        self.noise_scale = max(self.min_noise, self.noise_scale * self.noise_decay)


# -------------------------
# SAC（简化版）
# -------------------------
class GaussianPolicy(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden: int = 256):
        super().__init__()
        self.net = mlp(state_dim, hidden, hidden)
        self.mean = nn.Linear(hidden, action_dim)
        self.log_std = nn.Linear(hidden, action_dim)

    def forward(self, x):
        h = F.relu(self.net[0](x))
        h = F.relu(self.net[1](h))
        h = F.relu(self.net[2](h))
        mean = self.mean(h)
        log_std = torch.clamp(self.log_std(h), -5, 2)
        std = torch.exp(log_std)
        return mean, std

    def sample(self, state):
        mean, std = self(state)
        normal = torch.distributions.Normal(mean, std)
        x_t = normal.rsample()
        y_t = torch.tanh(x_t)
        log_prob = normal.log_prob(x_t) - torch.log(1 - y_t.pow(2) + 1e-6)
        log_prob = log_prob.sum(1, keepdim=True)
        return y_t, log_prob


class QNet(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden: int = 256):
        super().__init__()
        self.q = mlp(state_dim + action_dim, 1, hidden)

    def forward(self, s, a):
        return self.q(torch.cat([s, a], dim=-1))


class SAC:
    def __init__(self,
                 state_dim: int,
                 action_dim: int = 6,
                 lr_actor: Optional[float] = None,
                 lr_critic: Optional[float] = None,
                 lr_alpha: float = 3e-4,
                 gamma: Optional[float] = None,
                 tau: Optional[float] = None,
                 alpha: float = 0.2,
                 automatic_entropy_tuning: bool = True,
                 buffer_size: Optional[int] = None,
                 batch_size: Optional[int] = None,
                 hidden_dim: int = 256,
                 config: Optional[Config] = None,
                 use_semantic: bool = True):
        cfg = (config.MADDPG if config is not None else Config().MADDPG)
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.gamma = float(gamma if gamma is not None else cfg["gamma"])
        self.tau = float(tau if tau is not None else cfg["tau"])
        self.batch_size = int(batch_size if batch_size is not None else cfg["batch_size"])
        self.use_semantic = use_semantic

        self.policy = GaussianPolicy(self.state_dim, self.action_dim, hidden_dim).to(DEVICE)
        self.q1 = QNet(self.state_dim, self.action_dim, hidden_dim).to(DEVICE)
        self.q2 = QNet(self.state_dim, self.action_dim, hidden_dim).to(DEVICE)
        self.q1_target = QNet(self.state_dim, self.action_dim, hidden_dim).to(DEVICE)
        self.q2_target = QNet(self.state_dim, self.action_dim, hidden_dim).to(DEVICE)
        self.q1_target.load_state_dict(self.q1.state_dict())
        self.q2_target.load_state_dict(self.q2.state_dict())

        self.policy_opt = torch.optim.Adam(self.policy.parameters(),
                                           lr=(lr_actor if lr_actor is not None else cfg["actor_lr"]))
        lr_c = (lr_critic if lr_critic is not None else cfg["critic_lr"])
        self.q1_opt = torch.optim.Adam(self.q1.parameters(), lr=lr_c)
        self.q2_opt = torch.optim.Adam(self.q2.parameters(), lr=lr_c)

        self.automatic_entropy_tuning = automatic_entropy_tuning
        self.target_entropy = -float(self.action_dim)
        if self.automatic_entropy_tuning:
            self.log_alpha = torch.zeros(1, requires_grad=True, device=DEVICE)
            self.alpha_opt = torch.optim.Adam([self.log_alpha], lr=lr_alpha)
        else:
            self.alpha = alpha

        self.buffer = ReplayBuffer(
            capacity=int(buffer_size if buffer_size is not None else cfg["buffer_size"]),
            state_dim=self.state_dim, action_dim=self.action_dim
        )

    @torch.no_grad()
    def select_action(self, state: np.ndarray) -> np.ndarray:
        s = torch.tensor(state, dtype=torch.float32, device=DEVICE).unsqueeze(0)
        a, _ = self.policy.sample(s)
        return a.squeeze(0).cpu().numpy().astype(np.float32)

    def store_transition(self, s, a, r, s2, d):
        self.buffer.add(s, a, r, s2, d)

    def _soft_update(self, net: nn.Module, target: nn.Module):
        with torch.no_grad():
            for p, tp in zip(net.parameters(), target.parameters()):
                tp.data.mul_(1.0 - self.tau).add_(p.data, alpha=self.tau)

    def train_step(self):
        if len(self.buffer) < max(self.batch_size, 64):
            return
        s, a, r, ns, d = self.buffer.sample(self.batch_size)

        with torch.no_grad():
            next_a, next_logp = self.policy.sample(ns)
            if self.automatic_entropy_tuning:
                alpha = self.log_alpha.exp()
            else:
                alpha = torch.tensor(self.alpha, device=DEVICE)
            q1n = self.q1_target(ns, next_a)
            q2n = self.q2_target(ns, next_a)
            qn = torch.min(q1n, q2n) - alpha * next_logp
            y = r + (1.0 - d) * self.gamma * qn

        # Q更新
        q1 = self.q1(s, a)
        q2 = self.q2(s, a)
        q1_loss = F.mse_loss(q1, y)
        q2_loss = F.mse_loss(q2, y)
        self.q1_opt.zero_grad(); q1_loss.backward(); torch.nn.utils.clip_grad_norm_(self.q1.parameters(), 5.0); self.q1_opt.step()
        self.q2_opt.zero_grad(); q2_loss.backward(); torch.nn.utils.clip_grad_norm_(self.q2.parameters(), 5.0); self.q2_opt.step()

        # 策略更新
        a_pi, logp_pi = self.policy.sample(s)
        q1_pi = self.q1(s, a_pi)
        q2_pi = self.q2(s, a_pi)
        q_pi = torch.min(q1_pi, q2_pi)
        if self.automatic_entropy_tuning:
            alpha = self.log_alpha.exp()
        loss_pi = (alpha * logp_pi - q_pi).mean()
        self.policy_opt.zero_grad(); loss_pi.backward(); torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 5.0); self.policy_opt.step()

        # alpha 自动调整
        if self.automatic_entropy_tuning:
            alpha_loss = -(self.log_alpha * (logp_pi + self.target_entropy).detach()).mean()
            self.alpha_opt.zero_grad(); alpha_loss.backward(); self.alpha_opt.step()

        # 软更新
        self._soft_update(self.q1, self.q1_target)
        self._soft_update(self.q2, self.q2_target)


# -------------------------
# MADDPG（简化：多智能体=多个DDPG）
# -------------------------
class MADDPG:
    def __init__(self,
                 num_agents: int,
                 state_dim: int,
                 action_dim: int = 6,
                 lr_actor: Optional[float] = None,
                 lr_critic: Optional[float] = None,
                 gamma: Optional[float] = None,
                 tau: Optional[float] = None,
                 buffer_size: Optional[int] = None,
                 batch_size: Optional[int] = None,
                 hidden_dim: int = 256,
                 config: Optional[Config] = None,
                 use_semantic: bool = True):
        self.num_agents = int(num_agents)
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.agents: List[DDPG] = []
        for _ in range(self.num_agents):
            self.agents.append(
                DDPG(state_dim=self.state_dim, action_dim=self.action_dim,
                     lr_actor=lr_actor, lr_critic=lr_critic, gamma=gamma, tau=tau,
                     buffer_size=buffer_size, batch_size=batch_size, hidden_dim=hidden_dim,
                     config=config, use_semantic=use_semantic)
            )

    @torch.no_grad()
    def select_action(self, states: List[np.ndarray]) -> List[np.ndarray]:
        actions = []
        for i, ag in enumerate(self.agents):
            s = states[i] if i < len(states) else states[0]
            actions.append(ag.select_action(s))
        return actions

    def store_transition(self, s_list, a_list, r_list, ns_list, d_list):
        for i, ag in enumerate(self.agents):
            ag.store_transition(s_list[i], a_list[i], r_list[i], ns_list[i], d_list[i])

    def train_step(self):
        for ag in self.agents:
            ag.train_step()


# -------------------------
# MAPPO（简化：共享策略 + PPO 更新）
# -------------------------
class MAPPO:
    def __init__(self,
                 num_agents: int,
                 state_dim: int,
                 action_dim: int = 6,
                 lr_actor: Optional[float] = None,
                 lr_critic: Optional[float] = None,
                 gamma: Optional[float] = None,
                 tau: Optional[float] = None,
                 buffer_size: Optional[int] = None,
                 batch_size: Optional[int] = None,
                 hidden_dim: int = 256,
                 config: Optional[Config] = None,
                 use_semantic: bool = True):
        cfg = (config.MADDPG if config is not None else Config().MADDPG)
        self.num_agents = int(num_agents)
        self.state_dim = int(state_dim)
        self.action_dim = int(action_dim)
        self.gamma = float(gamma if gamma is not None else cfg["gamma"])
        self.batch_size = int(batch_size if batch_size is not None else cfg["batch_size"])
        self.use_semantic = use_semantic

        self.actor = mlp(self.state_dim, self.action_dim, hidden_dim, out_act=nn.Tanh()).to(DEVICE)
        self.critic = mlp(self.state_dim, 1, hidden_dim).to(DEVICE)
        self.opt_actor = torch.optim.Adam(self.actor.parameters(),
                                          lr=(lr_actor if lr_actor is not None else cfg["actor_lr"]))
        self.opt_critic = torch.optim.Adam(self.critic.parameters(),
                                           lr=(lr_critic if lr_critic is not None else cfg["critic_lr"]))

        # 简易缓冲区（PPO style）
        self.traj: Dict[str, List[np.ndarray]] = dict(s=[], a=[], r=[], v=[], logp=[], done=[])

    @torch.no_grad()
    def select_action(self, states: List[np.ndarray]) -> Tuple[List[np.ndarray], List[float], float]:
        # 简化：对每个 agent 使用相同策略，独立采样
        actions, logps, values = [], [], []
        for s in states:
            st = torch.tensor(s, dtype=torch.float32, device=DEVICE).unsqueeze(0)
            mean = self.actor(st)
            dist = torch.distributions.Normal(mean, torch.ones_like(mean) * 0.2)
            a = torch.tanh(dist.rsample())
            logp = (dist.log_prob(a) - torch.log(1 - a.pow(2) + 1e-6)).sum(-1)
            v = self.critic(st).squeeze(-1)
            actions.append(a.squeeze(0).cpu().numpy().astype(np.float32))
            logps.append(float(logp.item()))
            values.append(float(v.item()))
        return actions, logps, float(np.mean(values))

    def store_transition(self, s_list, a_list, r_list, v_list, logp_list, d_list):
        for s, a, r, v, lp, d in zip(s_list, a_list, r_list, v_list, logp_list, d_list):
            self.traj["s"].append(s)
            self.traj["a"].append(a)
            self.traj["r"].append([r])
            self.traj["v"].append([v])
            self.traj["logp"].append([lp])
            self.traj["done"].append([d])

    def train_step(self):
        # 极简 PPO 更新：只做一小步，保持与其余算法训练频率一致
        if len(self.traj["s"]) < max(self.batch_size, 64):
            return
        s = torch.tensor(np.array(self.traj["s"]), dtype=torch.float32, device=DEVICE)
        a = torch.tensor(np.array(self.traj["a"]), dtype=torch.float32, device=DEVICE)
        r = torch.tensor(np.array(self.traj["r"]), dtype=torch.float32, device=DEVICE)
        old_logp = torch.tensor(np.array(self.traj["logp"]), dtype=torch.float32, device=DEVICE)
        v = self.critic(s)
        adv = (r - v.detach()).clamp(-5.0, 5.0)
        # actor
        mean = self.actor(s)
        dist = torch.distributions.Normal(mean, torch.ones_like(mean) * 0.2)
        logp = (dist.log_prob(a) - torch.log(1 - a.pow(2) + 1e-6)).sum(-1, keepdim=True)
        ratio = (logp - old_logp).exp()
        surr = torch.min(ratio * adv, torch.clamp(ratio, 0.8, 1.2) * adv).mean()
        loss_actor = -surr
        self.opt_actor.zero_grad(); loss_actor.backward(); torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 5.0); self.opt_actor.step()
        # critic
        loss_v = F.mse_loss(v, r)
        self.opt_critic.zero_grad(); loss_v.backward(); torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 5.0); self.opt_critic.step()
        # 清空trajectory
        for k in self.traj.keys():
            self.traj[k].clear()


# -------------------------
# NoSemantic 变体（仅关闭 use_semantic 标志）
# -------------------------
class NoSemanticDDPG(DDPG):
    def __init__(self, *args, **kwargs):
        kwargs["use_semantic"] = False
        super().__init__(*args, **kwargs)


class NoSemanticSAC(SAC):
    def __init__(self, *args, **kwargs):
        kwargs["use_semantic"] = False
        super().__init__(*args, **kwargs)


class NoSemanticMADDPG(MADDPG):
    def __init__(self, *args, **kwargs):
        kwargs["use_semantic"] = False
        super().__init__(*args, **kwargs)


class NoSemanticMAPPO(MAPPO):
    def __init__(self, *args, **kwargs):
        kwargs["use_semantic"] = False
        super().__init__(*args, **kwargs)
