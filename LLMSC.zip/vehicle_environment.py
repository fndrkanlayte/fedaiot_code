"""
Vehicle network environment simulator for task offloading
优化版：直接使用Config对象，确保返回固定维度的状态
"""
import numpy as np
import torch
import random
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass
from config import Config


@dataclass
class Vehicle:
    """Vehicle class representing a vehicle in the network"""
    id: int
    x: float
    y: float
    velocity: float
    direction: float
    computation_capacity: float
    energy_capacity: float
    current_energy: float
    communication_range: float
    is_edge_server: bool = False
    is_service_vehicle: bool = False


@dataclass
class Task:
    """Task class representing a computational task"""
    id: int
    vehicle_id: int
    task_type: str  # 'text' or 'image'
    data_size: float  # MB
    computation_requirement: float  # MIPS
    energy_requirement: float  # Joules
    deadline: float  # seconds
    priority: float  # 0-1
    created_time: float


class VehicleEnvironment:
    """Vehicle network environment for task offloading simulation"""

    def __init__(self, config: Config = None, **kwargs):
        """
        初始化车辆网络环境

        Args:
            config: Config对象，包含所有配置参数
            **kwargs: 可选的覆盖参数（向后兼容）
        """
        # 使用Config对象或创建默认配置
        if config is None:
            config = Config()

        self.config = config

        # 从config读取参数，kwargs可以覆盖
        vehicle_cfg = config.VEHICLE

        self.num_vehicles = kwargs.get('num_vehicles', vehicle_cfg['num_vehicles'])
        self.num_edge_servers = kwargs.get('num_edge_servers', vehicle_cfg['num_edge_servers'])
        self.communication_range = kwargs.get('communication_range', vehicle_cfg['communication_range'])
        self.max_velocity = kwargs.get('max_velocity', vehicle_cfg['max_velocity'])
        self.task_arrival_rate = kwargs.get('task_arrival_rate', vehicle_cfg['task_arrival_rate'])
        self.max_task_size = kwargs.get('max_task_size', vehicle_cfg['max_task_size'])
        self.computation_capacity = kwargs.get('computation_capacity', vehicle_cfg['computation_capacity'])
        self.energy_capacity = kwargs.get('energy_capacity', vehicle_cfg['energy_capacity'])

        # 区域大小（默认值）
        self.area_size = kwargs.get('area_size', (1000, 1000))

        # 打印配置信息
        print(f"  车辆环境配置:")
        print(f"    车辆数: {self.num_vehicles}")
        print(f"    边缘服务器: {self.num_edge_servers}")
        print(f"    通信范围: {self.communication_range}m")
        print(f"    最大速度: {self.max_velocity}m/s")

        # Initialize vehicles
        self.vehicles = self._initialize_vehicles()
        self.edge_servers = [v for v in self.vehicles if v.is_edge_server]
        self.service_vehicles = [v for v in self.vehicles if v.is_service_vehicle]

        # Task management
        self.tasks = []
        self.completed_tasks = []
        self.failed_tasks = []
        self.task_counter = 0

        # Environment state
        self.current_time = 0.0
        self.step_count = 0

        # Performance metrics
        self.metrics = {
            'total_tasks': 0,
            'completed_tasks': 0,
            'failed_tasks': 0,
            'total_energy_consumed': 0.0,
            'total_computation_time': 0.0,
            'average_latency': 0.0,
            'success_rate': 0.0
        }

        # 计算固定的状态维度
        self.state_dim = self.num_vehicles * 8 + 7
        print(f"    状态维度: {self.state_dim}")

    def _initialize_vehicles(self) -> List[Vehicle]:
        """Initialize vehicles in the environment"""
        vehicles = []

        # Create edge servers (stationary)
        for i in range(self.num_edge_servers):
            x = random.uniform(0, self.area_size[0])
            y = random.uniform(0, self.area_size[1])
            vehicle = Vehicle(
                id=i,
                x=x,
                y=y,
                velocity=0,  # Edge servers are stationary
                direction=0,
                computation_capacity=self.computation_capacity * 2,
                energy_capacity=self.energy_capacity * 2,
                current_energy=self.energy_capacity * 2,
                communication_range=self.communication_range * 1.5,
                is_edge_server=True
            )
            vehicles.append(vehicle)

        # Create service vehicles (mobile servers)
        num_service_vehicles = min(3, self.num_vehicles - self.num_edge_servers)
        for i in range(num_service_vehicles):
            x = random.uniform(0, self.area_size[0])
            y = random.uniform(0, self.area_size[1])
            vehicle = Vehicle(
                id=i + self.num_edge_servers,
                x=x,
                y=y,
                velocity=random.uniform(5, self.max_velocity),
                direction=random.uniform(0, 2 * np.pi),
                computation_capacity=self.computation_capacity * 0.8,
                energy_capacity=self.energy_capacity,
                current_energy=self.energy_capacity,
                communication_range=self.communication_range,
                is_service_vehicle=True
            )
            vehicles.append(vehicle)

        # Create regular vehicles
        remaining_vehicles = self.num_vehicles - self.num_edge_servers - num_service_vehicles
        for i in range(remaining_vehicles):
            x = random.uniform(0, self.area_size[0])
            y = random.uniform(0, self.area_size[1])
            vehicle = Vehicle(
                id=i + self.num_edge_servers + num_service_vehicles,
                x=x,
                y=y,
                velocity=random.uniform(5, self.max_velocity),
                direction=random.uniform(0, 2 * np.pi),
                computation_capacity=self.computation_capacity * 0.5,
                energy_capacity=self.energy_capacity,
                current_energy=self.energy_capacity,
                communication_range=self.communication_range,
                is_edge_server=False,
                is_service_vehicle=False
            )
            vehicles.append(vehicle)

        return vehicles

    def _generate_task(self) -> Optional[Task]:
        """Generate a new task"""
        if random.random() > self.task_arrival_rate:
            return None

        # Select random vehicle (excluding edge servers)
        available_vehicles = [v for v in self.vehicles if not v.is_edge_server]
        if not available_vehicles:
            return None

        vehicle = random.choice(available_vehicles)

        # Generate task parameters
        task_type = random.choice(['text', 'image'])
        data_size = random.uniform(0.1, self.max_task_size)
        computation_requirement = random.uniform(10, 100)
        energy_requirement = random.uniform(1, 10)
        deadline = random.uniform(1, 10)
        priority = random.uniform(0.1, 1.0)

        task = Task(
            id=self.task_counter,
            vehicle_id=vehicle.id,
            task_type=task_type,
            data_size=data_size,
            computation_requirement=computation_requirement,
            energy_requirement=energy_requirement,
            deadline=deadline,
            priority=priority,
            created_time=self.current_time
        )

        self.task_counter += 1
        return task

    def _update_vehicle_positions(self, dt: float = 1.0):
        """Update vehicle positions based on their velocity and direction"""
        for vehicle in self.vehicles:
            if vehicle.is_edge_server:
                continue

            # Update position
            dx = vehicle.velocity * np.cos(vehicle.direction) * dt
            dy = vehicle.velocity * np.sin(vehicle.direction) * dt

            vehicle.x += dx
            vehicle.y += dy

            # Boundary conditions (wrap around)
            vehicle.x = vehicle.x % self.area_size[0]
            vehicle.y = vehicle.y % self.area_size[1]

            # Random direction change
            if random.random() < 0.1:
                vehicle.direction = random.uniform(0, 2 * np.pi)

            # Random velocity change
            if random.random() < 0.05:
                vehicle.velocity = random.uniform(5, self.max_velocity)

    def _get_available_servers(self, vehicle_id: int) -> List[Vehicle]:
        """Get available servers within communication range"""
        vehicle = self.vehicles[vehicle_id]
        available_servers = []

        for server in self.vehicles:
            if server.id == vehicle_id or (not server.is_edge_server and not server.is_service_vehicle):
                continue

            distance = np.sqrt((vehicle.x - server.x)**2 + (vehicle.y - server.y)**2)
            if distance <= min(vehicle.communication_range, server.communication_range):
                available_servers.append(server)

        return available_servers

    def _calculate_offloading_cost(self,
                                 task: Task,
                                 server: Vehicle,
                                 offloading_type: str) -> Dict[str, float]:
        """Calculate the cost of offloading a task to a server"""
        vehicle = self.vehicles[task.vehicle_id]

        distance = np.sqrt((vehicle.x - server.x)**2 + (vehicle.y - server.y)**2)

        # Communication cost
        communication_cost = task.data_size * 0.1 * (distance / 100)

        # Computation cost
        if offloading_type == 'edge_server':
            computation_cost = task.computation_requirement / server.computation_capacity * 0.5
        else:
            computation_cost = task.computation_requirement / server.computation_capacity * 0.8

        # Energy cost
        energy_cost = task.energy_requirement * computation_cost

        # Latency
        transmission_latency = task.data_size * 0.01 * (distance / 100)
        computation_latency = computation_cost
        total_latency = transmission_latency + computation_latency

        # Total cost
        total_cost = communication_cost + energy_cost + total_latency * 0.1

        return {
            'communication_cost': communication_cost,
            'computation_cost': computation_cost,
            'energy_cost': energy_cost,
            'latency': total_latency,
            'total_cost': total_cost
        }

    def step(self, actions: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict]:
        """Execute one step in the environment"""
        # Update vehicle positions
        self._update_vehicle_positions()

        # Generate new task
        new_task = self._generate_task()
        if new_task:
            self.tasks.append(new_task)
            self.metrics['total_tasks'] += 1

        # Process actions
        rewards = []
        dones = []

        for i, action in enumerate(actions):
            if i >= len(self.tasks):
                rewards.append(0.0)
                dones.append(False)
                continue

            task = self.tasks[i]
            vehicle = self.vehicles[task.vehicle_id]

            # Parse action
            offload_decision = action[0]
            server_selection = action[1]
            modality_conversion = action[2]

            reward = 0.0
            done = False

            if offload_decision > 0.5:
                # Offload to server
                available_servers = self._get_available_servers(task.vehicle_id)

                if available_servers:
                    # Select server type
                    if server_selection > 0.5:
                        servers = [s for s in available_servers if s.is_service_vehicle]
                    else:
                        servers = [s for s in available_servers if s.is_edge_server]

                    if servers:
                        # Select best server
                        server = min(servers,
                                   key=lambda s: self._calculate_offloading_cost(
                                       task, s,
                                       'edge_server' if not server_selection else 'service_vehicle'
                                   )['total_cost'])

                        cost = self._calculate_offloading_cost(
                            task, server,
                            'edge_server' if not server_selection else 'service_vehicle'
                        )

                        # Check if offloading is feasible
                        if (cost['latency'] <= task.deadline and
                            server.current_energy >= cost['energy_cost']):

                            # Successful offloading
                            server.current_energy -= cost['energy_cost']
                            self.completed_tasks.append(task)
                            self.tasks.remove(task)

                            reward = task.priority * 10 - cost['total_cost']
                            self.metrics['completed_tasks'] += 1
                            self.metrics['total_energy_consumed'] += cost['energy_cost']
                            self.metrics['total_computation_time'] += cost['latency']

                            done = False
                        else:
                            # Failed offloading
                            self.failed_tasks.append(task)
                            self.tasks.remove(task)
                            reward = -task.priority * 5
                            self.metrics['failed_tasks'] += 1
                            done = False
                    else:
                        reward = -1.0
                else:
                    reward = -1.0
            else:
                # Process locally
                if (vehicle.current_energy >= task.energy_requirement and
                    vehicle.computation_capacity >= task.computation_requirement):

                    vehicle.current_energy -= task.energy_requirement
                    self.completed_tasks.append(task)
                    self.tasks.remove(task)

                    local_cost = task.energy_requirement * 0.1
                    reward = task.priority * 8 - local_cost
                    self.metrics['completed_tasks'] += 1
                    self.metrics['total_energy_consumed'] += task.energy_requirement

                    done = False
                else:
                    # Failed local processing
                    self.failed_tasks.append(task)
                    self.tasks.remove(task)
                    reward = -task.priority * 3
                    self.metrics['failed_tasks'] += 1
                    done = False

            rewards.append(reward)
            dones.append(done)

        # Update metrics
        self._update_metrics()

        # Get next state
        next_states = self._get_state()

        # Update time
        self.current_time += 1.0
        self.step_count += 1

        return next_states, np.array(rewards), np.array(dones), self.metrics

    def _get_state(self) -> np.ndarray:
        """
        Get current environment state (固定维度)
        返回固定维度: num_vehicles * 8 + 7
        """
        state = []

        # 车辆状态 (每个车辆8个特征)
        for vehicle in self.vehicles:
            energy_ratio = vehicle.current_energy / vehicle.energy_capacity
            computation_ratio = vehicle.computation_capacity / self.computation_capacity

            vehicle_state = [
                vehicle.x / self.area_size[0],  # 归一化位置x
                vehicle.y / self.area_size[1],  # 归一化位置y
                vehicle.velocity / self.max_velocity,  # 归一化速度
                vehicle.direction / (2 * np.pi),  # 归一化方向
                energy_ratio,  # 能量比例
                computation_ratio,  # 计算能力比例
                1.0 if vehicle.is_edge_server else 0.0,  # 是否边缘服务器
                1.0 if vehicle.is_service_vehicle else 0.0  # 是否服务车辆
            ]
            state.extend(vehicle_state)

        # 任务状态（固定返回第一个任务的状态，或全0）
        if self.tasks:
            task = self.tasks[0]  # 只取第一个任务
            task_state = [
                task.vehicle_id / self.num_vehicles,  # 归一化车辆ID
                1.0 if task.task_type == 'text' else 0.0,  # 任务类型
                task.data_size / self.max_task_size,  # 归一化数据大小
                task.computation_requirement / 100,  # 归一化计算需求
                task.energy_requirement / 10,  # 归一化能量需求
                task.deadline / 10,  # 归一化截止时间
                task.priority  # 优先级
            ]
            state.extend(task_state)
        else:
            # 没有任务时填充0
            state.extend([0.0] * 7)

        state_array = np.array(state, dtype=np.float32)

        # 确保维度正确
        assert len(state_array) == self.state_dim, \
            f"State dimension mismatch: {len(state_array)} != {self.state_dim}"

        return state_array

    def _update_metrics(self):
        """Update performance metrics"""
        total_tasks = self.metrics['total_tasks']
        if total_tasks > 0:
            self.metrics['success_rate'] = self.metrics['completed_tasks'] / total_tasks

        if self.metrics['completed_tasks'] > 0:
            self.metrics['average_latency'] = (
                self.metrics['total_computation_time'] / self.metrics['completed_tasks']
            )

    def reset(self) -> np.ndarray:
        """Reset environment to initial state"""
        # Reinitialize vehicles
        self.vehicles = self._initialize_vehicles()
        self.edge_servers = [v for v in self.vehicles if v.is_edge_server]
        self.service_vehicles = [v for v in self.vehicles if v.is_service_vehicle]

        # Clear tasks
        self.tasks = []
        self.completed_tasks = []
        self.failed_tasks = []
        self.task_counter = 0

        # Reset time
        self.current_time = 0.0
        self.step_count = 0

        # Reset metrics
        self.metrics = {
            'total_tasks': 0,
            'completed_tasks': 0,
            'failed_tasks': 0,
            'total_energy_consumed': 0.0,
            'total_computation_time': 0.0,
            'average_latency': 0.0,
            'success_rate': 0.0
        }

        return self._get_state()

    def get_state_dim(self) -> int:
        """Get state dimension"""
        return self.state_dim

    def get_available_actions(self, vehicle_id: int) -> List[int]:
        """Get available actions for a vehicle"""
        return [0, 1, 2]

    def render(self):
        """Render the environment (print status)"""
        print(f"\n{'='*50}")
        print(f"Environment Status (t={self.current_time:.2f}s)")
        print(f"{'='*50}")
        print(f"Vehicles: {len(self.vehicles)} "
              f"(Servers: {len(self.edge_servers)}, "
              f"Service: {len(self.service_vehicles)})")
        print(f"Tasks: Active={len(self.tasks)}, "
              f"Completed={self.metrics['completed_tasks']}, "
              f"Failed={self.metrics['failed_tasks']}")
        print(f"Success Rate: {self.metrics['success_rate']:.2%}")
        print(f"Avg Latency: {self.metrics['average_latency']:.3f}s")
        print(f"Energy Consumed: {self.metrics['total_energy_consumed']:.2f}J")
        print(f"{'='*50}\n")

    def get_metrics(self) -> Dict:
        """Get current metrics"""
        return self.metrics.copy()


