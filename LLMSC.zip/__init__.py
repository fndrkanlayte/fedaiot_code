"""
Multimodal Semantic Communication Task Offloading System for Internet of Vehicles
"""

__version__ = "1.0.0"
__author__ = "IoV Task Offloading System"
