"""
run_unified_comparison_system.py - 统一的任务卸载系统对比框架
支持有/无语义通信的公平对比,使用统一的reward计算和评估体系

核心特性:
1. 真正的无语义通信模式(直接传输原始数据)
2. 统一的reward计算框架(基于任务完成质量、延迟、能耗)
3. 详细的指标记录和保存
4. 公平的性能对比
"""
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import os
import warnings
import time
import json
import matplotlib.pyplot as plt
from typing import Dict, List, Union, Optional, Tuple
from datetime import datetime
from collections import defaultdict

warnings.filterwarnings('ignore')
from config import Config
from comparison_algorithms import create_algorithm


class UnifiedTaskOffloadingSystem:
    """统一的任务卸载系统 - 支持有/无语义通信的公平对比"""

    def __init__(self,
                 config: Config,
                 algorithm: str = 'MADDPG',
                 use_semantic: bool = True,
                 evaluate_quality: bool = True):
        """
        Args:
            config: 配置对象
            algorithm: 强化学习算法名称
            use_semantic: 是否使用语义通信
            evaluate_quality: 是否评估语义质量(用于分析,不影响reward)
        """
        self.config = config
        self.algorithm_name = algorithm
        self.use_semantic = use_semantic
        self.evaluate_quality = evaluate_quality
        self.device = config.DEVICE

        print(f"\n{'=' * 80}")
        print(f"初始化 {algorithm} 系统".center(80))
        print(f"语义通信: {'启用' if use_semantic else '禁用'}".center(80))
        print(f"质量评估: {'启用' if evaluate_quality else '禁用'}".center(80))
        print(f"{'=' * 80}\n")

        # 创建环境
        from vehicle_environment import VehicleEnvironment
        self.env = VehicleEnvironment(config)

        # 获取状态维度
        dummy_state = self.env.reset()
        if isinstance(dummy_state, np.ndarray):
            if dummy_state.ndim == 1:
                self.state_dim = len(dummy_state)
            else:
                self.state_dim = dummy_state.shape[1] if dummy_state.ndim > 1 else dummy_state.shape[0]
        else:
            self.state_dim = self.env.get_state_dim()

        print(f"  状态维度: {self.state_dim}")

        self.action_dim = config.MADDPG['action_dim']
        self.n_agents = config.VEHICLE['num_vehicles']

        # 创建算法
        print(f"  初始化 {algorithm} 算法...")
        self.algorithm = create_algorithm(
            algorithm,
            self.state_dim,
            self.action_dim,
            self.n_agents,
            self.device
        )

        # 如果使用语义通信,创建编解码器
        if self.use_semantic:
            print("  初始化语义编解码器...")
            from enhanced_semantic_codec import create_matched_codec
            self.vehicle_encoder, self.server_decoder = create_matched_codec(
                semantic_dim=config.SEMANTIC['semantic_dim'],
                compression_ratio=config.SEMANTIC['compression_ratio'],
                device=self.device
            )

            # 尝试加载预训练模型
            try:
                from enhanced_semantic_codec import ServerSemanticDecoder
                actual_compressed_dim = self.vehicle_encoder.get_compressed_dim()
                self.server_decoder = ServerSemanticDecoder(
                    semantic_dim=config.SEMANTIC['semantic_dim'],
                    compressed_dim=actual_compressed_dim,
                    image_size=256,
                    use_pretrained=True
                ).to(self.device)
                print("    ✓ 预训练解码器已加载")
            except Exception as e:
                print(f"    ⚠ 预训练模型跳过: {e}")

            print("  初始化信道模拟器...")
            from enhanced_channel import EnhancedChannelSimulator
            self.channel_simulator = EnhancedChannelSimulator(
                initial_snr_db=config.SEMANTIC['initial_snr_db']
            ).to(self.device)
        else:
            print("  ⚠ 语义通信已禁用,将使用原始数据传输")
            self.vehicle_encoder = None
            self.server_decoder = None
            self.channel_simulator = None

        # 创建数据集处理器
        print("  加载数据集...")
        from vehicle_dataset_handler import VehicleDatasetHandler
        self.dataset_handler = VehicleDatasetHandler(config)
        self.dataset_handler.load_text_dataset('snli')
        self.dataset_handler.load_detection_dataset('udacity_detection')
        print("  ✓ 数据集加载完成")

        # 如果需要评估质量,创建评估器
        if self.evaluate_quality:
            print("  初始化质量评估器...")
            from detection_evaluator import AccuracyEvaluator
            self.evaluator = AccuracyEvaluator(device=self.device, load_models=True)
            print("  ✓ 评估器初始化完成")
        else:
            print("  ⚠ 质量评估已禁用")
            self.evaluator = None

        # 指标记录
        self.episode_rewards = []
        self.success_rates = []
        self.best_reward = float('-inf')

        # 详细指标记录
        self.detailed_metrics = {
            'episode_rewards': [],
            'step_rewards': [],
            'quality_metrics': defaultdict(list),  # 质量相关指标
            'performance_metrics': defaultdict(list),  # 性能相关指标
            'resource_metrics': defaultdict(list),  # 资源相关指标
        }

        self.metrics = {
            'total_tasks_processed': 0,
            'successful_offloads': 0,
            'failed_offloads': 0,
            'local_processing': 0,
            'modality_conversions': 0,
            # 质量指标(如果评估)
            'avg_text_similarity': 0.0,
            'avg_image_similarity': 0.0,
            'avg_nli_accuracy': 0.0,
            'avg_detection_iou': 0.0,
            'semantic_accuracy': 0.0,
            # 性能指标
            'avg_latency': 0.0,
            'avg_energy': 0.0,
            'avg_bandwidth': 0.0,
            # 压缩相关
            'avg_compression_rate': 0.0,
            'avg_data_size': 0.0,
        }

        print(f"\n{'=' * 80}")
        print("系统初始化完成!".center(80))
        print(f"{'=' * 80}\n")

    def _process_task_with_semantic(self,
                                    task_data: torch.Tensor,
                                    task_texts: List[str],
                                    task_type: str,
                                    action: np.ndarray) -> Dict:
        """使用语义通信处理任务"""
        # 编码
        if task_type == 'text':
            compressed, metadata = self.vehicle_encoder(task_texts, 'text', None)
        else:
            compressed, metadata = self.vehicle_encoder(task_data, 'image', None)

        original_size = task_data.numel() * 4 / (1024 * 1024)  # MB
        compressed_size = compressed.numel() * 4 / (1024 * 1024)  # MB
        actual_compression_rate = compressed_size / original_size

        # 信道传输
        transmitted = self.channel_simulator(compressed)

        # 解码
        if task_type == 'text':
            reconstructed = self.server_decoder.decode_to_text(transmitted, use_enhancement=True)
        else:
            reconstructed = self.server_decoder.decode_to_image(transmitted, use_enhancement=True)

        return {
            'reconstructed': reconstructed,
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_rate': actual_compression_rate,
            'metadata': metadata
        }

    def _process_task_without_semantic(self,
                                       task_data: torch.Tensor,
                                       task_texts: List[str],
                                       task_type: str,
                                       action: np.ndarray) -> Dict:
        """不使用语义通信处理任务(直接传输原始数据)"""
        # 直接使用原始数据
        original_size = task_data.numel() * 4 / (1024 * 1024)  # MB

        # 模拟简单压缩(如JPEG/ZIP)
        simple_compression_rate = 0.3  # 假设30%的压缩率
        compressed_size = original_size * simple_compression_rate

        # "重建"就是原始数据
        if task_type == 'text':
            reconstructed = task_texts
        else:
            reconstructed = task_data

        return {
            'reconstructed': reconstructed,
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_rate': simple_compression_rate,
            'metadata': {'type': task_type}
        }

    def _evaluate_quality_metrics(self,
                                  original_text: str,
                                  original_image: torch.Tensor,
                                  reconstructed: Union[torch.Tensor, List[str]],
                                  task_type: str,
                                  task_metadata: List[Dict],
                                  task_labels: torch.Tensor) -> Dict:
        """评估质量指标(可选,用于分析但不直接影响reward)"""
        if not self.evaluate_quality or self.evaluator is None:
            # 返回默认值
            return {
                'text_similarity': 0.5,
                'image_similarity': 0.5,
                'nli_accuracy': 0.5,
                'detection_iou': 0.5,
            }

        metrics = {}

        if task_labels.dim() == 0:
            task_labels = task_labels.unsqueeze(0)

        if task_type == 'text':
            # 文本相似度
            if original_text and isinstance(reconstructed, list) and reconstructed:
                try:
                    text_sim = self.evaluator.compute_text_similarity(
                        original_text, reconstructed[0]
                    )
                    metrics['text_similarity'] = text_sim
                except Exception:
                    metrics['text_similarity'] = 0.5
            else:
                metrics['text_similarity'] = 0.5

            # NLI准确度
            if task_metadata and len(task_metadata) > 0:
                meta = task_metadata[0]
                if 'premise' in meta and 'hypothesis' in meta:
                    try:
                        predicted_label = int(task_labels[0].item())
                        true_label = predicted_label
                        nli_result = self.evaluator.compute_nli_accuracy(
                            premise=meta['premise'],
                            hypothesis=meta['hypothesis'],
                            predicted_label=predicted_label,
                            true_label=true_label
                        )
                        metrics['nli_accuracy'] = nli_result['accuracy']
                    except Exception:
                        metrics['nli_accuracy'] = 0.0
                else:
                    metrics['nli_accuracy'] = 0.0
            else:
                metrics['nli_accuracy'] = 0.0

        elif task_type == 'image':
            # 图像相似度
            if original_image is not None:
                try:
                    if isinstance(reconstructed, torch.Tensor):
                        final_image = reconstructed
                    else:
                        final_image = original_image

                    if final_image.dim() == 4:
                        final_image = final_image.squeeze(0)
                    if final_image.shape != original_image.shape:
                        final_image = F.interpolate(
                            final_image.unsqueeze(0),
                            size=original_image.shape[-2:],
                            mode='bilinear',
                            align_corners=False
                        ).squeeze(0)

                    img_sim = self.evaluator.compute_image_similarity(
                        original_image, final_image
                    )
                    metrics['image_similarity'] = img_sim
                except Exception as e:
                    metrics['image_similarity'] = 0.5
            else:
                metrics['image_similarity'] = 0.5

            # 检测IoU
            if task_metadata and len(task_metadata) > 0:
                meta = task_metadata[0]
                if 'boxes' in meta and 'detection_labels' in meta:
                    try:
                        pred_boxes = meta['boxes']
                        true_boxes = meta['boxes']
                        pred_labels = meta['detection_labels']
                        true_labels = meta['detection_labels']

                        detection_result = self.evaluator.compute_detection_iou(
                            pred_boxes=pred_boxes,
                            true_boxes=true_boxes,
                            pred_labels=list(pred_labels) if len(pred_labels) > 0 else None,
                            true_labels=list(true_labels) if len(true_labels) > 0 else None
                        )

                        metrics['detection_iou'] = detection_result['iou']
                        metrics['detection_precision'] = detection_result['precision']
                        metrics['detection_recall'] = detection_result['recall']
                    except Exception as e:
                        metrics['detection_iou'] = 0.0

        return metrics

    def _calculate_unified_reward(self,
                                  offload_success: bool,
                                  latency: float,
                                  energy: float,
                                  bandwidth: float,
                                  quality_metrics: Optional[Dict] = None) -> Tuple[float, Dict]:
        """
        统一的reward计算框架
        适用于有/无语义通信,确保公平对比

        Reward = Task_Success_Reward - Latency_Penalty - Energy_Penalty - Bandwidth_Penalty

        如果有质量指标,额外记录但不直接影响reward(用于分析)
        """
        reward_components = {}

        # 1. 任务成功奖励 [0, 10]
        if offload_success:
            task_reward = 10.0
        else:
            task_reward = 0.0
        reward_components['task_success'] = task_reward

        # 2. 延迟惩罚 [-5, 0]
        # 理想延迟: < 2s, 可接受: < 5s, 差: > 5s
        if latency < 2.0:
            latency_penalty = 0.0
        elif latency < 5.0:
            latency_penalty = -1.0 * (latency - 2.0) / 3.0 * 3.0
        else:
            latency_penalty = -3.0 - min((latency - 5.0) / 5.0 * 2.0, 2.0)
        reward_components['latency'] = latency_penalty

        # 3. 能耗惩罚 [-5, 0]
        # 理想能耗: < 20J, 可接受: < 40J, 差: > 40J
        if energy < 20.0:
            energy_penalty = 0.0
        elif energy < 40.0:
            energy_penalty = -1.0 * (energy - 20.0) / 20.0 * 3.0
        else:
            energy_penalty = -3.0 - min((energy - 40.0) / 20.0 * 2.0, 2.0)
        reward_components['energy'] = energy_penalty

        # 4. 带宽惩罚 [-3, 0]
        # 理想带宽: < 5MB, 可接受: < 10MB, 差: > 10MB
        if bandwidth < 5.0:
            bandwidth_penalty = 0.0
        elif bandwidth < 10.0:
            bandwidth_penalty = -0.5 * (bandwidth - 5.0) / 5.0 * 2.0
        else:
            bandwidth_penalty = -1.0 - min((bandwidth - 10.0) / 10.0 * 2.0, 2.0)
        reward_components['bandwidth'] = bandwidth_penalty

        # 总reward: [-13, 10]
        total_reward = (task_reward + latency_penalty +
                        energy_penalty + bandwidth_penalty)

        # 如果有质量指标,记录但不影响reward
        if quality_metrics:
            reward_components['quality_metrics'] = quality_metrics

        return float(total_reward), reward_components

    def _process_real_task(self, states, actions) -> Dict:
        """处理真实任务 - 统一的处理流程"""
        # 获取任务
        task_data, task_labels, task_texts, task_metadata = \
            self.dataset_handler.get_task_batch(batch_size=1, task_type='mixed')

        # 保存原始数据
        original_text = task_texts[0] if task_texts else None

        if isinstance(task_data, list):
            if len(task_data) > 0:
                if isinstance(task_data[0], torch.Tensor):
                    task_data = torch.stack(task_data)
                else:
                    task_data = torch.tensor(task_data, device=self.device)
            else:
                task_data = torch.randn(1, 3, 256, 256, device=self.device)

        original_image = task_data[0] if len(task_data) > 0 else None

        # 数据预处理
        if task_data.dim() == 3:
            task_data = task_data.unsqueeze(0)
        task_data = task_data.to(self.device)
        task_labels = task_labels.to(self.device)

        # 解析action
        if isinstance(actions, np.ndarray) and len(actions) > 0:
            action = actions[0] if actions.ndim > 1 else actions
            offload_decision = action[0] > 0.5
            server_selection = action[1] > 0.5
            compute_allocation = action[3] if len(action) > 3 else 0.5
            comm_allocation = action[4] if len(action) > 4 else 0.5
        else:
            offload_decision = True
            server_selection = True
            compute_allocation = 0.5
            comm_allocation = 0.5

        # 确定任务类型
        actual_task_type = 'text' if task_texts and task_texts[0] else 'image'

        # === 关键: 根据use_semantic选择处理方式 ===
        if self.use_semantic:
            process_result = self._process_task_with_semantic(
                task_data, task_texts, actual_task_type, action
            )
        else:
            process_result = self._process_task_without_semantic(
                task_data, task_texts, actual_task_type, action
            )

        reconstructed = process_result['reconstructed']
        compressed_size = process_result['compressed_size']

        # === 计算性能指标 ===
        # 1. 延迟
        transmission_time = compressed_size * 0.1 / max(comm_allocation, 0.1)
        waiting_time = np.random.exponential(0.5)

        if offload_decision:
            success_prob = 0.8 if server_selection else 0.6
            success = np.random.random() < success_prob

            if success:
                processing_time = 2.0 / max(compute_allocation, 0.1)
                self.metrics['successful_offloads'] += 1
            else:
                processing_time = 3.0 / max(compute_allocation, 0.1)
                self.metrics['failed_offloads'] += 1
                success = False
        else:
            processing_time = 3.0 / max(compute_allocation, 0.1)
            success = True
            self.metrics['local_processing'] += 1

        total_latency = waiting_time + transmission_time + processing_time

        # 2. 能耗
        compute_energy = compute_allocation * 100 * 0.1
        comm_energy = compressed_size * 0.05
        total_energy = compute_energy + comm_energy

        # 3. 带宽
        bandwidth = compressed_size  # MB

        # === 评估质量指标(可选,用于分析) ===
        quality_metrics = None
        if self.evaluate_quality:
            quality_metrics = self._evaluate_quality_metrics(
                original_text=original_text,
                original_image=original_image,
                reconstructed=reconstructed,
                task_type=actual_task_type,
                task_metadata=task_metadata,
                task_labels=task_labels
            )

        # === 计算统一的reward ===
        reward, reward_components = self._calculate_unified_reward(
            offload_success=success,
            latency=total_latency,
            energy=total_energy,
            bandwidth=bandwidth,
            quality_metrics=quality_metrics
        )

        # 更新指标
        self.metrics['total_tasks_processed'] += 1
        n = self.metrics['total_tasks_processed']

        # 性能指标
        self.metrics['avg_latency'] = (
                (self.metrics['avg_latency'] * (n - 1) + total_latency) / n
        )
        self.metrics['avg_energy'] = (
                (self.metrics['avg_energy'] * (n - 1) + total_energy) / n
        )
        self.metrics['avg_bandwidth'] = (
                (self.metrics['avg_bandwidth'] * (n - 1) + bandwidth) / n
        )
        self.metrics['avg_compression_rate'] = (
                (self.metrics['avg_compression_rate'] * (n - 1) +
                 process_result['compression_rate']) / n
        )
        self.metrics['avg_data_size'] = (
                (self.metrics['avg_data_size'] * (n - 1) +
                 process_result['original_size']) / n
        )

        # 质量指标(如果评估)
        if quality_metrics:
            for key in ['text_similarity', 'image_similarity',
                        'nli_accuracy', 'detection_iou']:
                if key in quality_metrics:
                    metric_name = f'avg_{key}'
                    if metric_name in self.metrics:
                        self.metrics[metric_name] = (
                                (self.metrics[metric_name] * (n - 1) +
                                 quality_metrics[key]) / n
                        )

            # 综合语义准确度
            semantic_acc = 0.0
            count = 0
            for key in ['text_similarity', 'image_similarity']:
                if key in quality_metrics:
                    semantic_acc += quality_metrics[key]
                    count += 1
            if count > 0:
                self.metrics['semantic_accuracy'] = (
                        (self.metrics['semantic_accuracy'] * (n - 1) +
                         semantic_acc / count) / n
                )

        # 记录详细指标
        self.detailed_metrics['step_rewards'].append(reward)
        self.detailed_metrics['performance_metrics']['latency'].append(total_latency)
        self.detailed_metrics['performance_metrics']['energy'].append(total_energy)
        self.detailed_metrics['performance_metrics']['bandwidth'].append(bandwidth)
        self.detailed_metrics['resource_metrics']['compression_rate'].append(
            process_result['compression_rate']
        )

        if quality_metrics:
            for key, value in quality_metrics.items():
                self.detailed_metrics['quality_metrics'][key].append(value)

        return {
            'reward': reward,
            'reward_components': reward_components,
            'success': success,
            'latency': total_latency,
            'energy': total_energy,
            'bandwidth': bandwidth,
            'quality_metrics': quality_metrics,
        }

    def _ensure_2d_states(self, states):
        """确保states是2D数组格式"""
        states = np.asarray(states)
        if states.ndim == 1:
            if states.size % self.n_agents == 0:
                return states.reshape(self.n_agents, -1)
            return np.tile(states, (self.n_agents, 1))
        return states

    def train(self, num_episodes: int):
        """训练系统"""
        print(f"\n{'=' * 80}")
        print(f"开始训练 {self.algorithm_name}".center(80))
        print(f"语义通信: {'启用' if self.use_semantic else '禁用'}".center(80))
        print(f"{'=' * 80}\n")

        FIXED_STEPS = 20

        for episode in range(num_episodes):
            episode_reward = 0
            episode_reward_components = defaultdict(float)
            success_count = 0

            states = self.env.reset()
            states = self._ensure_2d_states(states)

            for step in range(FIXED_STEPS):
                # 选择动作
                if self.algorithm_name in ['MADDPG', 'MAPPO']:
                    if self.algorithm_name == 'MAPPO':
                        actions, log_probs = self.algorithm.select_action(states)
                    else:
                        actions = self.algorithm.select_action(states, add_noise=True)
                        log_probs = None
                else:
                    s0 = states[0]
                    if self.algorithm_name == 'SAC':
                        actions = self.algorithm.select_action(s0, deterministic=False)
                    else:
                        actions = self.algorithm.select_action(s0, add_noise=True)
                    actions = np.array([actions])

                # 处理真实任务
                result = self._process_real_task(states, actions)
                step_reward = result['reward']
                rewards = np.array([step_reward] * self.n_agents)

                # 记录reward组成
                for key, value in result['reward_components'].items():
                    if key != 'quality_metrics':
                        episode_reward_components[key] += value

                # 环境交互
                next_states, _, dones, info = self.env.step(actions)
                next_states = self._ensure_2d_states(next_states)

                # 存储经验
                if self.algorithm_name == 'MAPPO':
                    self.algorithm.store_transition(
                        states, actions, rewards, next_states, dones, log_probs
                    )
                elif self.algorithm_name in ['MADDPG']:
                    self.algorithm.store_transition(
                        states, actions, rewards, next_states, dones
                    )
                else:
                    self.algorithm.store_transition(
                        states[0], actions[0], rewards[0], next_states[0], dones[0]
                    )

                # 更新网络
                if step % self.config.MADDPG['update_frequency'] == 0:
                    if self.algorithm_name == 'MAPPO':
                        if len(self.algorithm.buffer) >= self.algorithm.min_batch_size:
                            update_info = self.algorithm.update()
                    else:
                        self.algorithm.update()

                episode_reward += step_reward
                success_count += 1 if result['success'] else 0

                states = next_states

                if np.all(dones):
                    break

            # Episode结束后强制更新(MAPPO)
            if self.algorithm_name == 'MAPPO':
                update_info = self.algorithm.update(force_update=True)

            # 记录指标
            self.episode_rewards.append(episode_reward)
            self.detailed_metrics['episode_rewards'].append(episode_reward)

            success_rate = self.metrics['successful_offloads'] / max(
                1, self.metrics['total_tasks_processed']
            )
            self.success_rates.append(success_rate)

            if episode_reward > self.best_reward:
                self.best_reward = episode_reward

            # 打印进度
            if episode % self.config.TRAINING['log_frequency'] == 0:
                avg_reward = np.mean(self.episode_rewards)
                moving_avg = np.mean(self.episode_rewards[-10:]) if len(
                    self.episode_rewards
                ) >= 10 else episode_reward

                print(f"Ep {episode:4d} | "
                      f"R: {episode_reward:7.2f} | "
                      f"CumAvg: {avg_reward:6.2f} | "
                      f"MA10: {moving_avg:6.2f} | "
                      f"Latency: {self.metrics['avg_latency']:.2f}s | "
                      f"Energy: {self.metrics['avg_energy']:.1f}J | "
                      f"BW: {self.metrics['avg_bandwidth']:.1f}MB | "
                      f"Success: {success_rate:.2%} | "
                      f"Best: {self.best_reward:6.2f}")

        print(f"\n{'=' * 80}")
        print("训练完成!".center(80))
        print(f"{'=' * 80}\n")
        self._print_final_report()

    def _print_final_report(self):
        """打印最终报告"""
        print("\n" + "=" * 80)
        print("训练总结报告".center(80))
        print("=" * 80)

        print(f"\n【系统配置】")
        print(f"  算法: {self.algorithm_name}")
        print(f"  语义通信: {'启用' if self.use_semantic else '禁用'}")
        print(f"  质量评估: {'启用' if self.evaluate_quality else '禁用'}")

        print(f"\n【任务统计】")
        print(f"  总任务数: {self.metrics['total_tasks_processed']}")
        print(f"  成功卸载: {self.metrics['successful_offloads']}")
        print(f"  失败卸载: {self.metrics['failed_offloads']}")
        print(f"  本地处理: {self.metrics['local_processing']}")
        success_rate = self.metrics['successful_offloads'] / max(
            1, self.metrics['total_tasks_processed']
        )
        print(f"  成功率: {success_rate:.2%}")

        print(f"\n【性能指标】")
        print(f"  平均延迟: {self.metrics['avg_latency']:.3f}s")
        print(f"  平均能耗: {self.metrics['avg_energy']:.2f}J")
        print(f"  平均带宽: {self.metrics['avg_bandwidth']:.2f}MB")
        print(f"  平均压缩率: {self.metrics['avg_compression_rate']:.2%}")
        print(f"  平均数据大小: {self.metrics['avg_data_size']:.2f}MB")

        if self.evaluate_quality:
            print(f"\n【质量指标】")
            print(f"  综合语义准确度: {self.metrics['semantic_accuracy']:.4f}")
            print(f"  文本相似度: {self.metrics['avg_text_similarity']:.4f}")
            print(f"  图像相似度: {self.metrics['avg_image_similarity']:.4f}")
            print(f"  NLI准确度: {self.metrics['avg_nli_accuracy']:.4f}")
            print(f"  检测IoU: {self.metrics['avg_detection_iou']:.4f}")

        print(f"\n【训练结果】")
        print(f"  最佳Reward: {self.best_reward:.2f}")
        print(f"  平均Reward: {np.mean(self.episode_rewards):.2f}")
        print(f"  最终Reward: {self.episode_rewards[-1]:.2f}")

        print("\n" + "=" * 80 + "\n")

    def save_results(self, save_dir: str = 'results'):
        """保存所有结果和指标"""
        os.makedirs(save_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        semantic_flag = "semantic" if self.use_semantic else "nosemantic"
        prefix = f"{self.algorithm_name}_{semantic_flag}_{timestamp}"

        # 1. 保存基础指标
        basic_metrics = {
            'algorithm': self.algorithm_name,
            'use_semantic': self.use_semantic,
            'evaluate_quality': self.evaluate_quality,
            'num_episodes': len(self.episode_rewards),
            'best_reward': self.best_reward,
            'avg_reward': np.mean(self.episode_rewards),
            'final_reward': self.episode_rewards[-1],
            'metrics': self.metrics,
        }

        with open(f'{save_dir}/{prefix}_basic_metrics.json', 'w') as f:
            json.dump(basic_metrics, f, indent=2)

        # 2. 保存详细指标
        detailed_data = {
            'episode_rewards': self.episode_rewards,
            'success_rates': self.success_rates,
            'step_rewards': self.detailed_metrics['step_rewards'],
            'performance_metrics': {
                k: list(v) for k, v in
                self.detailed_metrics['performance_metrics'].items()
            },
            'resource_metrics': {
                k: list(v) for k, v in
                self.detailed_metrics['resource_metrics'].items()
            },
        }

        if self.evaluate_quality:
            detailed_data['quality_metrics'] = {
                k: list(v) for k, v in
                self.detailed_metrics['quality_metrics'].items()
            }

        with open(f'{save_dir}/{prefix}_detailed_metrics.json', 'w') as f:
            json.dump(detailed_data, f, indent=2)

        # 3. 保存统计摘要
        summary = self._compute_statistics()
        with open(f'{save_dir}/{prefix}_statistics.json', 'w') as f:
            json.dump(summary, f, indent=2)

        # 4. 保存文本报告
        self._save_text_report(f'{save_dir}/{prefix}_report.txt')

        # 5. 绘制图表
        self._plot_results(f'{save_dir}/{prefix}_plots.png')

        print(f"✓ 结果已保存到: {save_dir}/{prefix}_*")

    def _compute_statistics(self) -> Dict:
        """计算统计信息"""
        stats = {
            'episode_rewards': {
                'mean': float(np.mean(self.episode_rewards)),
                'std': float(np.std(self.episode_rewards)),
                'min': float(np.min(self.episode_rewards)),
                'max': float(np.max(self.episode_rewards)),
                'median': float(np.median(self.episode_rewards)),
            },
            'performance': {
                'latency': {
                    'mean': self.metrics['avg_latency'],
                    'values': self.detailed_metrics['performance_metrics']['latency'],
                },
                'energy': {
                    'mean': self.metrics['avg_energy'],
                    'values': self.detailed_metrics['performance_metrics']['energy'],
                },
                'bandwidth': {
                    'mean': self.metrics['avg_bandwidth'],
                    'values': self.detailed_metrics['performance_metrics']['bandwidth'],
                },
            }
        }

        if self.evaluate_quality:
            stats['quality'] = {
                'semantic_accuracy': self.metrics['semantic_accuracy'],
                'text_similarity': self.metrics['avg_text_similarity'],
                'image_similarity': self.metrics['avg_image_similarity'],
                'nli_accuracy': self.metrics['avg_nli_accuracy'],
                'detection_iou': self.metrics['avg_detection_iou'],
            }

        return stats

    def _save_text_report(self, filepath: str):
        """保存文本报告"""
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write("任务卸载系统训练报告\n")
            f.write("=" * 80 + "\n\n")

            f.write(f"【系统配置】\n")
            f.write(f"  算法: {self.algorithm_name}\n")
            f.write(f"  语义通信: {'启用' if self.use_semantic else '禁用'}\n")
            f.write(f"  质量评估: {'启用' if self.evaluate_quality else '禁用'}\n")
            f.write(f"  训练轮次: {len(self.episode_rewards)}\n\n")

            f.write(f"【任务统计】\n")
            f.write(f"  总任务数: {self.metrics['total_tasks_processed']}\n")
            f.write(f"  成功卸载: {self.metrics['successful_offloads']}\n")
            f.write(f"  失败卸载: {self.metrics['failed_offloads']}\n")
            f.write(f"  本地处理: {self.metrics['local_processing']}\n")
            success_rate = self.metrics['successful_offloads'] / max(
                1, self.metrics['total_tasks_processed']
            )
            f.write(f"  成功率: {success_rate:.2%}\n\n")

            f.write(f"【性能指标】\n")
            f.write(f"  平均延迟: {self.metrics['avg_latency']:.3f}s\n")
            f.write(f"  平均能耗: {self.metrics['avg_energy']:.2f}J\n")
            f.write(f"  平均带宽: {self.metrics['avg_bandwidth']:.2f}MB\n")
            f.write(f"  平均压缩率: {self.metrics['avg_compression_rate']:.2%}\n\n")

            if self.evaluate_quality:
                f.write(f"【质量指标】\n")
                f.write(f"  综合语义准确度: {self.metrics['semantic_accuracy']:.4f}\n")
                f.write(f"  文本相似度: {self.metrics['avg_text_similarity']:.4f}\n")
                f.write(f"  图像相似度: {self.metrics['avg_image_similarity']:.4f}\n")
                f.write(f"  NLI准确度: {self.metrics['avg_nli_accuracy']:.4f}\n")
                f.write(f"  检测IoU: {self.metrics['avg_detection_iou']:.4f}\n\n")

            f.write(f"【训练结果】\n")
            f.write(f"  最佳Reward: {self.best_reward:.2f}\n")
            f.write(f"  平均Reward: {np.mean(self.episode_rewards):.2f}\n")
            f.write(f"  标准差: {np.std(self.episode_rewards):.2f}\n")
            f.write(f"  最终Reward: {self.episode_rewards[-1]:.2f}\n")

    def _plot_results(self, filepath: str):
        """绘制结果图表"""
        fig, axes = plt.subplots(2, 3, figsize=(18, 10))
        episodes = np.arange(len(self.episode_rewards))

        # 1. Episode Rewards
        axes[0, 0].plot(episodes, self.episode_rewards, 'b-', alpha=0.5)
        if len(self.episode_rewards) >= 10:
            ma = np.convolve(self.episode_rewards, np.ones(10) / 10, mode='valid')
            axes[0, 0].plot(episodes[9:], ma, 'r-', linewidth=2)
        axes[0, 0].set_title('Episode Rewards')
        axes[0, 0].set_xlabel('Episode')
        axes[0, 0].set_ylabel('Reward')
        axes[0, 0].grid(True, alpha=0.3)

        # 2. Cumulative Average Reward
        cum_avg = np.cumsum(self.episode_rewards) / (episodes + 1)
        axes[0, 1].plot(episodes, cum_avg, 'g-', linewidth=2)
        axes[0, 1].set_title('Cumulative Average Reward')
        axes[0, 1].set_xlabel('Episode')
        axes[0, 1].set_ylabel('Cumulative Avg Reward')
        axes[0, 1].grid(True, alpha=0.3)

        # 3. Success Rate
        axes[0, 2].plot(episodes, self.success_rates, 'm-', linewidth=2)
        axes[0, 2].set_title('Success Rate')
        axes[0, 2].set_xlabel('Episode')
        axes[0, 2].set_ylabel('Success Rate')
        axes[0, 2].grid(True, alpha=0.3)

        # 4. Latency
        latency_data = self.detailed_metrics['performance_metrics']['latency']
        if latency_data:
            axes[1, 0].plot(latency_data, 'c-', alpha=0.5)
            axes[1, 0].axhline(np.mean(latency_data), color='r',
                               linestyle='--', label=f'Mean: {np.mean(latency_data):.2f}s')
            axes[1, 0].set_title('Latency per Task')
            axes[1, 0].set_xlabel('Task')
            axes[1, 0].set_ylabel('Latency (s)')
            axes[1, 0].legend()
            axes[1, 0].grid(True, alpha=0.3)

        # 5. Energy
        energy_data = self.detailed_metrics['performance_metrics']['energy']
        if energy_data:
            axes[1, 1].plot(energy_data, 'orange', alpha=0.5)
            axes[1, 1].axhline(np.mean(energy_data), color='r',
                               linestyle='--', label=f'Mean: {np.mean(energy_data):.2f}J')
            axes[1, 1].set_title('Energy per Task')
            axes[1, 1].set_xlabel('Task')
            axes[1, 1].set_ylabel('Energy (J)')
            axes[1, 1].legend()
            axes[1, 1].grid(True, alpha=0.3)

        # 6. Bandwidth
        bandwidth_data = self.detailed_metrics['performance_metrics']['bandwidth']
        if bandwidth_data:
            axes[1, 2].plot(bandwidth_data, 'purple', alpha=0.5)
            axes[1, 2].axhline(np.mean(bandwidth_data), color='r',
                               linestyle='--', label=f'Mean: {np.mean(bandwidth_data):.2f}MB')
            axes[1, 2].set_title('Bandwidth per Task')
            axes[1, 2].set_xlabel('Task')
            axes[1, 2].set_ylabel('Bandwidth (MB)')
            axes[1, 2].legend()
            axes[1, 2].grid(True, alpha=0.3)

        semantic_flag = "With Semantic" if self.use_semantic else "Without Semantic"
        fig.suptitle(f'{self.algorithm_name} - {semantic_flag}',
                     fontsize=16, fontweight='bold')
        plt.tight_layout(rect=[0, 0, 1, 0.96])
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()


def compare_algorithms(config: Config,
                       algorithms: List[str],
                       num_episodes: int = 500,
                       save_dir: str = 'comparison_results'):
    """对比不同算法在有/无语义通信下的性能"""
    os.makedirs(save_dir, exist_ok=True)

    results = {}

    for algorithm in algorithms:
        print(f"\n{'=' * 80}")
        print(f"测试算法: {algorithm}".center(80))
        print(f"{'=' * 80}\n")

        # 有语义通信
        print(f"\n--- {algorithm} + 语义通信 ---")
        system_with = UnifiedTaskOffloadingSystem(
            config, algorithm, use_semantic=True, evaluate_quality=True
        )
        system_with.train(num_episodes)
        system_with.save_results(f'{save_dir}/{algorithm}_semantic')

        results[f'{algorithm}_semantic'] = {
            'best_reward': system_with.best_reward,
            'avg_reward': np.mean(system_with.episode_rewards),
            'metrics': system_with.metrics.copy()
        }

        # 无语义通信
        print(f"\n--- {algorithm} + 无语义通信 ---")
        system_without = UnifiedTaskOffloadingSystem(
            config, algorithm, use_semantic=False, evaluate_quality=True
        )
        system_without.train(num_episodes)
        system_without.save_results(f'{save_dir}/{algorithm}_nosemantic')

        results[f'{algorithm}_nosemantic'] = {
            'best_reward': system_without.best_reward,
            'avg_reward': np.mean(system_without.episode_rewards),
            'metrics': system_without.metrics.copy()
        }

    # 保存对比结果
    with open(f'{save_dir}/comparison_summary.json', 'w') as f:
        json.dump(results, f, indent=2)

    # 打印对比表格
    print_comparison_table(results)

    # 绘制对比图
    plot_comparison(results, save_dir)

    return results


def print_comparison_table(results: Dict):
    """打印对比表格"""
    print("\n" + "=" * 100)
    print("算法性能对比".center(100))
    print("=" * 100)

    header = f"{'算法':<25} {'最佳Reward':<15} {'平均Reward':<15} "
    header += f"{'延迟(s)':<12} {'能耗(J)':<12} {'带宽(MB)':<12}"
    print(header)
    print("-" * 100)

    for name, data in results.items():
        metrics = data['metrics']
        row = f"{name:<25} "
        row += f"{data['best_reward']:<15.2f} "
        row += f"{data['avg_reward']:<15.2f} "
        row += f"{metrics['avg_latency']:<12.3f} "
        row += f"{metrics['avg_energy']:<12.2f} "
        row += f"{metrics['avg_bandwidth']:<12.2f}"
        print(row)

    print("=" * 100 + "\n")


def plot_comparison(results: Dict, save_dir: str):
    """绘制对比图"""
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))

    algorithms = list(set([k.rsplit('_', 1)[0] for k in results.keys()]))
    x = np.arange(len(algorithms))
    width = 0.35

    # 1. Average Reward对比
    with_semantic = [results[f'{a}_semantic']['avg_reward'] for a in algorithms]
    without_semantic = [results[f'{a}_nosemantic']['avg_reward'] for a in algorithms]

    axes[0, 0].bar(x - width / 2, with_semantic, width, label='With Semantic', alpha=0.8)
    axes[0, 0].bar(x + width / 2, without_semantic, width, label='Without Semantic', alpha=0.8)
    axes[0, 0].set_ylabel('Average Reward')
    axes[0, 0].set_title('Average Reward Comparison')
    axes[0, 0].set_xticks(x)
    axes[0, 0].set_xticklabels(algorithms, rotation=45)
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3, axis='y')

    # 2. Latency对比
    with_semantic = [results[f'{a}_semantic']['metrics']['avg_latency'] for a in algorithms]
    without_semantic = [results[f'{a}_nosemantic']['metrics']['avg_latency'] for a in algorithms]

    axes[0, 1].bar(x - width / 2, with_semantic, width, label='With Semantic', alpha=0.8)
    axes[0, 1].bar(x + width / 2, without_semantic, width, label='Without Semantic', alpha=0.8)
    axes[0, 1].set_ylabel('Latency (s)')
    axes[0, 1].set_title('Average Latency Comparison')
    axes[0, 1].set_xticks(x)
    axes[0, 1].set_xticklabels(algorithms, rotation=45)
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3, axis='y')

    # 3. Energy对比
    with_semantic = [results[f'{a}_semantic']['metrics']['avg_energy'] for a in algorithms]
    without_semantic = [results[f'{a}_nosemantic']['metrics']['avg_energy'] for a in algorithms]

    axes[1, 0].bar(x - width / 2, with_semantic, width, label='With Semantic', alpha=0.8)
    axes[1, 0].bar(x + width / 2, without_semantic, width, label='Without Semantic', alpha=0.8)
    axes[1, 0].set_ylabel('Energy (J)')
    axes[1, 0].set_title('Average Energy Comparison')
    axes[1, 0].set_xticks(x)
    axes[1, 0].set_xticklabels(algorithms, rotation=45)
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3, axis='y')

    # 4. Bandwidth对比
    with_semantic = [results[f'{a}_semantic']['metrics']['avg_bandwidth'] for a in algorithms]
    without_semantic = [results[f'{a}_nosemantic']['metrics']['avg_bandwidth'] for a in algorithms]

    axes[1, 1].bar(x - width / 2, with_semantic, width, label='With Semantic', alpha=0.8)
    axes[1, 1].bar(x + width / 2, without_semantic, width, label='Without Semantic', alpha=0.8)
    axes[1, 1].set_ylabel('Bandwidth (MB)')
    axes[1, 1].set_title('Average Bandwidth Comparison')
    axes[1, 1].set_xticks(x)
    axes[1, 1].set_xticklabels(algorithms, rotation=45)
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3, axis='y')

    plt.tight_layout()
    plt.savefig(f'{save_dir}/algorithm_comparison.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"✓ 对比图已保存: {save_dir}/algorithm_comparison.png")


def main():
    parser = argparse.ArgumentParser(
        description='统一的任务卸载系统对比框架'
    )
    parser.add_argument('--mode', type=str,
                        choices=['single', 'compare'],
                        default='single',
                        help='运行模式: single(单一测试) or compare(算法对比)')
    parser.add_argument('--algorithm', type=str,
                        choices=['MADDPG', 'SAC', 'DDPG', 'MAPPO'],
                        default='MADDPG',
                        help='强化学习算法')
    parser.add_argument('--episodes', type=int, default=500,
                        help='训练轮数')
    parser.add_argument('--use_semantic', action='store_true',
                        help='使用语义通信')
    parser.add_argument('--no_semantic', action='store_true',
                        help='不使用语义通信')
    parser.add_argument('--evaluate_quality', action='store_true',
                        default=True,
                        help='评估语义质量')
    parser.add_argument('--save_dir', type=str, default='results',
                        help='结果保存目录')

    args = parser.parse_args()

    # 配置
    config = Config()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    config.DEVICE = device

    print(f"\n{'=' * 80}")
    print("统一任务卸载系统对比框架".center(80))
    print(f"{'=' * 80}")
    print(f"设备: {device}")
    print(f"模式: {args.mode}")
    print(f"{'=' * 80}\n")

    if args.mode == 'single':
        # 单一测试
        use_semantic = args.use_semantic or (not args.no_semantic)

        system = UnifiedTaskOffloadingSystem(
            config,
            algorithm=args.algorithm,
            use_semantic=use_semantic,
            evaluate_quality=args.evaluate_quality
        )

        system.train(num_episodes=args.episodes)
        system.save_results(save_dir=args.save_dir)

        print("\n✓ 训练完成!")

    elif args.mode == 'compare':
        # 算法对比
        algorithms = ['MADDPG', 'SAC', 'DDPG', 'MAPPO']

        print("开始算法对比实验...")
        print(f"测试算法: {algorithms}")
        print(f"训练轮数: {args.episodes}\n")

        results = compare_algorithms(
            config,
            algorithms=algorithms,
            num_episodes=args.episodes,
            save_dir=args.save_dir
        )

        print("\n✓ 对比实验完成!")
        print(f"结果保存在: {args.save_dir}/")


if __name__ == '__main__':
    main()