"""
vehicle_environment.py - 车辆任务卸载环境（简化版，支持算法对比）
"""
import numpy as np
import torch
from typing import Tuple, Dict, List
from config import Config


class VehicleEnvironment:
    """车辆任务卸载环境"""
    
    def __init__(self, config: Config):
        self.config = config
        self.n_vehicles = config.VEHICLE['num_vehicles']
        self.n_edge_servers = config.VEHICLE['num_edge_servers']
        
        # 状态空间维度
        self.state_dim = 20  # 每个车辆的状态维度
        
        # 动作空间维度
        self.action_dim = config.MADDPG['action_dim']
        
        # 车辆状态
        self.vehicle_states = None
        self.edge_server_loads = None
        
        # 时间步计数
        self.current_step = 0
        self.max_steps = config.TRAINING['max_steps_per_episode']
        
        # 资源参数
        self.base_compute_capacity = config.RESOURCE['base_compute_capacity']
        self.base_comm_capacity = config.RESOURCE['base_comm_capacity']
        
        # 初始化
        self.reset()
    
    def reset(self) -> np.ndarray:
        """重置环境"""
        self.current_step = 0
        
        # 初始化车辆状态
        self.vehicle_states = []
        for i in range(self.n_vehicles):
            state = self._generate_random_state()
            self.vehicle_states.append(state)
        
        # 初始化边缘服务器负载
        self.edge_server_loads = np.random.uniform(0.2, 0.6, self.n_edge_servers)
        
        return np.array(self.vehicle_states)
    
    def step(self, actions: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict]:
        """执行动作"""
        self.current_step += 1
        
        # 确保动作形状正确
        if actions.ndim == 1:
            actions = actions.reshape(1, -1)
        
        # 计算奖励
        rewards = []
        success_flags = []
        latencies = []
        energies = []
        
        for i in range(self.n_vehicles):
            action = actions[i] if i < len(actions) else actions[0]
            
            # 解析动作
            offload_decision = action[0]  # [-1, 1] -> [0(本地), 1(卸载)]
            server_selection = action[1]  # [-1, 1] -> 服务器索引
            compute_allocation = (action[2] + 1) / 2  # [-1, 1] -> [0, 1]
            comm_allocation = (action[3] + 1) / 2  # [-1, 1] -> [0, 1]
            compression_rate = (action[4] + 1) / 2 if len(action) > 4 else 0.5  # [-1, 1] -> [0, 1]
            snr_adjustment = action[5] if len(action) > 5 else 0  # [-1, 1]
            
            # 计算性能指标
            if offload_decision > 0:  # 卸载
                # 选择边缘服务器
                server_idx = int((server_selection + 1) / 2 * (self.n_edge_servers - 1))
                server_idx = np.clip(server_idx, 0, self.n_edge_servers - 1)
                
                server_load = self.edge_server_loads[server_idx]
                
                # 计算延迟
                transmission_delay = (1 - comm_allocation) * 0.1 + np.random.uniform(0, 0.05)
                computation_delay = (1 - compute_allocation) * server_load * 0.2 + np.random.uniform(0, 0.1)
                latency = transmission_delay + computation_delay
                
                # 计算能耗
                energy = comm_allocation * 2.0 + np.random.uniform(0, 0.5)
                
                # 成功概率
                success_prob = (1 - server_load) * compute_allocation * comm_allocation
                success = np.random.rand() < success_prob
                
            else:  # 本地处理
                latency = 0.3 + np.random.uniform(0, 0.2)
                energy = compute_allocation * 3.0 + np.random.uniform(0, 0.5)
                success = np.random.rand() < 0.7
            
            # 计算奖励
            reward = 0.0
            
            # 成功奖励
            if success:
                reward += 5.0
            else:
                reward -= 2.0
            
            # 延迟惩罚
            reward -= latency * 2.0
            
            # 能耗惩罚
            reward -= energy * 0.5
            
            # 压缩率奖励（使用语义通信时）
            if compression_rate < 0.5:
                reward += (0.5 - compression_rate) * 1.0
            
            rewards.append(reward)
            success_flags.append(1.0 if success else 0.0)
            latencies.append(latency)
            energies.append(energy)
            
            # 更新服务器负载
            if offload_decision > 0:
                self.edge_server_loads[server_idx] = min(
                    self.edge_server_loads[server_idx] + 0.05,
                    1.0
                )
        
        # 生成下一个状态
        next_states = []
        for i in range(self.n_vehicles):
            next_state = self._generate_random_state()
            next_states.append(next_state)
        
        self.vehicle_states = next_states
        
        # 判断是否结束
        dones = np.array([self.current_step >= self.max_steps] * self.n_vehicles)
        
        # 附加信息
        info = {
            'success': np.array(success_flags),
            'latency': np.array(latencies),
            'energy': np.array(energies)
        }
        
        return np.array(next_states), np.array(rewards), dones, info
    
    def _generate_random_state(self) -> np.ndarray:
        """生成随机状态"""
        state = np.random.randn(self.state_dim)
        
        # 标准化到合理范围
        state = np.clip(state, -2, 2)
        
        return state
    
    def render(self):
        """渲染环境（可选）"""
        pass


class VehicleEnvironmentWithSemantic(VehicleEnvironment):
    """支持语义通信的车辆环境"""
    
    def __init__(self, config: Config, use_semantic: bool = True):
        super().__init__(config)
        self.use_semantic = use_semantic
        
        # 语义编码器和解码器（模拟）
        if use_semantic:
            self.semantic_dim = config.SEMANTIC['semantic_dim']
            self.compression_ratio = config.SEMANTIC['compression_ratio']
    
    def step(self, actions: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict]:
        """执行动作（带语义通信）"""
        next_states, rewards, dones, info = super().step(actions)
        
        # 如果使用语义通信，添加语义奖励
        if self.use_semantic:
            semantic_rewards = self._compute_semantic_rewards(actions)
            rewards = rewards + semantic_rewards * 0.3
        
        return next_states, rewards, dones, info
    
    def _compute_semantic_rewards(self, actions: np.ndarray) -> np.ndarray:
        """计算语义奖励"""
        semantic_rewards = []
        
        for i in range(self.n_vehicles):
            action = actions[i] if i < len(actions) else actions[0]
            
            # 提取压缩率
            if len(action) > 4:
                compression_rate = (action[4] + 1) / 2
            else:
                compression_rate = self.compression_ratio
            
            # 压缩率越小，语义保真度越高，奖励越大
            semantic_accuracy = 1 - compression_rate * 0.5
            
            # 添加随机噪声
            semantic_accuracy += np.random.randn() * 0.1
            semantic_accuracy = np.clip(semantic_accuracy, 0, 1)
            
            # 转换为奖励
            reward = semantic_accuracy * 2.0
            semantic_rewards.append(reward)
        
        return np.array(semantic_rewards)
