"""
dataset_cache_manager.py - 数据集缓存管理器
支持SNLI文本数据集和Udacity Self Driving Car目标检测数据集
"""
import os
import pickle
import torch
import numpy as np
from typing import Tuple, List, Optional
import warnings
warnings.filterwarnings('ignore')


class DatasetCacheManager:
    """数据集缓存管理器"""

    def __init__(self, cache_dir: str = './data/cache'):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

        self.snli_cache_file = os.path.join(cache_dir, 'snli_dataset.pkl')
        self.udacity_cache_file = os.path.join(cache_dir, 'udacity_detection_dataset.pkl')

    # ================ SNLI文本数据集缓存 ================

    def cache_snli_dataset(self, premises: List[str],
                          hypotheses: List[str],
                          labels: List[int]):
        """缓存SNLI数据集"""
        print(f"缓存SNLI数据集到: {self.snli_cache_file}")
        data = {
            'premises': premises,
            'hypotheses': hypotheses,
            'labels': labels
        }
        with open(self.snli_cache_file, 'wb') as f:
            pickle.dump(data, f)
        print("✓ SNLI数据集缓存完成")

    def load_snli_from_cache(self) -> Optional[Tuple[List[str], List[str], List[int]]]:
        """从缓存加载SNLI数据集"""
        if not os.path.exists(self.snli_cache_file):
            return None

        try:
            print(f"从缓存加载SNLI数据集: {self.snli_cache_file}")
            with open(self.snli_cache_file, 'rb') as f:
                data = pickle.load(f)
            return data['premises'], data['hypotheses'], data['labels']
        except Exception as e:
            print(f"加载SNLI缓存失败: {e}")
            return None

    # ================ Udacity目标检测数据集缓存 ================

    def cache_udacity_dataset(self, images: torch.Tensor,
                             boxes: List[np.ndarray],
                             labels: List[np.ndarray]):
        """缓存Udacity检测数据集"""
        print(f"缓存Udacity数据集到: {self.udacity_cache_file}")
        data = {
            'images': images,
            'boxes': boxes,
            'labels': labels
        }
        with open(self.udacity_cache_file, 'wb') as f:
            pickle.dump(data, f)
        print("✓ Udacity数据集缓存完成")

    def load_udacity_from_cache(self) -> Optional[Tuple[torch.Tensor, List[np.ndarray], List[np.ndarray]]]:
        """从缓存加载Udacity数据集"""
        if not os.path.exists(self.udacity_cache_file):
            return None

        try:
            print(f"从缓存加载Udacity数据集: {self.udacity_cache_file}")
            with open(self.udacity_cache_file, 'rb') as f:
                data = pickle.load(f)
            return data['images'], data['boxes'], data['labels']
        except Exception as e:
            print(f"加载Udacity缓存失败: {e}")
            return None

    def clear_cache(self):
        """清除所有缓存"""
        for cache_file in [self.snli_cache_file, self.udacity_cache_file]:
            if os.path.exists(cache_file):
                os.remove(cache_file)
                print(f"✓ 已删除缓存: {cache_file}")


def create_synthetic_udacity_dataset(num_samples: int = 5000,
                                     image_size: int = 256) -> Tuple[torch.Tensor, List[np.ndarray], List[np.ndarray]]:
    """
    创建合成的Udacity风格目标检测数据集

    类别：
    - 0: car (汽车)
    - 1: truck (卡车)
    - 2: pedestrian (行人)
    - 3: cyclist (骑行者)
    - 4: traffic_light (交通灯)

    Returns:
        images: [N, 3, H, W] 图像张量
        boxes: List[np.ndarray] 边界框列表，每个元素为 [M, 4]
        labels: List[np.ndarray] 标签列表，每个元素为 [M]
    """
    print(f"创建合成Udacity数据集: {num_samples}个样本...")

    images = []
    boxes_list = []
    labels_list = []

    for i in range(num_samples):
        # 创建道路场景图像
        image = _generate_road_scene_image(image_size)

        # 生成目标数量（1-5个目标）
        num_objects = np.random.randint(1, 6)

        # 生成边界框和标签
        bboxes = []
        object_labels = []

        for _ in range(num_objects):
            # 随机选择类别（汽车和行人更常见）
            class_probs = [0.4, 0.15, 0.25, 0.1, 0.1]  # car, truck, pedestrian, cyclist, traffic_light
            label = np.random.choice(5, p=class_probs)

            # 根据类别生成合理的边界框大小
            if label in [0, 1]:  # car, truck
                w = np.random.randint(60, 150)
                h = np.random.randint(50, 100)
            elif label in [2, 3]:  # pedestrian, cyclist
                w = np.random.randint(30, 60)
                h = np.random.randint(60, 120)
            else:  # traffic_light
                w = np.random.randint(20, 40)
                h = np.random.randint(40, 70)

            # 生成位置（确保在图像内）
            x1 = np.random.randint(0, max(1, image_size - w))
            y1 = np.random.randint(0, max(1, image_size - h))
            x2 = x1 + w
            y2 = y1 + h

            # 确保边界框有效
            if x2 <= image_size and y2 <= image_size and w >= 20 and h >= 20:
                bboxes.append([x1, y1, x2, y2])
                object_labels.append(label)

        if len(bboxes) > 0:
            images.append(image)
            boxes_list.append(np.array(bboxes, dtype=np.float32))
            labels_list.append(np.array(object_labels, dtype=np.int64))

        if (i + 1) % 1000 == 0:
            print(f"  已生成 {i+1}/{num_samples} 样本...")

    # 转换为张量
    images_tensor = torch.stack(images)

    print(f"✓ 数据集创建完成: {len(images_tensor)} 样本")
    print(f"  图像形状: {images_tensor.shape}")
    print(f"  平均目标数: {np.mean([len(b) for b in boxes_list]):.2f}")

    return images_tensor, boxes_list, labels_list


def _generate_road_scene_image(size: int = 256) -> torch.Tensor:
    """生成道路场景图像"""
    # 创建基础道路场景
    image = torch.zeros(3, size, size)

    # 天空区域（上半部分 - 蓝色）
    sky_height = size // 3
    image[2, :sky_height, :] = 0.6 + torch.rand(sky_height, size) * 0.2  # 蓝色通道
    image[0, :sky_height, :] = 0.3 + torch.rand(sky_height, size) * 0.1
    image[1, :sky_height, :] = 0.3 + torch.rand(sky_height, size) * 0.1

    # 道路区域（下半部分 - 灰色）
    road_start = sky_height
    image[:, road_start:, :] = 0.4 + torch.rand(3, size - road_start, size) * 0.1

    # 添加道路标线
    mid = size // 2
    line_width = 4
    image[:, road_start:, mid-line_width//2:mid+line_width//2] = 0.9

    # 添加噪声
    noise = torch.randn(3, size, size) * 0.05
    image = torch.clamp(image + noise, 0, 1)

    return image


def download_and_prepare_udacity_dataset(cache_dir: str = './data/udacity',
                                         subset_size: int = 5000) -> Tuple[torch.Tensor, List[np.ndarray], List[np.ndarray]]:
    """
    下载并准备Udacity数据集

    注意：Udacity Self Driving Car数据集较大，这里提供模拟数据
    真实数据请访问: https://github.com/udacity/self-driving-car
    """
    print("\n" + "="*70)
    print("准备Udacity Self Driving Car数据集")
    print("="*70)
    print("\n注意: 使用合成数据进行演示")
    print("真实Udacity数据集请访问: https://github.com/udacity/self-driving-car")
    print(f"数据集大小: {subset_size} 样本\n")

    # 创建合成数据集
    images, boxes, labels = create_synthetic_udacity_dataset(
        num_samples=subset_size,
        image_size=256
    )

    return images, boxes, labels


# Udacity数据集类别信息
UDACITY_CLASSES = {
    0: 'car',
    1: 'truck',
    2: 'pedestrian',
    3: 'cyclist',
    4: 'traffic_light'
}

UDACITY_CLASS_COLORS = {
    'car': (0, 255, 0),          # 绿色
    'truck': (255, 165, 0),      # 橙色
    'pedestrian': (255, 0, 0),   # 红色
    'cyclist': (255, 255, 0),    # 黄色
    'traffic_light': (0, 255, 255)  # 青色
}