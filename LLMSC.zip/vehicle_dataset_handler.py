"""
vehicle_dataset_handler.py - 车辆场景数据集处理器
使用符合车辆场景的数据集：
- 文本: 自然语言推理（NLI）数据集
- 图像: Udacity Self Driving Car目标检测数据集（车辆、行人、骑行者等检测）
"""
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from transformers import AutoTokenizer
import numpy as np
from typing import Tuple, List, Optional, Union, Dict
import random
from config import Config


class VehicleTextDataset(Dataset):
    """车辆场景文本数据集 - 自然语言推理(NLI)"""
    def __init__(self,
                 premises: List[str],
                 hypotheses: List[str],
                 labels: List[int],
                 tokenizer_name: str = 'bert-base-uncased',
                 max_length: int = 128):
        self.premises = premises
        self.hypotheses = hypotheses
        self.labels = labels
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        self.max_length = max_length
        self.label_names = ['entailment', 'neutral', 'contradiction']

    def __len__(self):
        return len(self.premises)

    def __getitem__(self, idx):
        premise = self.premises[idx]
        hypothesis = self.hypotheses[idx]
        label = self.labels[idx]

        text = f"{premise} [SEP] {hypothesis}"

        encoding = self.tokenizer(
            text,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )

        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'labels': torch.tensor(label, dtype=torch.long),
            'premise': premise,
            'hypothesis': hypothesis,
            'text': text
        }


class UdacityDetectionDataset(Dataset):
    """Udacity Self Driving Car目标检测数据集"""

    def __init__(self,
                 images: torch.Tensor,
                 boxes: List[np.ndarray],
                 labels: List[np.ndarray],
                 image_size: int = 256,
                 normalize: bool = True,
                 min_box_size: int = 20):
        """
        Args:
            images: [N, 3, H, W] 图像张量
            boxes: List[np.ndarray] 每个图像的边界框 [M, 4] (x1, y1, x2, y2)
            labels: List[np.ndarray] 每个图像的类别标签 [M]
                    (0=car, 1=truck, 2=pedestrian, 3=cyclist, 4=traffic_light)
            image_size: 目标图像尺寸
            normalize: 是否归一化
            min_box_size: 最小边界框尺寸
        """
        self.images = images
        self.boxes = boxes
        self.labels = labels
        self.image_size = image_size
        self.normalize = normalize
        self.min_box_size = min_box_size

        # Udacity类别名称（5个类别）
        self.class_names = ['car', 'truck', 'pedestrian', 'cyclist', 'traffic_light']
        self.num_classes = len(self.class_names)

        # 验证数据
        assert len(images) == len(boxes) == len(labels), \
            "Images, boxes, and labels must have same length"

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        image = self.images[idx]
        boxes = self.boxes[idx].copy()  # [M, 4]
        labels = self.labels[idx].copy()  # [M]

        # 确保图像格式正确
        if isinstance(image, torch.Tensor):
            if image.dim() == 2:
                image = image.unsqueeze(0).repeat(3, 1, 1)
            elif image.dim() == 3 and image.shape[0] not in [1, 3]:
                image = image.permute(2, 0, 1)

            # 记录原始尺寸
            _, orig_h, orig_w = image.shape

            # Resize图像
            if orig_h != self.image_size or orig_w != self.image_size:
                image = torch.nn.functional.interpolate(
                    image.unsqueeze(0),
                    size=(self.image_size, self.image_size),
                    mode='bilinear',
                    align_corners=False
                ).squeeze(0)

                # 调整边界框坐标
                if len(boxes) > 0:
                    scale_x = self.image_size / orig_w
                    scale_y = self.image_size / orig_h
                    boxes[:, [0, 2]] *= scale_x
                    boxes[:, [1, 3]] *= scale_y

            # 确保是RGB
            if image.shape[0] == 1:
                image = image.repeat(3, 1, 1)

            # 归一化
            if self.normalize:
                mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
                std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
                image = (image - mean) / std

        # 过滤太小的边界框
        if len(boxes) > 0:
            widths = boxes[:, 2] - boxes[:, 0]
            heights = boxes[:, 3] - boxes[:, 1]
            valid_mask = (widths >= self.min_box_size) & (heights >= self.min_box_size)
            boxes = boxes[valid_mask]
            labels = labels[valid_mask]

        # 转换为torch张量
        boxes_tensor = torch.from_numpy(boxes).float() if len(boxes) > 0 else torch.zeros((0, 4))
        labels_tensor = torch.from_numpy(labels).long() if len(labels) > 0 else torch.zeros((0,), dtype=torch.long)

        return {
            'image': image,
            'boxes': boxes_tensor,
            'labels': labels_tensor,
            'num_objects': len(labels),
            'class_names': [self.class_names[int(l)] for l in labels] if len(labels) > 0 else []
        }


class VehicleDatasetHandler:
    """车辆场景数据集处理器 - 支持Udacity目标检测"""

    def __init__(self, config: Config):
        self.config = config
        self.text_dataset = None
        self.detection_dataset = None

        # 初始化缓存管理器
        from dataset_cache_manager import DatasetCacheManager
        self.cache_manager = DatasetCacheManager(
            cache_dir=config.PATHS['data_dir'] + '/cache'
        )

    def load_text_dataset(self, dataset_name: str = 'snli') -> VehicleTextDataset:
        """加载NLI文本数据集（优先使用缓存）"""
        print(f"加载文本数据集: {dataset_name}")

        cached_data = self.cache_manager.load_snli_from_cache()

        if cached_data is not None:
            premises, hypotheses, labels = cached_data
            print(f"✓ 从缓存加载: {len(premises)} 样本")
        else:
            print("首次加载，需要下载数据集（约1-3分钟）...")
            from datasets import load_dataset
            dataset = load_dataset('snli')

            train_premises = dataset['train']['premise']
            train_hypotheses = dataset['train']['hypothesis']
            train_labels = dataset['train']['label']

            val_premises = dataset['validation']['premise']
            val_hypotheses = dataset['validation']['hypothesis']
            val_labels = dataset['validation']['label']

            train_indices = [i for i, label in enumerate(train_labels) if label != -1]
            val_indices = [i for i, label in enumerate(val_labels) if label != -1]

            premises = [train_premises[i] for i in train_indices] + \
                      [val_premises[i] for i in val_indices]
            hypotheses = [train_hypotheses[i] for i in train_indices] + \
                        [val_hypotheses[i] for i in val_indices]
            labels = [train_labels[i] for i in train_indices] + \
                    [val_labels[i] for i in val_indices]

            print(f"✓ 下载完成: {len(premises)} 样本")
            self.cache_manager.cache_snli_dataset(premises, hypotheses, labels)

        # 使用子集
        if self.config.DATASET.get('use_subset', False):
            subset_size = self.config.DATASET.get('subset_size', 10000)
            subset_size = min(subset_size, len(premises))
            premises = premises[:subset_size]
            hypotheses = hypotheses[:subset_size]
            labels = labels[:subset_size]
            print(f"使用子集: {len(premises)} 样本")

        self.text_dataset = VehicleTextDataset(
            premises=premises,
            hypotheses=hypotheses,
            labels=labels,
            max_length=self.config.DATASET['max_text_length']
        )

        return self.text_dataset

    def load_detection_dataset(self, dataset_name: str = 'udacity_detection') -> UdacityDetectionDataset:
        """加载Udacity Self Driving Car目标检测数据集（优先使用缓存）"""
        print(f"加载检测数据集: {dataset_name}")

        cached_data = self.cache_manager.load_udacity_from_cache()

        if cached_data is not None:
            images, boxes, labels = cached_data
            print(f"✓ 从缓存加载: {len(images)} 样本")
        else:
            print("首次加载，创建Udacity风格检测数据集...")
            print("注意: 使用合成数据。如需真实Udacity数据请访问: https://github.com/udacity/self-driving-car")

            from dataset_cache_manager import create_synthetic_udacity_dataset

            num_samples = self.config.DATASET.get('subset_size', 5000)
            image_size = self.config.DATASET.get('image_size', 256)

            images, boxes, labels = create_synthetic_udacity_dataset(
                num_samples=num_samples,
                image_size=image_size
            )

            print(f"✓ 创建完成: {len(images)} 样本")
            self.cache_manager.cache_udacity_dataset(images, boxes, labels)

        # 使用子集
        if self.config.DATASET.get('use_subset', False):
            subset_size = self.config.DATASET.get('subset_size', 5000)
            subset_size = min(subset_size, len(images))
            images = images[:subset_size]
            boxes = boxes[:subset_size]
            labels = labels[:subset_size]
            print(f"使用子集: {len(images)} 样本")

        self.detection_dataset = UdacityDetectionDataset(
            images=images,
            boxes=boxes,
            labels=labels,
            image_size=self.config.DATASET['image_size'],
            min_box_size=self.config.DATASET.get('min_box_size', 20)
        )

        return self.detection_dataset

    def load_image_dataset(self, dataset_name: str = 'udacity_detection'):
        """兼容旧接口：加载图像数据集"""
        return self.load_detection_dataset(dataset_name)

    def get_task_batch(self,
                      batch_size: int = 32,
                      task_type: str = 'mixed') -> Tuple[List, torch.Tensor, List[str], List[dict]]:
        """
        获取任务批次（支持检测任务）

        Returns:
            data: 文本token_ids或图像tensor的列表
            labels: 标签tensor（文本为类别，图像为边界框数量）
            texts: 文本内容列表
            metadata: 元数据列表（包含boxes和labels）
        """
        if self.text_dataset is None or self.detection_dataset is None:
            raise ValueError("请先加载数据集")

        batch_data = []
        batch_labels = []
        batch_texts = []
        batch_metadata = []

        for _ in range(batch_size):
            if task_type == 'text':
                use_text = True
            elif task_type == 'image' or task_type == 'detection':
                use_text = False
            else:  # mixed
                use_text = random.random() < 0.5

            if use_text:
                # 文本任务
                idx = random.randint(0, len(self.text_dataset) - 1)
                item = self.text_dataset[idx]

                batch_data.append(item['input_ids'])
                batch_labels.append(item['labels'])
                batch_texts.append(item['text'])

                batch_metadata.append({
                    'type': 'text',
                    'premise': item['premise'],
                    'hypothesis': item['hypothesis'],
                    'label_name': self.text_dataset.label_names[item['labels'].item()],
                    'task': 'nli'
                })
            else:
                # 检测任务
                idx = random.randint(0, len(self.detection_dataset) - 1)
                item = self.detection_dataset[idx]

                batch_data.append(item['image'])
                # 使用边界框数量作为标签（用于跟踪）
                batch_labels.append(torch.tensor(item['num_objects'], dtype=torch.long))
                batch_texts.append("")

                batch_metadata.append({
                    'type': 'image',
                    'task': 'detection',
                    'boxes': item['boxes'].numpy(),
                    'detection_labels': item['labels'].numpy(),
                    'class_names': item['class_names'],
                    'num_objects': item['num_objects']
                })

        # 标签转换为tensor
        batch_labels = torch.stack(batch_labels)

        return batch_data, batch_labels, batch_texts, batch_metadata

    def get_dataset_info(self) -> dict:
        """获取数据集信息"""
        info = {
            'text_dataset_size': len(self.text_dataset) if self.text_dataset else 0,
            'detection_dataset_size': len(self.detection_dataset) if self.detection_dataset else 0,
            'num_text_classes': 3,
            'num_detection_classes': 5,  # Udacity有5个类别
            'text_task': 'Natural Language Inference (NLI)',
            'detection_task': 'Object Detection (Udacity Self Driving Car)',
            'text_classes': ['entailment', 'neutral', 'contradiction'],
            'detection_classes': ['car', 'truck', 'pedestrian', 'cyclist', 'traffic_light']
        }
        return info