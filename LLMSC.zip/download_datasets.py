"""
download_datasets.py - 一键下载并缓存所有数据集
运行一次后，后续加载将非常快速
"""
import time



def main():
    print("\n" + "=" * 70)
    print("数据集一键下载工具".center(70))
    print("=" * 70)
    print("\n这个工具将:")
    print("  1. 下载SNLI数据集 (约570MB, 用时2-5分钟)")
    print("  2. 下载CIFAR-10数据集 (约170MB, 用时1-2分钟)")
    print("  3. 缓存到本地，后续加载仅需数秒")
    print("\n只需运行一次！")

    input("\n按回车键开始下载...")

    try:
        from config import Config
        from dataset_cache_manager import DatasetCacheManager, download_and_cache_datasets

        config = Config()
        cache_manager = DatasetCacheManager(
            cache_dir=config.PATHS['data_dir'] + '/cache'
        )

        # 检查是否已缓存
        info = cache_manager.get_cache_info()

        need_download = False
        if not info['snli']['exists']:
            print("\n需要下载SNLI数据集")
            need_download = True
        else:
            print(f"\n✓ SNLI已缓存 ({info['snli']['size_mb']:.2f} MB)")

        if not info['cifar10']['exists']:
            print("需要下载CIFAR-10数据集")
            need_download = True
        else:
            print(f"✓ CIFAR-10已缓存 ({info['cifar10']['size_mb']:.2f} MB)")

        if not need_download:
            print("\n✓ 所有数据集已缓存，无需下载！")
            print("\n可以直接运行:")
            print("  python quick_test_vehicle.py")
            return

        # 下载
        start_time = time.time()
        download_and_cache_datasets(cache_manager, config, force_download=False)
        total_time = time.time() - start_time

        print(f"\n✓ 完成! 总用时: {total_time / 60:.1f} 分钟")

        # 显示缓存信息
        info = cache_manager.get_cache_info()
        total_size = info['snli'].get('size_mb', 0) + info['cifar10'].get('size_mb', 0)

        print(f"\n缓存信息:")
        print(f"  SNLI: {info['snli'].get('size_mb', 0):.2f} MB")
        print(f"  CIFAR-10: {info['cifar10'].get('size_mb', 0):.2f} MB")
        print(f"  总计: {total_size:.2f} MB")

        print(f"\n缓存位置: {config.PATHS['data_dir']}/cache/")

        print("\n现在可以运行:")
        print("  python quick_test_vehicle.py")
        print("  python test_vehicle_dataset.py")
        print("  python run_enhanced_system.py")

        print("\n后续加载将非常快速（数秒内完成）！")

    except Exception as e:
        print(f"\n✗ 错误: {e}")
        import traceback
        traceback.print_exc()

        print("\n故障排除:")
        print("  1. 检查网络连接")
        print("  2. 确保有足够的磁盘空间 (约1GB)")
        print("  3. 安装必要的库:")
        print("     pip install datasets torch torchvision")


if __name__ == "__main__":
    main()