"""
comparison_algorithms.py - 对比算法实现（修复MAPPO经验池问题 v2）

关键修复：
1. 降低min_batch_size从64到20（适配每episode只有20步的设置）
2. 使用episode-based更新而非step-based
3. 保持GAE、梯度裁剪等其他修复
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from typing import List, Tuple, Dict
from collections import deque
import random


# ===================== 通用组件 =====================

class ReplayBuffer:
    """经验回放缓冲区"""

    def __init__(self, capacity: int):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*batch)
        return (np.array(state), np.array(action), np.array(reward),
                np.array(next_state), np.array(done))

    def __len__(self):
        return len(self.buffer)


class Actor(nn.Module):
    """Actor网络"""

    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, action_dim)

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        return torch.tanh(self.fc3(x))


class Critic(nn.Module):
    """Critic网络"""

    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, 1)

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)


class GaussianActor(nn.Module):
    """高斯策略Actor（用于SAC）"""

    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.mean = nn.Linear(hidden_dim, action_dim)
        self.log_std = nn.Linear(hidden_dim, action_dim)

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        mean = self.mean(x)
        log_std = self.log_std(x)
        log_std = torch.clamp(log_std, -20, 2)
        return mean, log_std

    def sample(self, state):
        mean, log_std = self.forward(state)
        std = log_std.exp()
        normal = torch.distributions.Normal(mean, std)
        x_t = normal.rsample()
        action = torch.tanh(x_t)
        log_prob = normal.log_prob(x_t)
        log_prob -= torch.log(1 - action.pow(2) + 1e-6)
        log_prob = log_prob.sum(1, keepdim=True)
        return action, log_prob


# ===================== DDPG =====================

class DDPG:
    """Deep Deterministic Policy Gradient"""

    def __init__(self, state_dim: int, action_dim: int, device='cpu'):
        self.device = device
        self.action_dim = action_dim

        # 网络
        self.actor = Actor(state_dim, action_dim).to(device)
        self.actor_target = Actor(state_dim, action_dim).to(device)
        self.actor_target.load_state_dict(self.actor.state_dict())

        self.critic = Critic(state_dim, action_dim).to(device)
        self.critic_target = Critic(state_dim, action_dim).to(device)
        self.critic_target.load_state_dict(self.critic.state_dict())

        # 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=1e-4)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=3e-4)

        # 超参数
        self.gamma = 0.99
        self.tau = 0.005
        self.noise_std = 0.2

        # 经验回放
        self.replay_buffer = ReplayBuffer(100000)
        self.batch_size = 256

    def select_action(self, state, add_noise=True):
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            action = self.actor(state).cpu().numpy()[0]

        if add_noise:
            noise = np.random.normal(0, self.noise_std, size=self.action_dim)
            action = np.clip(action + noise, -1, 1)

        return action

    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return {}

        # 采样
        state, action, reward, next_state, done = self.replay_buffer.sample(self.batch_size)

        state = torch.FloatTensor(state).to(self.device)
        action = torch.FloatTensor(action).to(self.device)
        reward = torch.FloatTensor(reward).unsqueeze(1).to(self.device)
        next_state = torch.FloatTensor(next_state).to(self.device)
        done = torch.FloatTensor(done).unsqueeze(1).to(self.device)

        # 更新Critic
        with torch.no_grad():
            next_action = self.actor_target(next_state)
            target_q = reward + (1 - done) * self.gamma * self.critic_target(next_state, next_action)

        current_q = self.critic(state, action)
        critic_loss = F.mse_loss(current_q, target_q)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # 更新Actor
        actor_loss = -self.critic(state, self.actor(state)).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # 软更新目标网络
        self._soft_update(self.actor, self.actor_target)
        self._soft_update(self.critic, self.critic_target)

        return {
            'actor_loss': actor_loss.item(),
            'critic_loss': critic_loss.item()
        }

    def _soft_update(self, source, target):
        for param, target_param in zip(source.parameters(), target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def store_transition(self, state, action, reward, next_state, done):
        self.replay_buffer.push(state, action, reward, next_state, done)


# ===================== SAC =====================

class SAC:
    """Soft Actor-Critic"""

    def __init__(self, state_dim: int, action_dim: int, device='cpu'):
        self.device = device
        self.action_dim = action_dim

        # 网络
        self.actor = GaussianActor(state_dim, action_dim).to(device)

        self.critic1 = Critic(state_dim, action_dim).to(device)
        self.critic1_target = Critic(state_dim, action_dim).to(device)
        self.critic1_target.load_state_dict(self.critic1.state_dict())

        self.critic2 = Critic(state_dim, action_dim).to(device)
        self.critic2_target = Critic(state_dim, action_dim).to(device)
        self.critic2_target.load_state_dict(self.critic2.state_dict())

        # 优化器
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=3e-4)
        self.critic1_optimizer = optim.Adam(self.critic1.parameters(), lr=3e-4)
        self.critic2_optimizer = optim.Adam(self.critic2.parameters(), lr=3e-4)

        # 温度参数
        self.log_alpha = torch.zeros(1, requires_grad=True, device=device)
        self.alpha_optimizer = optim.Adam([self.log_alpha], lr=1e-4)
        self.target_entropy = -action_dim

        # 超参数
        self.gamma = 0.95
        self.tau = 0.005

        # 经验回放
        self.replay_buffer = ReplayBuffer(100000)
        self.batch_size = 256

    def select_action(self, state, deterministic=False):
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            if deterministic:
                mean, _ = self.actor(state)
                action = torch.tanh(mean).cpu().numpy()[0]
            else:
                action, _ = self.actor.sample(state)
                action = action.cpu().numpy()[0]
        return action

    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return {}

        # 采样
        state, action, reward, next_state, done = self.replay_buffer.sample(self.batch_size)

        state = torch.FloatTensor(state).to(self.device)
        action = torch.FloatTensor(action).to(self.device)
        reward = torch.FloatTensor(reward).unsqueeze(1).to(self.device)
        next_state = torch.FloatTensor(next_state).to(self.device)
        done = torch.FloatTensor(done).unsqueeze(1).to(self.device)

        alpha = self.log_alpha.exp()

        # 更新Critic
        with torch.no_grad():
            next_action, next_log_prob = self.actor.sample(next_state)
            target_q1 = self.critic1_target(next_state, next_action)
            target_q2 = self.critic2_target(next_state, next_action)
            target_q = torch.min(target_q1, target_q2) - alpha * next_log_prob
            target_q = reward + (1 - done) * self.gamma * target_q

        current_q1 = self.critic1(state, action)
        current_q2 = self.critic2(state, action)

        critic1_loss = F.mse_loss(current_q1, target_q)
        critic2_loss = F.mse_loss(current_q2, target_q)

        self.critic1_optimizer.zero_grad()
        critic1_loss.backward()
        self.critic1_optimizer.step()

        self.critic2_optimizer.zero_grad()
        critic2_loss.backward()
        self.critic2_optimizer.step()

        # 更新Actor
        new_action, log_prob = self.actor.sample(state)
        q1 = self.critic1(state, new_action)
        q2 = self.critic2(state, new_action)
        q = torch.min(q1, q2)

        actor_loss = (alpha * log_prob - q).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # 更新温度
        alpha_loss = -(self.log_alpha * (log_prob + self.target_entropy).detach()).mean()

        self.alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.alpha_optimizer.step()

        # 软更新目标网络
        self._soft_update(self.critic1, self.critic1_target)
        self._soft_update(self.critic2, self.critic2_target)

        return {
            'actor_loss': actor_loss.item(),
            'critic_loss': (critic1_loss + critic2_loss).item() / 2,
            'alpha': alpha.item()
        }

    def _soft_update(self, source, target):
        for param, target_param in zip(source.parameters(), target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def store_transition(self, state, action, reward, next_state, done):
        self.replay_buffer.push(state, action, reward, next_state, done)


# ===================== MADDPG =====================

class MADDPGAgent:
    """MADDPG单个智能体"""

    def __init__(self, state_dim: int, action_dim: int, n_agents: int, device='cpu'):
        self.device = device

        # Actor看自己状态
        self.actor = Actor(state_dim, action_dim).to(device)
        self.actor_target = Actor(state_dim, action_dim).to(device)
        self.actor_target.load_state_dict(self.actor.state_dict())

        # Critic看全局状态和所有动作
        self.critic = Critic(state_dim * n_agents, action_dim * n_agents).to(device)
        self.critic_target = Critic(state_dim * n_agents, action_dim * n_agents).to(device)
        self.critic_target.load_state_dict(self.critic.state_dict())

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=1e-4)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=3e-4)

    def _soft_update(self, source, target, tau=0.005):
        for param, target_param in zip(source.parameters(), target.parameters()):
            target_param.data.copy_(tau * param.data + (1 - tau) * target_param.data)


class MADDPG:
    """Multi-Agent DDPG"""

    def __init__(self, state_dim: int, action_dim: int, n_agents: int, device='cpu'):
        self.n_agents = n_agents
        self.device = device

        # 创建多个智能体
        self.agents = [MADDPGAgent(state_dim, action_dim, n_agents, device)
                       for _ in range(n_agents)]

        # 共享经验回放
        self.replay_buffer = ReplayBuffer(100000)
        self.batch_size = 256

        # 超参数
        self.gamma = 0.97
        self.noise_std = 0.2

    def select_action(self, states, add_noise=True):
        """选择所有智能体的动作"""
        actions = []
        for agent, state in zip(self.agents, states):
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            with torch.no_grad():
                action = agent.actor(state_tensor).cpu().numpy()[0]

            if add_noise:
                noise = np.random.normal(0, self.noise_std, size=action.shape)
                action = np.clip(action + noise, -1, 1)

            actions.append(action)

        return np.array(actions)

    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return {}

        # 采样
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.batch_size)

        states = torch.FloatTensor(states).to(self.device)
        actions = torch.FloatTensor(actions).to(self.device)
        rewards = torch.FloatTensor(rewards).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).to(self.device)

        total_loss = {'actor_loss': 0, 'critic_loss': 0}

        for agent_id, agent in enumerate(self.agents):
            # 全局状态和动作
            global_states = states.reshape(self.batch_size, -1)
            global_actions = actions.reshape(self.batch_size, -1)
            global_next_states = next_states.reshape(self.batch_size, -1)

            # 更新Critic
            with torch.no_grad():
                next_actions = []
                for i, a in enumerate(self.agents):
                    next_actions.append(a.actor_target(next_states[:, i, :]))
                next_actions = torch.cat(next_actions, dim=1)

                target_q = agent.critic_target(global_next_states, next_actions)
                target_q = rewards[:, agent_id].unsqueeze(1) + (1 - dones[:, agent_id].unsqueeze(1)) * self.gamma * target_q

            current_q = agent.critic(global_states, global_actions)
            critic_loss = F.mse_loss(current_q, target_q)

            agent.critic_optimizer.zero_grad()
            critic_loss.backward()
            agent.critic_optimizer.step()

            # 更新Actor
            current_actions = []
            for i, a in enumerate(self.agents):
                if i == agent_id:
                    current_actions.append(agent.actor(states[:, i, :]))
                else:
                    current_actions.append(a.actor(states[:, i, :]).detach())

            current_actions = torch.cat(current_actions, dim=1)
            actor_loss = -agent.critic(global_states, current_actions).mean()

            agent.actor_optimizer.zero_grad()
            actor_loss.backward()
            agent.actor_optimizer.step()

            # 软更新
            agent._soft_update(agent.actor, agent.actor_target)
            agent._soft_update(agent.critic, agent.critic_target)

            total_loss['actor_loss'] += actor_loss.item()
            total_loss['critic_loss'] += critic_loss.item()

        total_loss['actor_loss'] /= self.n_agents
        total_loss['critic_loss'] /= self.n_agents

        return total_loss

    def store_transition(self, states, actions, rewards, next_states, dones):
        """存储转移"""
        self.replay_buffer.push(states, actions, rewards, next_states, dones)


# ===================== MAPPO (修复经验池问题 v2) =====================

class PPOActor(nn.Module):
    """PPO Actor网络"""

    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.mean = nn.Linear(hidden_dim, action_dim)
        self.log_std = nn.Parameter(torch.zeros(action_dim))

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        mean = torch.tanh(self.mean(x))
        std = self.log_std.exp().expand_as(mean)
        return mean, std

    def get_action(self, state):
        mean, std = self.forward(state)
        dist = torch.distributions.Normal(mean, std)
        action = dist.sample()
        log_prob = dist.log_prob(action).sum(dim=-1)
        return torch.clamp(action, -1, 1), log_prob


class PPOCritic(nn.Module):
    """PPO Critic网络"""

    def __init__(self, state_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, 1)

    def forward(self, state):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        return self.fc3(x)


class MAPPO:
    """Multi-Agent PPO (修复经验池问题 v2)

    关键修复：
    1. 降低min_batch_size从64到20（适配FIXED_STEPS=20）
    2. 每个episode结束后强制更新（无论buffer大小）
    3. 保持GAE、梯度裁剪等优化
    """

    def __init__(self, state_dim, action_dim, n_agents, device='cpu'):
        self.n_agents = n_agents
        self.device = device
        self.state_dim = state_dim

        # Actor：去中心化
        self.actors = [PPOActor(state_dim, action_dim).to(device) for _ in range(n_agents)]
        self.actor_optimizers = [optim.Adam(actor.parameters(), lr=3e-4) for actor in self.actors]

        # ✅ Critic：中心化（输入全局状态）
        global_state_dim = state_dim * n_agents
        self.critics = [PPOCritic(global_state_dim).to(device) for _ in range(n_agents)]
        self.critic_optimizers = [optim.Adam(critic.parameters(), lr=1e-4) for critic in self.critics]

        # 超参数
        self.gamma = 0.97
        self.lam = 0.97
        self.clip_epsilon = 0.2
        self.value_coef = 0.5
        self.entropy_coef = 0.01
        self.max_grad_norm = 0.5

        self.buffer = []
        self.min_batch_size = 20
        self.update_epochs = 5  # ✅ 固定epoch数

    def select_action(self, states):
        """选择所有智能体的动作"""
        actions = []
        log_probs = []

        for agent_id, (actor, state) in enumerate(zip(self.actors, states)):
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            with torch.no_grad():
                action, log_prob = actor.get_action(state_tensor)
            actions.append(action.cpu().numpy()[0])
            log_probs.append(log_prob.item())

        return np.array(actions), np.array(log_probs)

    def store_transition(self, states, actions, rewards, next_states, dones, log_probs):
        """存储转移"""
        self.buffer.append((states, actions, rewards, next_states, dones, log_probs))

    def update(self, force_update=False):
        """优化后的更新逻辑"""

        if not force_update and len(self.buffer) < self.min_batch_size:
            return {}
        if len(self.buffer) < 5:
            return {}

        # 提取数据
        states, actions, rewards, next_states, dones, old_log_probs = zip(*self.buffer)
        states = np.array(states)  # [T, n_agents, state_dim]
        actions = np.array(actions)
        rewards = np.array(rewards)
        dones = np.array(dones)
        old_log_probs = np.array(old_log_probs)

        T = len(self.buffer)

        # ✅ 构造全局状态
        global_states = states.reshape(T, -1)  # [T, state_dim * n_agents]

        # 为每个agent计算GAE
        returns_list = []
        advantages_list = []
        old_values_list = []

        for agent_id in range(self.n_agents):
            agent_rewards = rewards[:, agent_id]
            agent_dones = dones[:, agent_id]

            # ✅ 使用全局状态计算value
            with torch.no_grad():
                values = self.critics[agent_id](
                    torch.FloatTensor(global_states).to(self.device)
                ).cpu().numpy().flatten()

            old_values_list.append(values)

            # GAE计算
            agent_advantages = np.zeros(T)
            agent_returns = np.zeros(T)
            gae = 0

            for t in reversed(range(T)):
                next_value = 0 if t == T - 1 else values[t + 1]
                delta = agent_rewards[t] + self.gamma * next_value * (1 - agent_dones[t]) - values[t]
                gae = delta + self.gamma * self.lam * (1 - agent_dones[t]) * gae
                agent_advantages[t] = gae
                agent_returns[t] = gae + values[t]

            returns_list.append(agent_returns)
            advantages_list.append(agent_advantages)

        returns = np.array(returns_list).T  # [T, n_agents]
        advantages = np.array(advantages_list).T
        old_values = np.array(old_values_list).T

        # ✅ 全局标准化
        adv_mean = advantages.mean()
        adv_std = advantages.std()
        if adv_std > 1e-8:
            advantages = (advantages - adv_mean) / (adv_std + 1e-8)

        total_loss = {'actor_loss': 0, 'critic_loss': 0, 'entropy': 0}

        # PPO更新
        for epoch in range(self.update_epochs):
            for agent_id in range(self.n_agents):
                # Actor更新
                state_tensor = torch.FloatTensor(states[:, agent_id]).to(self.device)
                action_tensor = torch.FloatTensor(actions[:, agent_id]).to(self.device)
                old_log_prob_tensor = torch.FloatTensor(old_log_probs[:, agent_id]).to(self.device)
                advantage_tensor = torch.FloatTensor(advantages[:, agent_id]).to(self.device)

                mean, std = self.actors[agent_id](state_tensor)
                dist = torch.distributions.Normal(mean, std)
                new_log_prob = dist.log_prob(action_tensor).sum(dim=-1)

                ratio = torch.exp(new_log_prob - old_log_prob_tensor)
                surr1 = ratio * advantage_tensor
                surr2 = torch.clamp(ratio, 1 - self.clip_epsilon, 1 + self.clip_epsilon) * advantage_tensor
                actor_loss = -torch.min(surr1, surr2).mean()

                entropy = dist.entropy().sum(dim=-1).mean()
                actor_loss = actor_loss - self.entropy_coef * entropy

                self.actor_optimizers[agent_id].zero_grad()
                actor_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.actors[agent_id].parameters(), self.max_grad_norm)
                self.actor_optimizers[agent_id].step()

                # ✅ Critic更新：使用全局状态 + value clipping
                global_states_tensor = torch.FloatTensor(global_states).to(self.device)
                agent_returns_tensor = torch.FloatTensor(returns[:, agent_id:agent_id + 1]).to(self.device)
                old_values_tensor = torch.FloatTensor(old_values[:, agent_id:agent_id + 1]).to(self.device)

                values_pred = self.critics[agent_id](global_states_tensor)

                # Value clipping
                values_clipped = old_values_tensor + torch.clamp(
                    values_pred - old_values_tensor,
                    -self.clip_epsilon,
                    self.clip_epsilon
                )

                loss1 = F.mse_loss(values_pred, agent_returns_tensor, reduction='none')
                loss2 = F.mse_loss(values_clipped, agent_returns_tensor, reduction='none')
                critic_loss = 0.5 * torch.max(loss1, loss2).mean()

                self.critic_optimizers[agent_id].zero_grad()
                critic_loss.backward()
                torch.nn.utils.clip_grad_norm_(self.critics[agent_id].parameters(), self.max_grad_norm)
                self.critic_optimizers[agent_id].step()

                total_loss['actor_loss'] += actor_loss.item()
                total_loss['critic_loss'] += critic_loss.item()
                total_loss['entropy'] += entropy.item()

        total_loss['actor_loss'] /= (self.update_epochs * self.n_agents)
        total_loss['critic_loss'] /= (self.update_epochs * self.n_agents)
        total_loss['entropy'] /= (self.update_epochs * self.n_agents)

        self.buffer = []
        return total_loss


# ===================== 算法工厂 =====================

def create_algorithm(algo_name: str, state_dim: int, action_dim: int,
                     n_agents: int = 1, device='cpu'):
    """创建算法实例"""
    algo_name = algo_name.upper()

    if algo_name == 'DDPG':
        return DDPG(state_dim, action_dim, device)
    elif algo_name == 'SAC':
        return SAC(state_dim, action_dim, device)
    elif algo_name == 'MADDPG':
        return MADDPG(state_dim, action_dim, n_agents, device)
    elif algo_name == 'MAPPO':
        return MAPPO(state_dim, action_dim, n_agents, device)
    else:
        raise ValueError(f"Unknown algorithm: {algo_name}")