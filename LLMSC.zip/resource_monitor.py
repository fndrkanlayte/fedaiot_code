"""
resource_monitor.py - 资源使用监控和可视化
"""
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List


class ResourceMonitor:
    """资源监控器"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.compute_resources_used = 0.0
        self.comm_resources_used = 0.0
        self.energy_consumed = 0.0
        self.waiting_time = 0.0
        self.processing_time = 0.0
        self.transmission_time = 0.0
        self.task_count = 0

        self.compute_history = []
        self.comm_history = []
        self.energy_history = []
        self.waiting_history = []

    def record_task(self, compute_used: float, comm_used: float,
                    energy_used: float, waiting_time: float,
                    processing_time: float, transmission_time: float):
        """记录任务资源使用"""
        self.compute_resources_used += compute_used
        self.comm_resources_used += comm_used
        self.energy_consumed += energy_used
        self.waiting_time += waiting_time
        self.processing_time += processing_time
        self.transmission_time += transmission_time
        self.task_count += 1

        self.compute_history.append(compute_used)
        self.comm_history.append(comm_used)
        self.energy_history.append(energy_used)
        self.waiting_history.append(waiting_time)

    def get_average_metrics(self) -> Dict[str, float]:
        """获取平均指标"""
        if self.task_count == 0:
            return {
                'avg_compute': 0.0, 'avg_comm': 0.0, 'avg_energy': 0.0,
                'avg_waiting_time': 0.0, 'avg_processing_time': 0.0,
                'avg_transmission_time': 0.0, 'total_energy': 0.0
            }

        return {
            'avg_compute': self.compute_resources_used / self.task_count,
            'avg_comm': self.comm_resources_used / self.task_count,
            'avg_energy': self.energy_consumed / self.task_count,
            'avg_waiting_time': self.waiting_time / self.task_count,
            'avg_processing_time': self.processing_time / self.task_count,
            'avg_transmission_time': self.transmission_time / self.task_count,
            'total_energy': self.energy_consumed
        }

    def plot_resource_usage(self, save_path: str = None):
        """绘制资源使用图"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))

        axes[0, 0].plot(self.compute_history, 'b-', alpha=0.7)
        axes[0, 0].set_title('计算资源使用 (MIPS)')
        axes[0, 0].set_xlabel('任务编号')
        axes[0, 0].set_ylabel('MIPS')
        axes[0, 0].grid(True, alpha=0.3)

        axes[0, 1].plot(self.comm_history, 'g-', alpha=0.7)
        axes[0, 1].set_title('通信资源使用 (MB)')
        axes[0, 1].set_xlabel('任务编号')
        axes[0, 1].set_ylabel('MB')
        axes[0, 1].grid(True, alpha=0.3)

        axes[1, 0].plot(self.energy_history, 'r-', alpha=0.7)
        axes[1, 0].set_title('能量消耗 (Joules)')
        axes[1, 0].set_xlabel('任务编号')
        axes[1, 0].set_ylabel('Joules')
        axes[1, 0].grid(True, alpha=0.3)

        axes[1, 1].plot(self.waiting_history, 'm-', alpha=0.7)
        axes[1, 1].set_title('等待时间 (seconds)')
        axes[1, 1].set_xlabel('任务编号')
        axes[1, 1].set_ylabel('Seconds')
        axes[1, 1].grid(True, alpha=0.3)

        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()