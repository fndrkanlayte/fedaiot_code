"""
Diffusion model implementation for data recovery in semantic communication
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional, Tuple
import math

class SinusoidalPositionEmbeddings(nn.Module):
    """Sinusoidal position embeddings for timesteps"""
    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim

    def forward(self, time: torch.Tensor) -> torch.Tensor:
        device = time.device
        half_dim = self.dim // 2
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        embeddings = time[:, None] * embeddings[None, :]
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        return embeddings

class ResidualBlock(nn.Module):
    """Residual block with time embedding"""
    def __init__(self, in_channels: int, out_channels: int, time_emb_dim: int, dropout: float = 0.1):
        super().__init__()
        self.time_mlp = nn.Linear(time_emb_dim, out_channels)
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1)
        self.dropout = nn.Dropout(dropout)
        self.norm1 = nn.GroupNorm(8, out_channels)
        self.norm2 = nn.GroupNorm(8, out_channels)
        
        if in_channels != out_channels:
            self.shortcut = nn.Conv2d(in_channels, out_channels, 1)
        else:
            self.shortcut = nn.Identity()

    def forward(self, x: torch.Tensor, time_emb: torch.Tensor) -> torch.Tensor:
        h = self.norm1(self.conv1(x))
        h = h + self.time_mlp(time_emb)[:, :, None, None]
        h = F.relu(h)
        h = self.dropout(h)
        h = self.norm2(self.conv2(h))
        h = F.relu(h)
        return h + self.shortcut(x)

class UNet(nn.Module):
    """UNet architecture for diffusion model"""
    def __init__(self, 
                 in_channels: int = 3,
                 out_channels: int = 3,
                 time_emb_dim: int = 128,
                 model_channels: int = 128,
                 num_res_blocks: int = 2,
                 attention_resolutions: Tuple[int, ...] = (16, 8),
                 dropout: float = 0.1):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.time_emb_dim = time_emb_dim
        self.model_channels = model_channels
        
        # Time embedding
        self.time_embed = nn.Sequential(
            SinusoidalPositionEmbeddings(time_emb_dim),
            nn.Linear(time_emb_dim, time_emb_dim),
            nn.ReLU()
        )
        
        # Input projection
        self.input_proj = nn.Conv2d(in_channels, model_channels, 3, padding=1)
        
        # Downsampling
        self.down_blocks = nn.ModuleList()
        self.down_samples = nn.ModuleList()
        
        ch = model_channels
        for i in range(3):  # 3 downsampling levels
            for _ in range(num_res_blocks):
                self.down_blocks.append(ResidualBlock(ch, ch, time_emb_dim, dropout))
            self.down_samples.append(nn.Conv2d(ch, ch, 3, stride=2, padding=1))
            ch *= 2
        
        # Middle
        self.middle_block1 = ResidualBlock(ch, ch, time_emb_dim, dropout)
        self.middle_block2 = ResidualBlock(ch, ch, time_emb_dim, dropout)
        
        # Upsampling
        self.up_blocks = nn.ModuleList()
        self.up_samples = nn.ModuleList()
        
        for i in range(3):  # 3 upsampling levels
            ch //= 2
            for _ in range(num_res_blocks):
                self.up_blocks.append(ResidualBlock(ch * 2, ch, time_emb_dim, dropout))
            self.up_samples.append(nn.ConvTranspose2d(ch, ch, 3, stride=2, padding=1, output_padding=1))
        
        # Output
        self.output = nn.Conv2d(model_channels, out_channels, 3, padding=1)

    def forward(self, x: torch.Tensor, timesteps: torch.Tensor) -> torch.Tensor:
        # Time embedding
        t_emb = self.time_embed(timesteps)
        
        # Input projection
        h = self.input_proj(x)
        
        # Downsampling
        down_hs = []
        for i, (block, sample) in enumerate(zip(self.down_blocks, self.down_samples)):
            if i % 2 == 0:  # Every 2 blocks, we have a residual block
                h = block(h, t_emb)
                down_hs.append(h)
            else:
                h = sample(h)
        
        # Middle
        h = self.middle_block1(h, t_emb)
        h = self.middle_block2(h, t_emb)
        
        # Upsampling
        for i, (block, sample) in enumerate(zip(self.up_blocks, self.up_samples)):
            if i % 2 == 0:  # Every 2 blocks, we have a residual block
                h = torch.cat([h, down_hs.pop()], dim=1)
                h = block(h, t_emb)
            else:
                h = sample(h)
        
        # Output
        return self.output(h)

class DiffusionModel(nn.Module):
    """Diffusion model for data recovery"""
    def __init__(self, 
                 in_channels: int = 3,
                 out_channels: int = 3,
                 num_timesteps: int = 1000,
                 beta_start: float = 0.0001,
                 beta_end: float = 0.02,
                 beta_schedule: str = 'linear',
                 prediction_type: str = 'epsilon',
                 loss_type: str = 'mse'):
        super().__init__()
        self.num_timesteps = num_timesteps
        self.prediction_type = prediction_type
        self.loss_type = loss_type
        
        # UNet model
        self.unet = UNet(in_channels=in_channels, out_channels=out_channels)
        
        # Noise schedule
        if beta_schedule == 'linear':
            self.betas = torch.linspace(beta_start, beta_end, num_timesteps)
        elif beta_schedule == 'cosine':
            self.betas = self._cosine_beta_schedule(num_timesteps, beta_start, beta_end)
        else:
            raise ValueError(f"Unknown beta schedule: {beta_schedule}")
        
        self.alphas = 1.0 - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        self.alphas_cumprod_prev = F.pad(self.alphas_cumprod[:-1], (1, 0), value=1.0)
        
        # Calculations for diffusion q(x_t | x_{t-1}) and others
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1.0 - self.alphas_cumprod)
        
        # Calculations for posterior q(x_{t-1} | x_t, x_0)
        self.posterior_variance = self.betas * (1.0 - self.alphas_cumprod_prev) / (1.0 - self.alphas_cumprod)

    def _cosine_beta_schedule(self, timesteps: int, s: float = 0.008) -> torch.Tensor:
        """Cosine beta schedule"""
        steps = timesteps + 1
        x = torch.linspace(0, timesteps, steps)
        alphas_cumprod = torch.cos(((x / timesteps) + s) / (1 + s) * torch.pi * 0.5) ** 2
        alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
        betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
        return torch.clip(betas, 0.0001, 0.9999)

    def q_sample(self, x_start: torch.Tensor, t: torch.Tensor, noise: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """Sample from q(x_t | x_0)"""
        if noise is None:
            noise = torch.randn_like(x_start)
        
        sqrt_alphas_cumprod_t = self.sqrt_alphas_cumprod[t].reshape(-1, 1, 1, 1)
        sqrt_one_minus_alphas_cumprod_t = self.sqrt_one_minus_alphas_cumprod[t].reshape(-1, 1, 1, 1)
        
        return sqrt_alphas_cumprod_t * x_start + sqrt_one_minus_alphas_cumprod_t * noise, noise

    def p_sample(self, x: torch.Tensor, t: torch.Tensor, t_index: int) -> torch.Tensor:
        """从p(x_{t-1} | x_t)采样"""
        device = x.device

        # 确保所有张量在同一设备
        betas_t = self.betas[t].to(device).reshape(-1, 1, 1, 1)
        sqrt_one_minus_alphas_cumprod_t = self.sqrt_one_minus_alphas_cumprod[t].to(device).reshape(-1, 1, 1, 1)
        sqrt_recip_alphas_t = torch.sqrt(1.0 / self.alphas[t]).to(device).reshape(-1, 1, 1, 1)

        # 预测噪声
        model_output = self.unet(x, t)

        if self.prediction_type == 'epsilon':
            pred_x_start = sqrt_recip_alphas_t * (x - betas_t * model_output / sqrt_one_minus_alphas_cumprod_t)
        else:
            pred_x_start = model_output

        if t_index == 0:
            return pred_x_start
        else:
            posterior_variance_t = self.posterior_variance[t].to(device).reshape(-1, 1, 1, 1)
            noise = torch.randn_like(x)
            return pred_x_start + torch.sqrt(posterior_variance_t) * noise

    def p_sample_loop(self, shape: Tuple[int, ...], device: torch.device) -> torch.Tensor:
        """Generate samples by iteratively sampling from p(x_{t-1} | x_t)"""
        b = shape[0]
        # Start from pure noise
        img = torch.randn(shape, device=device)
        
        for i in reversed(range(self.num_timesteps)):
            t = torch.full((b,), i, device=device, dtype=torch.long)
            img = self.p_sample(img, t, i)
        
        return img

    def sample(self, batch_size: int, device: torch.device) -> torch.Tensor:
        """Generate samples"""
        return self.p_sample_loop((batch_size, self.unet.in_channels, 32, 32), device)

    def forward(self, x: torch.Tensor, noise: Optional[torch.Tensor] = None) -> torch.Tensor:
        """Training forward pass"""
        batch_size = x.shape[0]
        device = x.device
        
        # Sample random timesteps
        t = torch.randint(0, self.num_timesteps, (batch_size,), device=device).long()
        
        # Sample noise
        if noise is None:
            noise = torch.randn_like(x)
        
        # Add noise to x
        x_noisy, _ = self.q_sample(x, t, noise)
        
        # Predict noise
        predicted_noise = self.unet(x_noisy, t)
        
        if self.loss_type == 'mse':
            loss = F.mse_loss(noise, predicted_noise)
        elif self.loss_type == 'l1':
            loss = F.l1_loss(noise, predicted_noise)
        else:
            raise ValueError(f"Unknown loss type: {self.loss_type}")
        
        return loss

    def recover_data(self, corrupted_data: torch.Tensor, num_steps: int = 100) -> torch.Tensor:
        """恢复数据"""
        device = corrupted_data.device
        batch_size = corrupted_data.shape[0]

        # 确保所有缓存的张量都在正确的设备上
        if not hasattr(self, '_device_checked'):
            self.betas = self.betas.to(device)
            self.alphas = self.alphas.to(device)
            self.alphas_cumprod = self.alphas_cumprod.to(device)
            self.sqrt_alphas_cumprod = self.sqrt_alphas_cumprod.to(device)
            self.sqrt_one_minus_alphas_cumprod = self.sqrt_one_minus_alphas_cumprod.to(device)
            self.posterior_variance = self.posterior_variance.to(device)
            self._device_checked = True

        x = corrupted_data.clone()

        # 反向扩散过程
        for i in reversed(range(0, self.num_timesteps, self.num_timesteps // num_steps)):
            t = torch.full((batch_size,), i, device=device, dtype=torch.long)
            x = self.p_sample(x, t, i)

        return x
