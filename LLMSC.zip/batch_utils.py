"""
batch_utils.py - 批次数据处理工具
处理混合模态批次（文本+图像）
"""
import torch
from typing import List, Tuple, Dict


def separate_mixed_batch(data: List,
                         labels: torch.Tensor,
                         texts: List[str],
                         metadata: List[Dict]) -> Tuple[Dict, Dict]:
    """
    分离混合批次为文本批次和图像批次

    Args:
        data: 数据列表（包含文本token_ids和图像tensor）
        labels: 标签tensor
        texts: 文本列表
        metadata: 元数据列表

    Returns:
        text_batch: 文本批次字典
        image_batch: 图像批次字典
    """
    text_indices = []
    image_indices = []

    # 找出文本和图像的索引
    for i, meta in enumerate(metadata):
        if meta['type'] == 'text':
            text_indices.append(i)
        else:
            image_indices.append(i)

    # 分离文本批次
    text_batch = None
    if text_indices:
        text_data = [data[i] for i in text_indices]
        text_labels = labels[text_indices]
        text_texts = [texts[i] for i in text_indices]
        text_metadata = [metadata[i] for i in text_indices]

        # Stack文本数据
        text_data_stacked = torch.stack(text_data)

        text_batch = {
            'data': text_data_stacked,
            'labels': text_labels,
            'texts': text_texts,
            'metadata': text_metadata,
            'indices': text_indices
        }

    # 分离图像批次
    image_batch = None
    if image_indices:
        image_data = [data[i] for i in image_indices]
        image_labels = labels[image_indices]
        image_texts = [texts[i] for i in image_indices]
        image_metadata = [metadata[i] for i in image_indices]

        # Stack图像数据
        image_data_stacked = torch.stack(image_data)

        image_batch = {
            'data': image_data_stacked,
            'labels': image_labels,
            'texts': image_texts,
            'metadata': image_metadata,
            'indices': image_indices
        }

    return text_batch, image_batch


def process_batch_for_encoding(data: List,
                               metadata: List[Dict],
                               device: torch.device = None) -> Tuple[torch.Tensor, torch.Tensor, str]:
    """
    为编码器准备批次数据

    Args:
        data: 数据列表
        metadata: 元数据列表
        device: 目标设备

    Returns:
        text_data: 文本数据tensor（如果有）
        image_data: 图像数据tensor（如果有）
        batch_type: 'text', 'image', or 'mixed'
    """
    if device is None:
        device = torch.device('cpu')

    # 检查批次类型
    types = [meta['type'] for meta in metadata]

    if all(t == 'text' for t in types):
        # 纯文本批次
        text_data = torch.stack(data).to(device)
        return text_data, None, 'text'

    elif all(t == 'image' for t in types):
        # 纯图像批次
        image_data = torch.stack(data).to(device)
        return None, image_data, 'image'

    else:
        # 混合批次 - 需要分离处理
        text_batch, image_batch = separate_mixed_batch(data, None, None, metadata)

        text_data = text_batch['data'].to(device) if text_batch else None
        image_data = image_batch['data'].to(device) if image_batch else None

        return text_data, image_data, 'mixed'


def merge_batch_results(text_results: Dict,
                        image_results: Dict,
                        original_batch_size: int,
                        text_indices: List[int],
                        image_indices: List[int]) -> List:
    """
    合并文本和图像的处理结果

    Args:
        text_results: 文本处理结果
        image_results: 图像处理结果
        original_batch_size: 原始批次大小
        text_indices: 文本样本的原始索引
        image_indices: 图像样本的原始索引

    Returns:
        merged_results: 按原始顺序合并的结果列表
    """
    merged = [None] * original_batch_size

    # 填充文本结果
    if text_results:
        for i, idx in enumerate(text_indices):
            merged[idx] = text_results[i]

    # 填充图像结果
    if image_results:
        for i, idx in enumerate(image_indices):
            merged[idx] = image_results[i]

    return merged


def get_batch_statistics(metadata: List[Dict]) -> Dict[str, int]:
    """
    获取批次统计信息

    Args:
        metadata: 元数据列表

    Returns:
        stats: 统计信息字典
    """
    stats = {
        'total': len(metadata),
        'text': sum(1 for m in metadata if m['type'] == 'text'),
        'image': sum(1 for m in metadata if m['type'] == 'image'),
        'nli': sum(1 for m in metadata if m.get('task') == 'nli'),
        'classification': sum(1 for m in metadata if m.get('task') == 'classification'),
    }

    stats['text_ratio'] = stats['text'] / stats['total'] if stats['total'] > 0 else 0
    stats['image_ratio'] = stats['image'] / stats['total'] if stats['total'] > 0 else 0

    return stats


# 示例用法
if __name__ == "__main__":
    print("批次处理工具测试\n")

    # 模拟混合批次
    data = [
        torch.randn(128),  # 文本
        torch.randn(3, 32, 32),  # 图像
        torch.randn(128),  # 文本
        torch.randn(3, 32, 32),  # 图像
    ]

    labels = torch.tensor([0, 1, 2, 3])
    texts = ["text1", "", "text2", ""]
    metadata = [
        {'type': 'text', 'task': 'nli'},
        {'type': 'image', 'task': 'classification'},
        {'type': 'text', 'task': 'nli'},
        {'type': 'image', 'task': 'classification'},
    ]

    # 测试分离
    print("=" * 60)
    print("测试批次分离")
    print("=" * 60)
    text_batch, image_batch = separate_mixed_batch(data, labels, texts, metadata)

    if text_batch:
        print(f"\n文本批次:")
        print(f"  数据形状: {text_batch['data'].shape}")
        print(f"  标签: {text_batch['labels']}")
        print(f"  索引: {text_batch['indices']}")

    if image_batch:
        print(f"\n图像批次:")
        print(f"  数据形状: {image_batch['data'].shape}")
        print(f"  标签: {image_batch['labels']}")
        print(f"  索引: {image_batch['indices']}")

    # 测试统计
    print("\n" + "=" * 60)
    print("批次统计")
    print("=" * 60)
    stats = get_batch_statistics(metadata)
    for key, value in stats.items():
        print(f"  {key}: {value}")

    print("\n✓ 批次工具测试完成")