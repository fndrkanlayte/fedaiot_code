"""
Main training and testing script for the multi-modal semantic communication task offloading system
"""
import os
import argparse
import torch
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import json
import wandb
from typing import Dict, List

from config import Config
from enhanced_task_offloading_system import TaskOffloadingSystem
from vehicle_dataset_handler import DatasetHandler

def setup_directories(config: Config):
    """Create necessary directories"""
    for path in config.PATHS.values():
        os.makedirs(path, exist_ok=True)

def setup_logging(config: Config, use_wandb: bool = True):
    """Setup logging and monitoring"""
    if use_wandb:
        wandb.init(
            project="multimodal-semantic-communication",
            config=vars(config),
            name=f"experiment_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )

def train_system(config: Config, 
                num_episodes: int = 1000,
                use_wandb: bool = True,
                save_models: bool = True):
    """Train the task offloading system"""
    print("=" * 50)
    print("Training Multi-Modal Semantic Communication Task Offloading System")
    print("=" * 50)
    
    # Setup
    setup_directories(config)
    setup_logging(config, use_wandb)
    
    # Initialize system
    system = TaskOffloadingSystem(config)
    
    # Load datasets
    print("Loading datasets...")
    dataset_handler = DatasetHandler(config)
    
    # Load text dataset
    text_dataset = dataset_handler.load_text_dataset(config.DATASET['text_dataset'])
    print(f"Loaded text dataset: {len(text_dataset)} samples")
    
    # Load image dataset
    image_dataset = dataset_handler.load_image_dataset(config.DATASET['image_dataset'])
    print(f"Loaded image dataset: {len(image_dataset)} samples")
    
    # Create multi-modal dataset
    multimodal_dataset = dataset_handler.create_multimodal_dataset(
        text_dataset, image_dataset
    )
    print(f"Created multi-modal dataset: {len(multimodal_dataset)} samples")
    
    # Training
    print("\nStarting training...")
    training_metrics = []
    
    for episode in range(num_episodes):
        # Train one episode
        system.train(1)  # Train one episode at a time
        
        # Get metrics
        metrics = system.get_system_status()
        training_metrics.append(metrics)
        
        # Log to wandb
        # 记录到wandb
        if use_wandb:
            wandb.log({
                'episode': episode,
                'reward': system.episode_rewards[-1] if system.episode_rewards else 0,
                'success_rate': system.success_rates[-1] if system.success_rates else 0,
                'semantic_accuracy': system.metrics['semantic_accuracy'],
                'avg_compression_rate': system.metrics['avg_compression_rate'],
                'current_snr': system.metrics['current_snr_db'],
            })
        
        # Print progress
        if episode % 100 == 0:
            print(f"Episode {episode}: Success Rate = {metrics['success_rate']:.2%}, "
                  f"Semantic Accuracy = {metrics['semantic_accuracy']:.4f}")
    print("\n生成可视化...")
    system.plot_training_curves(save_path='results/training_curves.png')
    system.resource_monitor.plot_resource_usage(save_path='results/resource_usage.png')

    # 打印详细报告
    print_summary_report(system)
    # Save final models
    if save_models:
        model_path = os.path.join(config.PATHS['model_dir'], 'final_models')
        system.save_models(model_path)
        print(f"Models saved to {model_path}")
    
    # Save training metrics
    metrics_path = os.path.join(config.PATHS['result_dir'], 'training_metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(training_metrics, f, indent=2)
    
    print("Training completed!")
    return system, training_metrics


def print_summary_report(system):
    """打印详细报告"""
    print("\n" + "=" * 80)
    print("任务卸载系统性能报告".center(80))
    print("=" * 80)

    print("\n【基本统计】")
    print(f"  总任务数: {system.metrics['total_tasks_processed']}")
    print(f"  成功卸载: {system.metrics['successful_offloads']}")
    print(f"  本地处理: {system.metrics['local_processing']}")

    print("\n【性能指标】")
    print(f"  语义准确度: {system.metrics['semantic_accuracy']:.4f}")
    print(f"  平均压缩率: {system.metrics['avg_compression_rate']:.2%}")
    print(f"  当前SNR: {system.metrics['current_snr_db']:.1f} dB")

    resource_metrics = system.resource_monitor.get_average_metrics()
    print("\n【资源消耗】")
    print(f"  平均计算: {resource_metrics['avg_compute']:.2f} MIPS")
    print(f"  平均通信: {resource_metrics['avg_comm']:.2f} MB")
    print(f"  总能量: {resource_metrics['total_energy']:.2f} J")

    print("\n【时间分析】")
    print(f"  平均等待: {resource_metrics['avg_waiting_time']:.3f} s")
    print(f"  平均处理: {resource_metrics['avg_processing_time']:.3f} s")

    print("\n" + "=" * 80)

def evaluate_system(system: TaskOffloadingSystem, 
                   config: Config,
                   num_tasks: int = 1000):
    """Evaluate the trained system"""
    print("\n" + "=" * 50)
    print("Evaluating System Performance")
    print("=" * 50)
    
    # Load datasets for evaluation
    dataset_handler = DatasetHandler(config)
    text_dataset = dataset_handler.load_text_dataset(config.DATASET['text_dataset'])
    image_dataset = dataset_handler.load_image_dataset(config.DATASET['image_dataset'])
    multimodal_dataset = dataset_handler.create_multimodal_dataset(text_dataset, image_dataset)
    
    # Evaluate
    evaluation_results = system.evaluate(num_tasks)
    
    # Print results
    print("\nEvaluation Results:")
    print("-" * 30)
    for metric, value in evaluation_results.items():
        if isinstance(value, float):
            print(f"{metric}: {value:.4f}")
        else:
            print(f"{metric}: {value}")
    
    # Save results
    results_path = os.path.join(config.PATHS['result_dir'], 'evaluation_results.json')
    with open(results_path, 'w') as f:
        json.dump(evaluation_results, f, indent=2)
    
    return evaluation_results

def plot_training_metrics(training_metrics: List[Dict], 
                         config: Config):
    """Plot training metrics"""
    print("Generating training plots...")
    
    # Extract metrics
    episodes = list(range(len(training_metrics)))
    success_rates = [m['success_rate'] for m in training_metrics]
    semantic_accuracies = [m['semantic_accuracy'] for m in training_metrics]
    total_tasks = [m['total_tasks_processed'] for m in training_metrics]
    
    # Create plots
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Success rate
    axes[0, 0].plot(episodes, success_rates)
    axes[0, 0].set_title('Success Rate Over Time')
    axes[0, 0].set_xlabel('Episode')
    axes[0, 0].set_ylabel('Success Rate')
    axes[0, 0].grid(True)
    
    # Semantic accuracy
    axes[0, 1].plot(episodes, semantic_accuracies)
    axes[0, 1].set_title('Semantic Accuracy Over Time')
    axes[0, 1].set_xlabel('Episode')
    axes[0, 1].set_ylabel('Semantic Accuracy')
    axes[0, 1].grid(True)
    
    # Total tasks processed
    axes[1, 0].plot(episodes, total_tasks)
    axes[1, 0].set_title('Total Tasks Processed Over Time')
    axes[1, 0].set_xlabel('Episode')
    axes[1, 0].set_ylabel('Total Tasks')
    axes[1, 0].grid(True)
    
    # Combined metrics
    axes[1, 1].plot(episodes, success_rates, label='Success Rate')
    axes[1, 1].plot(episodes, semantic_accuracies, label='Semantic Accuracy')
    axes[1, 1].set_title('Combined Metrics')
    axes[1, 1].set_xlabel('Episode')
    axes[1, 1].set_ylabel('Value')
    axes[1, 1].legend()
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    
    # Save plot
    plot_path = os.path.join(config.PATHS['result_dir'], 'training_metrics.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    print(f"Training plots saved to {plot_path}")
    
    plt.show()

def run_ablation_study(config: Config):
    """Run ablation study to evaluate different components"""
    print("\n" + "=" * 50)
    print("Running Ablation Study")
    print("=" * 50)
    
    # Test different configurations
    configs = {
        'baseline': config,
        'no_modality_conversion': Config(),
        'no_semantic_compression': Config(),
        'no_diffusion_recovery': Config()
    }
    
    # Modify configs for ablation
    configs['no_modality_conversion'].SEMANTIC['compression_ratio'] = 1.0  # No compression
    configs['no_semantic_compression'].SEMANTIC['compression_ratio'] = 1.0
    configs['no_diffusion_recovery'].DIFFUSION['num_timesteps'] = 1  # No diffusion
    
    results = {}
    
    for name, test_config in configs.items():
        print(f"\nTesting {name}...")
        
        # Create system with test config
        system = TaskOffloadingSystem(test_config)
        
        # Quick training (reduced episodes for ablation)
        system.train(100)
        
        # Evaluate
        eval_results = system.evaluate(100)
        results[name] = eval_results
        
        print(f"{name} - Success Rate: {eval_results['success_rate']:.2%}")
    
    # Save ablation results
    ablation_path = os.path.join(config.PATHS['result_dir'], 'ablation_study.json')
    with open(ablation_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"Ablation study results saved to {ablation_path}")
    return results

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description='Multi-Modal Semantic Communication Task Offloading System')
    parser.add_argument('--mode', type=str, choices=['train', 'eval', 'ablation'], 
                       default='train', help='Mode to run')
    parser.add_argument('--episodes', type=int, default=1000, 
                       help='Number of training episodes')
    parser.add_argument('--eval_tasks', type=int, default=1000, 
                       help='Number of tasks for evaluation')
    parser.add_argument('--use_wandb', action='store_true', 
                       help='Use Weights & Biases for logging')
    parser.add_argument('--model_path', type=str, default=None, 
                       help='Path to load pre-trained models')
    parser.add_argument('--config_path', type=str, default=None, 
                       help='Path to custom config file')
    
    args = parser.parse_args()
    
    # Load config
    if args.config_path:
        config = Config()
        # Load custom config (simplified)
        print(f"Loading custom config from {args.config_path}")
    else:
        config = Config()
    
    # Set device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    if args.mode == 'train':
        # Training mode
        system, training_metrics = train_system(
            config, 
            num_episodes=args.episodes,
            use_wandb=args.use_wandb
        )
        
        # Plot metrics
        plot_training_metrics(training_metrics, config)
        
        # Evaluate
        evaluation_results = evaluate_system(system, config, args.eval_tasks)
        
    elif args.mode == 'eval':
        # Evaluation mode
        if args.model_path is None:
            raise ValueError("Model path must be provided for evaluation mode")
        
        system = TaskOffloadingSystem(config)
        system.load_models(args.model_path)
        
        evaluation_results = evaluate_system(system, config, args.eval_tasks)
        
    elif args.mode == 'ablation':
        # Ablation study mode
        ablation_results = run_ablation_study(config)
        
        # Print comparison
        print("\nAblation Study Results:")
        print("-" * 40)
        for name, results in ablation_results.items():
            print(f"{name}: Success Rate = {results['success_rate']:.2%}, "
                  f"Semantic Accuracy = {results['semantic_accuracy']:.4f}")
    
    print("\nDone!")

if __name__ == "__main__":
    main()

