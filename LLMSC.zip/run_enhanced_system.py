"""
run_enhanced_system.py - 运行增强的任务卸载系统

使用方法:
    python run_enhanced_system.py --mode train --episodes 500
    python run_enhanced_system.py --mode train --episodes 500 --no_semantic  # 不使用语义通信
    python run_enhanced_system.py --mode eval --model_path models/episode_500
    python run_enhanced_system.py --mode demo --model_path models/episode_500
"""
import argparse
import torch
import numpy as np
import os
import warnings
import json

warnings.filterwarnings('ignore')
from config import Config
from enhanced_task_offloading_system import EnhancedTaskOffloadingSystem


def save_metrics_report(system, save_path='results/metrics_report.json'):
    """保存详细的指标报告"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    # 计算统计指标
    episode_rewards = system.episode_rewards

    metrics_report = {
        'training_summary': {
            'total_episodes': len(episode_rewards),
            'total_tasks_processed': system.metrics['total_tasks_processed'],
            'successful_offloads': system.metrics['successful_offloads'],
            'failed_offloads': system.metrics['failed_offloads'],
            'local_processing': system.metrics['local_processing']
        },
        'reward_statistics': {
            'final_reward': float(episode_rewards[-1]) if episode_rewards else 0.0,
            'average_reward': float(np.mean(episode_rewards)) if episode_rewards else 0.0,
            'max_reward': float(np.max(episode_rewards)) if episode_rewards else 0.0,
            'min_reward': float(np.min(episode_rewards)) if episode_rewards else 0.0,
            'std_reward': float(np.std(episode_rewards)) if episode_rewards else 0.0,
            'last_10_avg': float(np.mean(episode_rewards[-10:])) if len(episode_rewards) >= 10 else 0.0,
            'last_50_avg': float(np.mean(episode_rewards[-50:])) if len(episode_rewards) >= 50 else 0.0
        },
        'quality_metrics': {
            'semantic_accuracy': {
                'final': float(system.metrics['semantic_accuracy']),
                'avg_text_similarity': float(system.metrics['avg_text_similarity']),
                'avg_image_similarity': float(system.metrics['avg_image_similarity'])
            },
            'task_performance': {
                'avg_nli_accuracy': float(system.metrics['avg_nli_accuracy']),
                'avg_detection_iou': float(system.metrics['avg_detection_iou']),
                'avg_detection_precision': float(system.metrics['avg_detection_precision']),
                'avg_detection_recall': float(system.metrics['avg_detection_recall']),
                'avg_detection_f1': float(system.metrics['avg_detection_f1'])
            },
            'reconstruction_quality': float(system.metrics['reconstruction_quality']),
            'avg_compression_rate': float(system.metrics['avg_compression_rate'])
        },
        'success_rate': {
            'final': float(system.success_rates[-1]) if system.success_rates else 0.0,
            'average': float(np.mean(system.success_rates)) if system.success_rates else 0.0
        },
        'modality_conversion': {
            'total_conversions': int(system.metrics['modality_conversions']),
            'image_to_text': int(system.metrics['image_to_text_conversions']),
            'text_to_image': int(system.metrics['modality_conversions'] - system.metrics['image_to_text_conversions'])
        },
        'best_performance': {
            'best_reward': float(system.best_reward),
            'best_semantic_accuracy': float(system.best_semantic_accuracy)
        }
    }

    # 保存资源使用统计
    if hasattr(system, 'resource_monitor'):
        resource_metrics = system.resource_monitor.get_average_metrics()
        metrics_report['resource_usage'] = {
            'avg_compute': float(resource_metrics['avg_compute']),
            'avg_comm': float(resource_metrics['avg_comm']),
            'avg_energy': float(resource_metrics['avg_energy']),
            'total_energy': float(resource_metrics['total_energy']),
            'avg_waiting_time': float(resource_metrics['avg_waiting_time']),
            'avg_processing_time': float(resource_metrics['avg_processing_time']),
            'avg_transmission_time': float(resource_metrics['avg_transmission_time'])
        }

    # 保存为JSON
    with open(save_path, 'w') as f:
        json.dump(metrics_report, f, indent=4)

    print(f"\n✓ 指标报告已保存至: {save_path}")

    # 打印关键指标总结
    print("\n" + "="*80)
    print("训练指标总结".center(80))
    print("="*80)
    print(f"\n【奖励统计】")
    print(f"  最终奖励: {metrics_report['reward_statistics']['final_reward']:.2f}")
    print(f"  平均奖励: {metrics_report['reward_statistics']['average_reward']:.2f}")
    print(f"  最佳奖励: {metrics_report['reward_statistics']['max_reward']:.2f}")
    print(f"  最近10轮平均: {metrics_report['reward_statistics']['last_10_avg']:.2f}")

    print(f"\n【质量指标】")
    print(f"  语义准确度: {metrics_report['quality_metrics']['semantic_accuracy']['final']:.4f}")
    print(f"  重建质量: {metrics_report['quality_metrics']['reconstruction_quality']:.4f}")
    print(f"  NLI准确度: {metrics_report['quality_metrics']['task_performance']['avg_nli_accuracy']:.4f}")
    print(f"  检测IoU: {metrics_report['quality_metrics']['task_performance']['avg_detection_iou']:.4f}")

    print(f"\n【成功率】")
    print(f"  最终成功率: {metrics_report['success_rate']['final']:.2%}")
    print(f"  平均成功率: {metrics_report['success_rate']['average']:.2%}")

    if 'resource_usage' in metrics_report:
        print(f"\n【资源使用】")
        print(f"  平均计算: {metrics_report['resource_usage']['avg_compute']:.2f} MIPS")
        print(f"  平均通信: {metrics_report['resource_usage']['avg_comm']:.2f} MB")
        print(f"  总能耗: {metrics_report['resource_usage']['total_energy']:.2f} J")

    print("="*80 + "\n")

    return metrics_report


def main():
    parser = argparse.ArgumentParser(description='增强的多模态语义通信任务卸载系统')
    parser.add_argument('--mode', type=str, choices=['train', 'eval', 'demo'],
                        default='train', help='运行模式')
    parser.add_argument('--episodes', type=int, default=500,
                        help='训练轮数')
    parser.add_argument('--eval_tasks', type=int, default=100,
                        help='评估任务数')
    parser.add_argument('--model_path', type=str, default=None,
                        help='模型路径(用于加载)')
    parser.add_argument('--snr', type=float, default=20.0,
                        help='信噪比(dB)')
    parser.add_argument('--compression', type=float, default=0.1,
                        help='压缩率')
    parser.add_argument('--save_plots', action='store_true',
                        help='保存训练曲线')
    parser.add_argument('--no_semantic', action='store_true',
                        help='不使用语义通信（纯任务卸载环境）')

    args = parser.parse_args()

    # 配置
    config = Config()
    config.SEMANTIC['initial_snr_db'] = args.snr
    config.SEMANTIC['compression_ratio'] = args.compression

    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    config.DEVICE = device
    print(f"\n使用设备: {device}")
    print(f"语义通信: {'关闭' if args.no_semantic else '开启'}")

    # 创建系统
    print("\n初始化系统...")
    system = EnhancedTaskOffloadingSystem(config)
    system.use_semantic = not args.no_semantic  # 设置是否使用语义通信

    if args.mode == 'train':
        print("\n" + "=" * 80)
        mode_text = "训练模式 (不使用语义通信)" if args.no_semantic else "训练模式 (使用语义通信)"
        print(mode_text.center(80))
        print("=" * 80)

        # 训练
        system.train(num_episodes=args.episodes)

        # 绘制训练曲线
        os.makedirs('results', exist_ok=True)
        system.plot_training_curves(save_path='results/training_curves.png')
        system.resource_monitor.plot_resource_usage(save_path='results/resource_usage.png')

        # 保存详细的指标报告
        save_metrics_report(system, 'results/metrics_report.json')

        # 保存模型
        os.makedirs('models', exist_ok=True)
        model_suffix = '_no_semantic' if args.no_semantic else '_with_semantic'
        system.save_models(f'models/final_model{model_suffix}')

        # 最终评估
        print("\n最终评估...")
        eval_results = system.evaluate(num_tasks=args.eval_tasks)

    elif args.mode == 'eval':
        print("\n" + "=" * 80)
        print("评估模式".center(80))
        print("=" * 80)

        if args.model_path is None:
            raise ValueError("评估模式需要提供 --model_path")

        # 加载模型
        system.load_models(args.model_path)

        # 评估
        eval_results = system.evaluate(num_tasks=args.eval_tasks)

        # 保存评估结果
        os.makedirs('results', exist_ok=True)
        with open('results/evaluation_results.json', 'w') as f:
            json.dump(eval_results, f, indent=2)
        print("\n✓ 评估结果已保存至: results/evaluation_results.json")

    elif args.mode == 'demo':
        print("\n" + "=" * 80)
        print("演示模式".center(80))
        print("=" * 80)

        if args.model_path:
            system.load_models(args.model_path)

        # 演示不同SNR下的性能
        print("\n【不同SNR下的性能测试】")
        snr_values = [5, 10, 15, 20, 25]

        for snr in snr_values:
            print(f"\n测试 SNR = {snr} dB...")
            system.set_snr(snr)

            # 评估少量任务
            results = system.evaluate(num_tasks=20)
            print(f"  语义准确度: {results['semantic_accuracy']:.4f}")
            print(f"  重建质量: {results['reconstruction_quality']:.4f}")

        # 演示重建效果
        print("\n\n【重建效果演示】")
        system.set_snr(20.0)
        if hasattr(system, 'demonstrate_reconstruction'):
            system.demonstrate_reconstruction(num_samples=5)

        # 模态转换统计
        print("\n\n【模态转换统计】")
        print(f"总转换次数: {system.metrics['modality_conversions']}")
        print(f"文本→图像: {system.metrics['text_to_image_conversions']}")
        print(f"图像→文本: {system.metrics['image_to_text_conversions']}")

    print("\n\n" + "=" * 80)
    print("程序执行完成!".center(80))
    print("=" * 80 + "\n")


def quick_test():
    """快速测试系统功能"""
    print("\n" + "=" * 80)
    print("快速功能测试".center(80))
    print("=" * 80 + "\n")

    # 创建配置
    config = Config()
    config.TRAINING['num_episodes'] = 10
    config.DATASET['use_subset'] = True
    config.DATASET['subset_size'] = 100

    # 创建系统
    system = EnhancedTaskOffloadingSystem(config)

    # 快速训练
    print("执行快速训练(10 episodes)...")
    system.train(num_episodes=10)

    # 快速评估
    print("\n执行快速评估...")
    results = system.evaluate(num_tasks=10)

    print("\n✓ 快速测试完成!")
    print(f"  语义准确度: {results['semantic_accuracy']:.4f}")
    print(f"  重建质量: {results['reconstruction_quality']:.4f}")
    print(f"  成功率: {results['success_rate']:.2%}")


def compare_methods():
    """比较不同方法的性能"""
    print("\n" + "=" * 80)
    print("方法对比实验".center(80))
    print("=" * 80 + "\n")

    config = Config()
    config.TRAINING['num_episodes'] = 50
    config.DATASET['use_subset'] = True
    config.DATASET['subset_size'] = 500

    methods = {
        '增强系统(扩散Actor + 预训练解码器)': {},
        '基础系统(无扩散Actor)': {'use_diffusion': False},
        '无预训练增强': {'use_pretrained': False},
    }

    results = {}

    for method_name, modifications in methods.items():
        print(f"\n{'=' * 60}")
        print(f"测试方法: {method_name}")
        print('=' * 60)

        # 创建系统
        system = EnhancedTaskOffloadingSystem(config)

        # 训练
        system.train(num_episodes=50)

        # 评估
        eval_results = system.evaluate(num_tasks=50)
        results[method_name] = eval_results

        print(f"\n{method_name} 结果:")
        print(f"  语义准确度: {eval_results['semantic_accuracy']:.4f}")
        print(f"  重建质量: {eval_results['reconstruction_quality']:.4f}")
        print(f"  成功率: {eval_results['success_rate']:.2%}")

    # 打印对比表格
    print("\n\n" + "=" * 80)
    print("方法对比总结".center(80))
    print("=" * 80)
    print(f"\n{'方法':<40} {'语义准确度':<15} {'重建质量':<15} {'成功率':<10}")
    print("-" * 80)

    for method_name, result in results.items():
        print(f"{method_name:<40} "
              f"{result['semantic_accuracy']:<15.4f} "
              f"{result['reconstruction_quality']:<15.4f} "
              f"{result['success_rate']:<10.2%}")

    print("=" * 80 + "\n")


if __name__ == "__main__":
    # 检查是否直接运行测试
    import sys

    if len(sys.argv) == 1:
        # 没有参数时,运行快速测试
        print("未提供参数,运行快速测试模式...")
        print("提示: 使用 'python run_enhanced_system.py --help' 查看所有选项\n")
        quick_test()
    elif '--compare' in sys.argv:
        # 对比实验
        compare_methods()
    else:
        # 正常运行
        main()