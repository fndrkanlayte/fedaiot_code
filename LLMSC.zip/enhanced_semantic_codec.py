"""
enhanced_semantic_codec.py - 修复维度匹配问题
关键修复: 确保编码器和解码器使用相同的compressed_dim
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel, CLIPModel, CLIPProcessor, GPT2LMHeadModel, GPT2Tokenizer
from diffusers import AutoencoderKL
from typing import Tuple, Union, Optional, Dict
import warnings
warnings.filterwarnings('ignore')


class VehicleSemanticEncoder(nn.Module):
    """车辆端语义编码器"""

    def __init__(self,
                 text_model_name: str = 'bert-base-uncased',
                 semantic_dim: int = 256,
                 image_size: int = 32,
                 compression_ratio: float = 0.1):
        super().__init__()
        self.semantic_dim = semantic_dim
        self.compression_ratio = compression_ratio
        # 确保compressed_dim是整数
        self.compressed_dim = max(1, int(semantic_dim * compression_ratio))

        print(f"  车辆编码器: semantic_dim={semantic_dim}, compressed_dim={self.compressed_dim}")

        # 文本编码器
        try:
            self.text_tokenizer = AutoTokenizer.from_pretrained(text_model_name)
            self.text_bert = AutoModel.from_pretrained(text_model_name)
            for param in self.text_bert.parameters():
                param.requires_grad = False
            print(f"  ✓ BERT加载完成")
        except Exception as e:
            print(f"  ✗ BERT加载失败: {e}")
            self.text_tokenizer = None
            self.text_bert = None

        # 文本语义投影
        bert_hidden_size = 768
        self.text_projection = nn.Sequential(
            nn.Linear(bert_hidden_size, semantic_dim),
            nn.LayerNorm(semantic_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(semantic_dim, semantic_dim),
            nn.Tanh()
        )

        # 图像编码器
        self.image_encoder = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((4, 4)),

            nn.Flatten(),
            nn.Linear(128 * 4 * 4, semantic_dim),
            nn.ReLU(),
            nn.Linear(semantic_dim, semantic_dim),
            nn.Tanh()
        )

        # 语义压缩器
        self.compressor = nn.Sequential(
            nn.Linear(semantic_dim, semantic_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(semantic_dim // 2, self.compressed_dim),
            nn.Tanh()
        )

        # 解压缩器
        self.decompressor = nn.Sequential(
            nn.Linear(self.compressed_dim, semantic_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(semantic_dim // 2, semantic_dim),
            nn.Tanh()
        )

        # 模态转换
        self.modality_converter = ModalityConverter(semantic_dim)

    def get_compressed_dim(self):
        """获取压缩后的维度"""
        return self.compressed_dim

    def encode_text(self, texts: Union[str, list]) -> Tuple[torch.Tensor, Dict]:
        """编码文本"""
        if self.text_bert is None:
            batch_size = len(texts) if isinstance(texts, list) else 1
            device = next(self.parameters()).device
            compressed = torch.randn(batch_size, self.compressed_dim, device=device) * 0.1
            metadata = {
                'modality': 'text',
                'compressed_dim': self.compressed_dim
            }
            return compressed, metadata

        if isinstance(texts, str):
            texts = [texts]

        device = next(self.text_bert.parameters()).device

        encoded = self.text_tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors='pt'
        )

        encoded = {k: v.to(device) for k, v in encoded.items()}

        with torch.no_grad():
            outputs = self.text_bert(**encoded)
            text_embeddings = outputs.last_hidden_state[:, 0, :]

        semantic = self.text_projection(text_embeddings)
        compressed = self.compressor(semantic)

        metadata = {
            'modality': 'text',
            'semantic_dim': semantic.shape[-1],
            'compressed_dim': compressed.shape[-1]
        }

        return compressed, metadata

    def encode_image(self, images: torch.Tensor) -> Tuple[torch.Tensor, Dict]:
        """编码图像"""
        semantic = self.image_encoder(images)
        compressed = self.compressor(semantic)

        metadata = {
            'modality': 'image',
            'semantic_dim': semantic.shape[-1],
            'compressed_dim': compressed.shape[-1]
        }

        return compressed, metadata

    def convert_modality(self, compressed: torch.Tensor,
                        source_modality: str, target_modality: str) -> torch.Tensor:
        """模态转换"""
        semantic = self.decompressor(compressed)
        converted_semantic = self.modality_converter(semantic, source_modality, target_modality)
        converted_compressed = self.compressor(converted_semantic)
        return converted_compressed

    def forward(self, data: Union[str, torch.Tensor, list],
                modality: str, target_modality: Optional[str] = None) -> Tuple[torch.Tensor, Dict]:
        """前向传播"""
        if modality == 'text':
            compressed, metadata = self.encode_text(data)
        else:
            compressed, metadata = self.encode_image(data)

        if target_modality and target_modality != modality:
            compressed = self.convert_modality(compressed, modality, target_modality)
            metadata['converted_to'] = target_modality

        return compressed, metadata


class ModalityConverter(nn.Module):
    """模态转换模块"""

    def __init__(self, semantic_dim: int = 256):
        super().__init__()

        self.text_to_image = nn.Sequential(
            nn.Linear(semantic_dim, semantic_dim),
            nn.LayerNorm(semantic_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(semantic_dim, semantic_dim),
            nn.Tanh()
        )

        self.image_to_text = nn.Sequential(
            nn.Linear(semantic_dim, semantic_dim),
            nn.LayerNorm(semantic_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(semantic_dim, semantic_dim),
            nn.Tanh()
        )

    def forward(self, semantic: torch.Tensor, source: str, target: str) -> torch.Tensor:
        if source == 'text' and target == 'image':
            return self.text_to_image(semantic)
        elif source == 'image' and target == 'text':
            return self.image_to_text(semantic)
        else:
            return semantic


class ServerSemanticDecoder(nn.Module):
    """服务器端语义解码器"""

    def __init__(self,
                 semantic_dim: int = 256,
                 compressed_dim: Optional[int] = None,
                 image_size: int = 256,
                 use_pretrained: bool = True,
                 compression_ratio: float = 0.1):
        super().__init__()
        self.semantic_dim = semantic_dim

        # 如果没有提供compressed_dim，从compression_ratio计算
        if compressed_dim is None:
            self.compressed_dim = max(1, int(semantic_dim * compression_ratio))
        else:
            self.compressed_dim = compressed_dim

        self.image_size = image_size
        self.use_pretrained = use_pretrained

        print(f"  服务器解码器: semantic_dim={semantic_dim}, compressed_dim={self.compressed_dim}")

        # 解压缩器
        self.decompressor = nn.Sequential(
            nn.Linear(self.compressed_dim, semantic_dim // 2),
            nn.LayerNorm(semantic_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(semantic_dim // 2, semantic_dim),
            nn.Tanh()
        )

        # 图像解码器
        self.image_decoder = ImageDecoder(semantic_dim, image_size)

        # 文本解码器
        self.text_decoder = TextDecoder(semantic_dim)

        # 预训练模型
        self.gpt2_model = None
        self.gpt2_tokenizer = None
        self.clip_model = None
        self.clip_processor = None
        self.vae = None

        if use_pretrained:
            self._load_pretrained_models()

    def _load_pretrained_models(self):
        """加载预训练模型"""
        print("  加载预训练模型...")

        # GPT-2
        try:
            print("    [1/3] 加载GPT-2...")
            self.gpt2_tokenizer = GPT2Tokenizer.from_pretrained('gpt2')
            self.gpt2_model = GPT2LMHeadModel.from_pretrained('gpt2')

            if self.gpt2_tokenizer.pad_token is None:
                self.gpt2_tokenizer.pad_token = self.gpt2_tokenizer.eos_token
                self.gpt2_model.config.pad_token_id = self.gpt2_tokenizer.eos_token_id

            self.gpt2_model.eval()
            for param in self.gpt2_model.parameters():
                param.requires_grad = False
            print("    ✓ GPT-2加载完成")
        except Exception as e:
            print(f"    ⚠ GPT-2加载跳过: {e}")
            self.gpt2_model = None

        # CLIP
        try:
            print("    [2/3] 加载CLIP...")
            self.clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")
            self.clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
            self.clip_model.eval()
            for param in self.clip_model.parameters():
                param.requires_grad = False
            print("    ✓ CLIP加载完成")
        except Exception as e:
            print(f"    ⚠ CLIP加载跳过: {e}")
            self.clip_model = None

        # VAE
        try:
            print("    [3/3] 加载SD-VAE...")
            self.vae = AutoencoderKL.from_pretrained("stabilityai/sd-vae-ft-mse")
            self.vae.eval()
            for param in self.vae.parameters():
                param.requires_grad = False
            print("    ✓ VAE加载完成")
        except Exception as e:
            print(f"    ⚠ VAE加载跳过: {e}")
            self.vae = None

    def decode_to_image(self, compressed: torch.Tensor,
                       use_enhancement: bool = True) -> torch.Tensor:
        """解码为图像"""
        device = compressed.device

        # 检查维度
        if compressed.shape[-1] != self.compressed_dim:
            print(f"    警告: 输入维度 {compressed.shape[-1]} != 期望维度 {self.compressed_dim}")
            # 自动调整维度
            if compressed.shape[-1] < self.compressed_dim:
                padding = torch.zeros(compressed.shape[0],
                                     self.compressed_dim - compressed.shape[-1],
                                     device=device)
                compressed = torch.cat([compressed, padding], dim=-1)
            else:
                compressed = compressed[:, :self.compressed_dim]

        semantic = self.decompressor(compressed)
        image = self.image_decoder(semantic)

        if use_enhancement and self.vae is not None:
            try:
                if next(self.vae.parameters()).device != device:
                    self.vae = self.vae.to(device)
                image = self._enhance_image_with_vae(image)
            except Exception as e:
                print(f"    VAE增强跳过: {e}")

        return image

    def decode_to_text(self, compressed: torch.Tensor,
                      use_enhancement: bool = True,
                      max_length: int = 50) -> list:
        """解码为文本"""
        device = compressed.device
        batch_size = compressed.shape[0]

        # 检查维度
        if compressed.shape[-1] != self.compressed_dim:
            print(f"    警告: 输入维度 {compressed.shape[-1]} != 期望维度 {self.compressed_dim}")
            if compressed.shape[-1] < self.compressed_dim:
                padding = torch.zeros(compressed.shape[0],
                                     self.compressed_dim - compressed.shape[-1],
                                     device=device)
                compressed = torch.cat([compressed, padding], dim=-1)
            else:
                compressed = compressed[:, :self.compressed_dim]

        semantic = self.decompressor(compressed)

        if use_enhancement and self.gpt2_model is not None:
            try:
                if next(self.gpt2_model.parameters()).device != device:
                    self.gpt2_model = self.gpt2_model.to(device)
                texts = self._enhance_text_with_gpt2(semantic, max_length, device)
            except Exception as e:
                print(f"    GPT-2增强跳过: {e}")
                texts = [f"[解码文本 {i+1}]" for i in range(batch_size)]
        else:
            texts = [f"[解码文本 {i+1}]" for i in range(batch_size)]

        return texts

    def _enhance_image_with_vae(self, image: torch.Tensor) -> torch.Tensor:
        """使用VAE增强图像"""
        with torch.no_grad():
            device = image.device
            image_resized = F.interpolate(image, size=(512, 512),
                                         mode='bilinear', align_corners=False)
            image_norm = image_resized * 2 - 1
            latent = self.vae.encode(image_norm).latent_dist.sample()
            enhanced = self.vae.decode(latent).sample
            enhanced = (enhanced + 1) / 2
            enhanced = F.interpolate(enhanced, size=(self.image_size, self.image_size),
                                    mode='bilinear', align_corners=False)
        return enhanced

    def _enhance_text_with_gpt2(self, semantic: torch.Tensor,
                                max_length: int, device) -> list:
        """使用GPT-2增强文本生成"""
        batch_size = semantic.shape[0]
        texts = []

        with torch.no_grad():
            for i in range(batch_size):
                try:
                    prompt = "The semantic content represents:"
                    inputs = self.gpt2_tokenizer(
                        prompt,
                        return_tensors='pt',
                        padding=True,
                        truncation=True
                    )

                    input_ids = inputs['input_ids'].to(device)
                    attention_mask = inputs['attention_mask'].to(device)

                    outputs = self.gpt2_model.generate(
                        input_ids,
                        attention_mask=attention_mask,
                        max_length=max_length,
                        num_return_sequences=1,
                        temperature=0.7,
                        do_sample=True,
                        top_p=0.9,
                        pad_token_id=self.gpt2_tokenizer.eos_token_id,
                        no_repeat_ngram_size=3
                    )

                    text = self.gpt2_tokenizer.decode(outputs[0], skip_special_tokens=True)
                    texts.append(text)

                except Exception as e:
                    texts.append(f"[解码文本 {i+1}]")

        return texts

    def forward(self, compressed: torch.Tensor, target_modality: str,
                source_modality: Optional[str] = None,
                use_enhancement: bool = True) -> Union[torch.Tensor, list]:
        """前向传播"""
        if target_modality == 'image':
            return self.decode_to_image(compressed, use_enhancement)
        else:
            return self.decode_to_text(compressed, use_enhancement)


class ImageDecoder(nn.Module):
    """图像解码器"""

    def __init__(self, semantic_dim: int = 256, image_size: int = 256):
        super().__init__()
        self.image_size = image_size
        self.init_size = image_size // 16
        self.init_channels = 512

        self.fc = nn.Sequential(
            nn.Linear(semantic_dim, semantic_dim * 2),
            nn.ReLU(),
            nn.Linear(semantic_dim * 2, self.init_channels * self.init_size * self.init_size),
            nn.ReLU()
        )

        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(self.init_channels, 256, 4, stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),

            nn.ConvTranspose2d(256, 128, 4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),

            nn.ConvTranspose2d(128, 64, 4, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),

            nn.ConvTranspose2d(64, 32, 4, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),

            nn.Conv2d(32, 3, 3, padding=1),
            nn.Sigmoid()
        )

    def forward(self, semantic: torch.Tensor) -> torch.Tensor:
        batch_size = semantic.shape[0]
        x = self.fc(semantic)
        x = x.view(batch_size, self.init_channels, self.init_size, self.init_size)
        image = self.decoder(x)
        return image


class TextDecoder(nn.Module):
    """文本解码器"""

    def __init__(self, semantic_dim: int = 256, vocab_size: int = 50000):
        super().__init__()

        self.decoder = nn.Sequential(
            nn.Linear(semantic_dim, semantic_dim * 2),
            nn.LayerNorm(semantic_dim * 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(semantic_dim * 2, vocab_size)
        )

    def forward(self, semantic: torch.Tensor) -> torch.Tensor:
        return self.decoder(semantic)


def create_matched_codec(semantic_dim: int = 256,
                        compression_ratio: float = 0.1,
                        device = None) -> Tuple[VehicleSemanticEncoder, ServerSemanticDecoder]:
    """
    创建维度匹配的编码器和解码器

    Returns:
        encoder, decoder: 配置匹配的编解码器对
    """
    if device is None:
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 创建编码器
    encoder = VehicleSemanticEncoder(
        semantic_dim=semantic_dim,
        compression_ratio=compression_ratio
    ).to(device)

    # 获取实际的compressed_dim
    actual_compressed_dim = encoder.get_compressed_dim()

    # 创建匹配的解码器
    decoder = ServerSemanticDecoder(
        semantic_dim=semantic_dim,
        compressed_dim=actual_compressed_dim,
        use_pretrained=False
    ).to(device)

    print(f"\n✓ 创建了维度匹配的编解码器:")
    print(f"  semantic_dim={semantic_dim}, compressed_dim={actual_compressed_dim}")

    return encoder, decoder