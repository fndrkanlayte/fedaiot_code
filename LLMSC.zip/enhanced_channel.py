"""
enhanced_channel.py - 支持动态SNR的增强信道模拟器
"""
import torch
import torch.nn as nn


class EnhancedChannelSimulator(nn.Module):
    """增强的信道模拟器，支持动态SNR设置"""

    def __init__(self, initial_snr_db: float = 20.0):
        super().__init__()
        self.snr_db = initial_snr_db
        self.snr_linear = 10 ** (initial_snr_db / 10)

    def set_snr(self, snr_db: float):
        """动态设置信噪比（SNR）"""
        self.snr_db = snr_db
        self.snr_linear = 10 ** (snr_db / 10)
        print(f"SNR设置为: {snr_db:.1f} dB (信道质量: {self.get_channel_quality()})")

    def forward(self, semantic_data: torch.Tensor) -> torch.Tensor:
        """根据SNR添加信道噪声"""
        if self.training:
            # 计算信号功率
            signal_power = torch.mean(semantic_data ** 2)
            # 根据SNR计算噪声功率
            noise_power = signal_power / self.snr_linear
            # 生成高斯噪声
            noise = torch.randn_like(semantic_data) * torch.sqrt(noise_power)
            return semantic_data + noise
        else:
            return semantic_data

    def get_channel_quality(self) -> str:
        """获取信道质量评估"""
        if self.snr_db >= 20:
            return "优秀"
        elif self.snr_db >= 15:
            return "良好"
        elif self.snr_db >= 10:
            return "一般"
        else:
            return "较差"