"""
enhanced_maddpg.py - 原始版本（优化前）
基础的MADDPG实现，使用扩散模型Actor
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from typing import List, Tuple, Optional
from collections import deque
import random
import math


class SinusoidalPositionEmbeddings(nn.Module):
    """正弦位置编码"""
    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim

    def forward(self, time: torch.Tensor) -> torch.Tensor:
        device = time.device
        half_dim = self.dim // 2
        embeddings = math.log(10000) / (half_dim - 1)
        embeddings = torch.exp(torch.arange(half_dim, device=device) * -embeddings)
        embeddings = time[:, None] * embeddings[None, :]
        embeddings = torch.cat((embeddings.sin(), embeddings.cos()), dim=-1)
        return embeddings


class DiffusionActor(nn.Module):
    """基于扩散模型的Actor网络（原始版本）"""

    def __init__(self,
                 state_dim: int,
                 action_dim: int = 6,
                 hidden_dim: int = 256,
                 num_timesteps: int = 50):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.num_timesteps = num_timesteps

        # 时间嵌入
        self.time_embed_dim = 128
        self.time_embedding = nn.Sequential(
            SinusoidalPositionEmbeddings(self.time_embed_dim),
            nn.Linear(self.time_embed_dim, self.time_embed_dim),
            nn.ReLU()
        )

        # 状态编码器（简单版本）
        self.state_encoder = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )

        # 噪声预测网络
        self.noise_predictor = nn.ModuleList([
            nn.Sequential(
                nn.Linear(action_dim + hidden_dim + self.time_embed_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1)
            ),
            nn.Sequential(
                nn.Linear(hidden_dim, action_dim)
            )
        ])

        # Beta调度
        self.register_buffer('betas', self._cosine_beta_schedule(num_timesteps))
        self.register_buffer('alphas', 1.0 - self.betas)
        self.register_buffer('alphas_cumprod', torch.cumprod(self.alphas, dim=0))
        self.register_buffer('sqrt_alphas_cumprod', torch.sqrt(self.alphas_cumprod))
        self.register_buffer('sqrt_one_minus_alphas_cumprod',
                           torch.sqrt(1.0 - self.alphas_cumprod))

        # 动作约束层
        self.action_constraint = ActionConstraintLayer()

    def _cosine_beta_schedule(self, timesteps: int, s: float = 0.008) -> torch.Tensor:
        """余弦Beta调度"""
        steps = timesteps + 1
        x = torch.linspace(0, timesteps, steps)
        alphas_cumprod = torch.cos(((x / timesteps) + s) / (1 + s) * torch.pi * 0.5) ** 2
        alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
        betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
        return torch.clip(betas, 0.0001, 0.9999)

    def forward(self, state: torch.Tensor, deterministic: bool = False) -> torch.Tensor:
        """生成动作"""
        batch_size = state.shape[0]
        device = state.device

        # 编码状态
        state_emb = self.state_encoder(state)

        # 从高斯噪声开始
        action = torch.randn(batch_size, self.action_dim, device=device)

        # 反向扩散过程
        timesteps = self.num_timesteps if not deterministic else self.num_timesteps // 5

        for t in reversed(range(timesteps)):
            t_batch = torch.full((batch_size,), t, device=device, dtype=torch.long)

            # 预测噪声
            predicted_noise = self._predict_noise(action, state_emb, t_batch)

            # 更新动作
            alpha_t = self.alphas[t]
            alpha_cumprod_t = self.alphas_cumprod[t]
            sqrt_one_minus_alpha_cumprod_t = self.sqrt_one_minus_alphas_cumprod[t]

            # DDPM更新公式
            action = (1 / torch.sqrt(alpha_t)) * (
                action - ((1 - alpha_t) / sqrt_one_minus_alpha_cumprod_t) * predicted_noise
            )

            # 添加噪声(除了最后一步)
            if t > 0 and not deterministic:
                noise = torch.randn_like(action)
                sigma_t = torch.sqrt(self.betas[t])
                action = action + sigma_t * noise

        # 应用动作约束
        action = self.action_constraint(action)

        return action

    def _predict_noise(self,
                       action: torch.Tensor,
                       state_emb: torch.Tensor,
                       t: torch.Tensor) -> torch.Tensor:
        """预测噪声"""
        t_emb = self.time_embedding(t.float())
        x = torch.cat([action, state_emb, t_emb], dim=-1)

        skip_connections = []

        # 下采样
        for i in range(2):
            x = self.noise_predictor[i](x)
            skip_connections.append(x)

        # 中间层
        x = self.noise_predictor[2](x)

        # 上采样(带残差连接)
        for i in range(2):
            if skip_connections:
                x = x + skip_connections.pop()
            x = self.noise_predictor[3 + i](x)

        return x

    def compute_loss(self, state: torch.Tensor, target_action: torch.Tensor) -> torch.Tensor:
        """计算扩散模型训练损失"""
        batch_size = state.shape[0]
        device = state.device

        state_emb = self.state_encoder(state)

        # 随机采样时间步
        t = torch.randint(0, self.num_timesteps, (batch_size,), device=device).long()

        # 添加噪声到目标动作
        noise = torch.randn_like(target_action)
        sqrt_alpha_cumprod_t = self.sqrt_alphas_cumprod[t].view(-1, 1)
        sqrt_one_minus_alpha_cumprod_t = self.sqrt_one_minus_alphas_cumprod[t].view(-1, 1)

        noisy_action = sqrt_alpha_cumprod_t * target_action + sqrt_one_minus_alpha_cumprod_t * noise

        # 预测噪声
        predicted_noise = self._predict_noise(noisy_action, state_emb, t)

        # MSE损失
        loss = F.mse_loss(predicted_noise, noise)

        return loss


class ActionConstraintLayer(nn.Module):
    """动作约束层"""

    def forward(self, action: torch.Tensor) -> torch.Tensor:
        """约束动作到有效范围"""
        constrained_action = torch.zeros_like(action)

        # 二元决策 [0, 1]
        constrained_action[:, :3] = torch.sigmoid(action[:, :3])

        # 资源分配 [0.3, 1.0]
        constrained_action[:, 3:5] = 0.3 + 0.7 * torch.sigmoid(action[:, 3:5])

        # 压缩率 [0.1, 0.5]
        constrained_action[:, 5:6] = 0.1 + 0.4 * torch.sigmoid(action[:, 5:6])

        return constrained_action


class Critic(nn.Module):
    """Critic网络（原始版本 - 单Q网络）"""

    def __init__(self,
                 state_dim: int,
                 action_dim: int = 6,
                 hidden_dim: int = 256):
        super().__init__()

        # 单Q网络
        self.network = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, state: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
        """计算Q值"""
        x = torch.cat([state, action], dim=-1)
        return self.network(x)


class ReplayBuffer:
    """标准经验回放缓冲区（无优先级）"""

    def __init__(self, capacity: int):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        """添加经验"""
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        """随机采样"""
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return state, action, reward, next_state, done

    def __len__(self):
        return len(self.buffer)


class EnhancedMADDPGAgent:
    """MADDPG智能体（原始版本）"""

    def __init__(self,
                 agent_id: int,
                 state_dim: int,
                 action_dim: int = 6,
                 lr_actor: float = 3e-4,
                 lr_critic: float = 3e-3,
                 gamma: float = 0.99,
                 tau: float = 0.005,
                 hidden_dim: int = 256):

        self.agent_id = agent_id
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.tau = tau

        # 网络
        self.actor = DiffusionActor(state_dim, action_dim, hidden_dim)
        self.critic = Critic(state_dim, action_dim, hidden_dim)
        self.target_actor = DiffusionActor(state_dim, action_dim, hidden_dim)
        self.target_critic = Critic(state_dim, action_dim, hidden_dim)

        # 复制参数到目标网络
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.target_critic.load_state_dict(self.critic.state_dict())

        # 优化器（固定学习率）
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr_critic)

    def select_action(self, state: np.ndarray,
                     noise_scale: float = 0.0,
                     deterministic: bool = False) -> np.ndarray:
        """选择动作"""
        state_tensor = torch.FloatTensor(state).unsqueeze(0)

        with torch.no_grad():
            action = self.actor(state_tensor, deterministic=deterministic)

        action = action.squeeze(0).cpu().numpy()

        # 添加探索噪声
        if noise_scale > 0 and not deterministic:
            noise = np.random.normal(0, noise_scale, size=action.shape)
            action = action + noise
            # 重新约束
            action = self._constrain_action(action)

        return action

    def _constrain_action(self, action: np.ndarray) -> np.ndarray:
        """NumPy版本的动作约束"""
        constrained = np.zeros_like(action)
        constrained[:3] = np.clip(action[:3], 0, 1)
        constrained[3:5] = np.clip(action[3:5], 0.3, 1.0)
        constrained[5:6] = np.clip(action[5:6], 0.1, 0.5)
        return constrained

    def update(self,
               states: torch.Tensor,
               actions: torch.Tensor,
               rewards: torch.Tensor,
               next_states: torch.Tensor,
               dones: torch.Tensor):
        """
        更新网络（修复版本 - 解决延迟更新的RuntimeError）

        修复内容：
        1. 正确实现延迟Actor更新（每2步更新一次）
        2. 避免在不更新时创建无梯度的tensor
        3. 确保返回值正确
        """

        # ========== 步骤1: 更新Critic（每次都执行）==========
        with torch.no_grad():
            next_actions = self.target_actor(next_states, deterministic=True)
            target_q = self.target_critic(next_states, next_actions)
            target_q = rewards.unsqueeze(-1) + self.gamma * (1 - dones.unsqueeze(-1)) * target_q

        current_q = self.critic(states, actions)
        critic_loss = F.mse_loss(current_q, target_q)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
        self.critic_optimizer.step()

        # ========== 步骤2: 延迟更新Actor ==========
        # 初始化更新计数器（只在第一次调用时初始化）
        if not hasattr(self, 'update_counter'):
            self.update_counter = 0

        self.update_counter += 1

        # 检查是否应该更新Actor（每2步更新一次）
        should_update_actor = (self.update_counter % 2 == 0)

        if should_update_actor:
            # === 更新Actor ===
            # 1. 扩散模型损失
            diffusion_loss = self.actor.compute_loss(states, actions)

            # 2. 策略梯度损失
            predicted_actions = self.actor(states, deterministic=False)
            policy_loss = -self.critic(states, predicted_actions).mean()

            # 3. 组合损失
            actor_loss = diffusion_loss + 0.1 * policy_loss

            # 4. 反向传播和优化
            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 1.0)
            self.actor_optimizer.step()

            # 5. 软更新目标网络
            self._soft_update(self.target_actor, self.actor)
            self._soft_update(self.target_critic, self.critic)

            # 返回完整的损失信息
            return {
                'critic_loss': critic_loss.item(),
                'actor_loss': actor_loss.item(),
                'diffusion_loss': diffusion_loss.item(),
                'policy_loss': policy_loss.item(),
                'q_value': current_q.mean().item()
            }
        else:
            # === 跳过Actor更新 ===
            # 只更新了Critic，返回部分损失信息
            return {
                'critic_loss': critic_loss.item(),
                'actor_loss': 0.0,  # 未更新，返回0
                'diffusion_loss': 0.0,  # 未更新，返回0
                'policy_loss': 0.0,  # 未更新，返回0
                'q_value': current_q.mean().item()
            }



    def _soft_update(self, target_net: nn.Module, source_net: nn.Module):
        """软更新目标网络"""
        for target_param, source_param in zip(target_net.parameters(), source_net.parameters()):
            target_param.data.copy_(
                self.tau * source_param.data + (1.0 - self.tau) * target_param.data
            )


class ImprovedMADDPG:
    """MADDPG算法（原始版本）"""

    def __init__(self,
                 num_agents: int,
                 state_dim: int,
                 action_dim: int = 6,
                 lr_actor: float = 3e-4,
                 lr_critic: float = 3e-3,
                 gamma: float = 0.995,
                 tau: float = 0.005,
                 buffer_size: int = 100000,
                 batch_size: int = 128,
                 hidden_dim: int = 256):

        self.num_agents = num_agents
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.batch_size = batch_size

        # 创建智能体
        self.agents = []
        for i in range(num_agents):
            agent = EnhancedMADDPGAgent(
                agent_id=i,
                state_dim=state_dim,
                action_dim=action_dim,
                lr_actor=lr_actor,
                lr_critic=lr_critic,
                gamma=gamma,
                tau=tau,
                hidden_dim=hidden_dim
            )
            self.agents.append(agent)

        # 标准经验回放
        self.replay_buffer = ReplayBuffer(buffer_size)

        # 探索参数（快速衰减）
        self.noise_scale = 0.5
        self.noise_decay = 0.995
        self.min_noise = 0.05
        # 添加自适应探索
        self.recent_rewards = []
        self.best_avg_reward = -float('inf')
        self.exploration_boost = False

        # 更新参数
        self.update_frequency = 1
        self.step_count = 0

    def adaptive_noise_update(self, episode_reward: float):
        """自适应噪声调整"""
        self.recent_rewards.append(episode_reward)
        if len(self.recent_rewards) > 20:
            self.recent_rewards.pop(0)

        # 检查性能
        if len(self.recent_rewards) >= 20:
            avg_reward = np.mean(self.recent_rewards)

            # 如果性能提升 → 正常衰减
            if avg_reward > self.best_avg_reward + 0.5:
                self.best_avg_reward = avg_reward
                self.noise_scale *= self.noise_decay
                self.exploration_boost = False

            # 如果性能停滞 → 增加探索
            elif avg_reward < self.best_avg_reward - 1.0:
                if not self.exploration_boost:
                    self.noise_scale = min(0.3, self.noise_scale * 1.2)
                    self.exploration_boost = True

        # 限制范围
        self.noise_scale = np.clip(self.noise_scale, self.min_noise, 0.5)

    def select_actions(self, states: np.ndarray, deterministic: bool = False) -> np.ndarray:
        """所有智能体选择动作"""
        actions = []
        for i, agent in enumerate(self.agents):
            noise = 0.0 if deterministic else self.noise_scale
            action = agent.select_action(states[i], noise_scale=noise, deterministic=deterministic)
            actions.append(action)
        return np.array(actions)

    def store_experience(self,
                        states: np.ndarray,
                        actions: np.ndarray,
                        rewards: np.ndarray,
                        next_states: np.ndarray,
                        dones: np.ndarray):
        """存储经验"""
        for i in range(self.num_agents):
            self.replay_buffer.push(
                states[i], actions[i], rewards[i], next_states[i], dones[i]
            )

    def update(self):
        """更新所有智能体"""
        if len(self.replay_buffer) < self.batch_size:
            return {}

        # 采样批次
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.batch_size)

        # 转换为tensor
        states = torch.FloatTensor(states)
        actions = torch.FloatTensor(actions)
        rewards = torch.FloatTensor(rewards)
        next_states = torch.FloatTensor(next_states)
        dones = torch.FloatTensor(dones)

        # 更新每个智能体
        losses = {}
        for i, agent in enumerate(self.agents):
            agent_losses = agent.update(states, actions, rewards, next_states, dones)

            for key, value in agent_losses.items():
                losses[f'agent_{i}_{key}'] = value

        # 衰减探索噪声
        self.noise_scale = max(self.min_noise, self.noise_scale * self.noise_decay)
        losses['noise_scale'] = self.noise_scale

        return losses

    def step(self,
             states: np.ndarray,
             actions: np.ndarray,
             rewards: np.ndarray,
             next_states: np.ndarray,
             dones: np.ndarray):
        """训练步骤"""
        # 存储经验
        self.store_experience(states, actions, rewards, next_states, dones)

        # 更新网络
        self.step_count += 1
        if self.step_count % self.update_frequency == 0:
            return self.update()

        return {}

    def save_models(self, filepath: str):
        """保存所有模型"""
        for i, agent in enumerate(self.agents):
            torch.save({
                'actor_state_dict': agent.actor.state_dict(),
                'critic_state_dict': agent.critic.state_dict(),
                'target_actor_state_dict': agent.target_actor.state_dict(),
                'target_critic_state_dict': agent.target_critic.state_dict(),
                'actor_optimizer': agent.actor_optimizer.state_dict(),
                'critic_optimizer': agent.critic_optimizer.state_dict(),
            }, f"{filepath}_agent_{i}.pth")
        print(f"模型已保存至: {filepath}_agent_*.pth")

    def load_models(self, filepath: str):
        """加载所有模型"""
        for i, agent in enumerate(self.agents):
            checkpoint = torch.load(f"{filepath}_agent_{i}.pth")
            agent.actor.load_state_dict(checkpoint['actor_state_dict'])
            agent.critic.load_state_dict(checkpoint['critic_state_dict'])
            agent.target_actor.load_state_dict(checkpoint['target_actor_state_dict'])
            agent.target_critic.load_state_dict(checkpoint['target_critic_state_dict'])
            agent.actor_optimizer.load_state_dict(checkpoint['actor_optimizer'])
            agent.critic_optimizer.load_state_dict(checkpoint['critic_optimizer'])
        print(f"模型已加载自: {filepath}_agent_*.pth")