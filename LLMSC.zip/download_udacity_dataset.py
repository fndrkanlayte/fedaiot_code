"""
download_udacity_dataset.py - 处理真实的Udacity Self Driving Car数据集

支持的CSV格式:
- filename, width, height, class, xmin, ymin, xmax, ymax

数据集来源：
- GitHub: https://github.com/udacity/self-driving-car
- Kaggle: https://www.kaggle.com/datasets/sshikamaru/udacity-self-driving-car
"""

import os
import sys
import zipfile
import cv2
import torch
import numpy as np
import pandas as pd
from pathlib import Path
from typing import List, Tuple, Dict
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')


class UdacityDatasetProcessor:
    """Udacity数据集处理器"""

    def __init__(self, data_dir: str = './data/udacity'):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        # 数据集路径
        self.raw_dir = self.data_dir / 'raw'
        self.processed_dir = self.data_dir / 'processed'
        self.images_dir = self.processed_dir / 'images'
        self.labels_dir = self.processed_dir / 'labels'

        # 创建目录
        for dir_path in [self.raw_dir, self.processed_dir, self.images_dir, self.labels_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)

        # Udacity类别映射（根据实际CSV中的类别名称）
        self.class_mapping = {
            # 汽车类
            'Car': 0,
            'car': 0,
            'vehicle': 0,

            # 卡车类
            'Truck': 1,
            'truck': 1,

            # 行人类
            'Pedestrian': 2,
            'pedestrian': 2,
            'Person': 2,
            'person': 2,

            # 骑行者类
            'Cyclist': 3,
            'cyclist': 3,
            'Biker': 3,
            'biker': 3,
            'Bike': 3,
            'bike': 3,

            # 交通灯类
            'Traffic Light': 4,
            'TrafficLight': 4,
            'traffic_light': 4,
            'trafficLight': 4,
        }

        self.class_names = ['car', 'truck', 'pedestrian', 'cyclist', 'traffic_light']

        print("="*70)
        print("Udacity Self Driving Car 数据集处理器")
        print("="*70)
        print(f"数据目录: {self.data_dir}")
        print(f"类别数: {len(self.class_names)}")
        print(f"类别: {self.class_names}\n")

    def find_labels_csv(self) -> Path:
        """查找labels.csv文件"""
        print("查找labels.csv文件...")

        # 在raw目录下查找
        csv_files = list(self.raw_dir.rglob('labels.csv'))

        if not csv_files:
            # 尝试在上级目录查找
            csv_files = list(self.raw_dir.parent.rglob('labels.csv'))

        if not csv_files:
            print("✗ 未找到labels.csv文件")
            print(f"\n请确保labels.csv在以下目录之一:")
            print(f"  - {self.raw_dir}")
            print(f"  - {self.raw_dir}的任何子目录")
            return None

        csv_path = csv_files[0]
        print(f"✓ 找到标注文件: {csv_path}")
        return csv_path

    def analyze_csv(self, csv_path: Path) -> Dict:
        """分析CSV文件"""
        print("\n分析CSV文件...")

        # 读取CSV
        df = pd.read_csv(csv_path)

        print(f"✓ CSV信息:")
        print(f"  总行数: {len(df)}")
        print(f"  列名: {list(df.columns)}")
        print(f"  唯一图像: {df['filename'].nunique()}")

        # 分析类别分布
        class_counts = df['class'].value_counts()
        print(f"\n✓ 类别分布:")
        for class_name, count in class_counts.items():
            mapped_id = self.class_mapping.get(class_name, -1)
            if mapped_id >= 0:
                print(f"  {class_name}: {count} (映射到ID {mapped_id}: {self.class_names[mapped_id]})")
            else:
                print(f"  {class_name}: {count} (未映射)")

        # 检查未映射的类别
        unmapped_classes = [c for c in class_counts.index if c not in self.class_mapping]
        if unmapped_classes:
            print(f"\n⚠️  未映射的类别: {unmapped_classes}")
            print("这些类别将被忽略")

        return {
            'total_rows': len(df),
            'unique_images': df['filename'].nunique(),
            'class_distribution': class_counts.to_dict()
        }

    def process_csv_labels(self, csv_path: Path, max_samples: int = None) -> Dict:
        """
        处理CSV格式的标注文件

        CSV格式：filename, width, height, class, xmin, ymin, xmax, ymax
        """
        print("\n【处理CSV标注数据】")

        # 读取CSV
        df = pd.read_csv(csv_path)
        print(f"✓ 读取标注: {len(df)} 行")

        # 按图像分组
        images_data = {}
        skipped_count = 0

        for filename, group in tqdm(df.groupby('filename'), desc="处理标注"):
            boxes = []
            labels = []

            for _, row in group.iterrows():
                # 获取类别
                class_name = row['class']

                # 检查是否在映射中
                if class_name not in self.class_mapping:
                    skipped_count += 1
                    continue

                # 获取边界框（已经是像素坐标）
                xmin = int(row['xmin'])
                ymin = int(row['ymin'])
                xmax = int(row['xmax'])
                ymax = int(row['ymax'])

                # 验证边界框
                if xmax <= xmin or ymax <= ymin:
                    continue

                # 边界框尺寸检查
                width = xmax - xmin
                height = ymax - ymin
                if width < 10 or height < 10:  # 过滤太小的框
                    continue

                bbox = [xmin, ymin, xmax, ymax]
                label_id = self.class_mapping[class_name]

                boxes.append(bbox)
                labels.append(label_id)

            # 只保留有有效标注的图像
            if boxes:
                images_data[filename] = {
                    'boxes': np.array(boxes, dtype=np.float32),
                    'labels': np.array(labels, dtype=np.int64)
                }

            # 限制样本数
            if max_samples and len(images_data) >= max_samples:
                print(f"\n达到最大样本数限制: {max_samples}")
                break

        print(f"\n✓ 处理完成:")
        print(f"  有效图像: {len(images_data)}")
        print(f"  跳过的标注: {skipped_count}")

        if len(images_data) == 0:
            print("\n✗ 没有有效的标注数据！")
            return None

        return images_data

    def find_images(self) -> Dict[str, Path]:
        """查找所有图像文件"""
        print("\n【查找图像文件】")

        image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.JPG', '*.JPEG', '*.PNG']
        image_files = []

        for ext in image_extensions:
            image_files.extend(self.raw_dir.rglob(ext))

        print(f"✓ 找到 {len(image_files)} 个图像文件")

        # 创建文件名到路径的映射
        image_paths = {}
        for img_path in image_files:
            image_paths[img_path.name] = img_path

        return image_paths

    def load_and_resize_images(self,
                               images_data: Dict,
                               image_paths: Dict[str, Path],
                               target_size: int = 256) -> Tuple:
        """
        加载并调整图像尺寸

        Args:
            images_data: 图像标注数据
            image_paths: 图像文件路径映射
            target_size: 目标尺寸
        """
        print(f"\n【加载图像并调整到 {target_size}x{target_size}】")

        images_list = []
        boxes_list = []
        labels_list = []

        valid_count = 0
        missing_count = 0
        error_count = 0

        for image_name, annotation in tqdm(images_data.items(), desc="加载图像"):
            # 检查图像是否存在
            if image_name not in image_paths:
                missing_count += 1
                continue

            try:
                # 读取图像
                img_path = image_paths[image_name]
                img = cv2.imread(str(img_path))

                if img is None:
                    error_count += 1
                    continue

                # 转换BGR到RGB
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

                # 获取原始尺寸
                orig_h, orig_w = img.shape[:2]

                # 调整图像尺寸
                img_resized = cv2.resize(img, (target_size, target_size))

                # 转换为tensor并归一化到[0,1]
                img_tensor = torch.from_numpy(img_resized).permute(2, 0, 1).float() / 255.0

                # 调整边界框坐标
                boxes = annotation['boxes'].copy()
                scale_x = target_size / orig_w
                scale_y = target_size / orig_h
                boxes[:, [0, 2]] *= scale_x
                boxes[:, [1, 3]] *= scale_y

                # 确保边界框在图像范围内
                boxes[:, [0, 2]] = np.clip(boxes[:, [0, 2]], 0, target_size)
                boxes[:, [1, 3]] = np.clip(boxes[:, [1, 3]], 0, target_size)

                # 过滤调整后太小的边界框
                widths = boxes[:, 2] - boxes[:, 0]
                heights = boxes[:, 3] - boxes[:, 1]
                min_size = max(10, target_size // 25)  # 根据目标尺寸调整最小尺寸
                valid_mask = (widths >= min_size) & (heights >= min_size)

                boxes = boxes[valid_mask]
                labels = annotation['labels'][valid_mask]

                # 至少要有一个有效边界框
                if len(boxes) > 0:
                    images_list.append(img_tensor)
                    boxes_list.append(boxes)
                    labels_list.append(labels)
                    valid_count += 1

            except Exception as e:
                error_count += 1
                continue

        print(f"\n✓ 加载统计:")
        print(f"  成功: {valid_count}")
        print(f"  图像缺失: {missing_count}")
        print(f"  读取错误: {error_count}")

        if valid_count == 0:
            print("\n✗ 没有加载到有效图像！")
            return None, None, None

        # 堆叠为tensor
        images_tensor = torch.stack(images_list)

        return images_tensor, boxes_list, labels_list

    def save_processed_dataset(self,
                               images: torch.Tensor,
                               boxes: List[np.ndarray],
                               labels: List[np.ndarray]) -> Path:
        """保存处理后的数据集"""
        print("\n【保存处理后的数据集】")

        cache_file = self.data_dir / 'udacity_detection_dataset.pkl'

        import pickle
        data = {
            'images': images,
            'boxes': boxes,
            'labels': labels
        }

        print(f"保存到: {cache_file}")
        with open(cache_file, 'wb') as f:
            pickle.dump(data, f)

        # 计算统计信息
        total_objects = sum([len(b) for b in boxes])
        class_counts = {i: 0 for i in range(5)}
        for label_array in labels:
            for label in label_array:
                class_counts[int(label)] += 1

        stats = {
            'num_images': len(images),
            'image_shape': tuple(images.shape),
            'num_classes': len(self.class_names),
            'class_names': self.class_names,
            'avg_objects_per_image': total_objects / len(images),
            'total_objects': total_objects,
            'class_distribution': {
                self.class_names[i]: count
                for i, count in class_counts.items()
            }
        }

        # 保存统计信息
        import yaml
        stats_file = self.data_dir / 'dataset_stats.yaml'
        with open(stats_file, 'w') as f:
            yaml.dump(stats, f, default_flow_style=False)

        print(f"✓ 数据集已保存!")
        print(f"\n【数据集统计】")
        print(f"  图像数量: {stats['num_images']}")
        print(f"  图像形状: {stats['image_shape']}")
        print(f"  类别数: {stats['num_classes']}")
        print(f"  平均目标数: {stats['avg_objects_per_image']:.2f}")
        print(f"  总目标数: {stats['total_objects']}")
        print(f"\n  类别分布:")
        for class_name, count in stats['class_distribution'].items():
            print(f"    {class_name}: {count}")

        return cache_file

    def process_dataset(self,
                       target_size: int = 256,
                       max_samples: int = None) -> Path:
        """
        完整处理流程

        Args:
            target_size: 目标图像尺寸
            max_samples: 最大样本数（None表示全部）
        """
        print("\n" + "="*70)
        print("开始处理数据集")
        print("="*70)

        # 1. 查找labels.csv
        csv_path = self.find_labels_csv()
        if csv_path is None:
            return None

        # 2. 分析CSV
        self.analyze_csv(csv_path)

        # 3. 处理标注
        images_data = self.process_csv_labels(csv_path, max_samples)
        if images_data is None:
            return None

        # 4. 查找图像
        image_paths = self.find_images()
        if not image_paths:
            print("✗ 未找到图像文件！")
            return None

        # 5. 加载和调整图像
        images, boxes, labels = self.load_and_resize_images(
            images_data, image_paths, target_size
        )

        if images is None:
            return None

        # 6. 保存数据集
        cache_file = self.save_processed_dataset(images, boxes, labels)

        print("\n" + "="*70)
        print("✓ 数据集处理完成！")
        print("="*70)
        print(f"\n缓存文件: {cache_file}")
        print("\n使用方法:")
        print("  1. 复制到项目cache目录:")
        print(f"     cp {cache_file} data/cache/")
        print("  2. 运行训练脚本:")
        print("     python run_enhanced_system.py --mode train --episodes 100")

        return cache_file

    def quick_preview(self, num_samples: int = 5):
        """快速预览数据集"""
        print("\n" + "="*70)
        print("数据集预览")
        print("="*70)

        csv_path = self.find_labels_csv()
        if csv_path is None:
            return

        df = pd.read_csv(csv_path)

        # 随机选择几张图像
        sample_files = df['filename'].unique()[:num_samples]

        image_paths = self.find_images()

        for i, filename in enumerate(sample_files, 1):
            print(f"\n图像 {i}: {filename}")

            # 获取该图像的所有标注
            img_annotations = df[df['filename'] == filename]

            print(f"  标注数: {len(img_annotations)}")
            print(f"  类别: {img_annotations['class'].tolist()}")

            # 检查图像是否存在
            if filename in image_paths:
                img_path = image_paths[filename]
                img = cv2.imread(str(img_path))
                if img is not None:
                    h, w = img.shape[:2]
                    print(f"  尺寸: {w}x{h}")
                else:
                    print("  状态: 读取失败")
            else:
                print("  状态: 文件不存在")


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description='Udacity数据集处理器')
    parser.add_argument('--data-dir', type=str, default='./data/udacity',
                       help='数据目录')
    parser.add_argument('--target-size', type=int, default=256,
                       help='目标图像尺寸')
    parser.add_argument('--max-samples', type=int, default=None,
                       help='最大样本数')
    parser.add_argument('--preview', action='store_true',
                       help='预览数据集')

    args = parser.parse_args()

    # 创建处理器
    processor = UdacityDatasetProcessor(args.data_dir)

    if args.preview:
        # 预览模式
        processor.quick_preview()
    else:
        # 处理模式
        processor.process_dataset(args.target_size, args.max_samples)


if __name__ == "__main__":
    main()