"""
detection_evaluator.py - 修复图像相似度负数问题
关键修复：
1. 确保图像值域在[0, 1]
2. 正确处理维度
3. 添加调试信息
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel
from typing import Tuple, List, Optional, Dict, Union
import numpy as np
import warnings
warnings.filterwarnings('ignore')


def compute_iou(box1: Union[torch.Tensor, np.ndarray],
                box2: Union[torch.Tensor, np.ndarray]) -> float:
    """计算两个边界框的IoU"""
    if isinstance(box1, torch.Tensor):
        box1 = box1.cpu().numpy()
    if isinstance(box2, torch.Tensor):
        box2 = box2.cpu().numpy()

    x1_inter = max(box1[0], box2[0])
    y1_inter = max(box1[1], box2[1])
    x2_inter = min(box1[2], box2[2])
    y2_inter = min(box1[3], box2[3])

    inter_width = max(0, x2_inter - x1_inter)
    inter_height = max(0, y2_inter - y1_inter)
    inter_area = inter_width * inter_height

    box1_area = (box1[2] - box1[0]) * (box1[3] - box1[1])
    box2_area = (box2[2] - box2[0]) * (box2[3] - box2[1])
    union_area = box1_area + box2_area - inter_area

    if union_area <= 0:
        return 0.0

    return float(inter_area / union_area)


def compute_batch_iou(boxes1: torch.Tensor, boxes2: torch.Tensor) -> torch.Tensor:
    """批量计算IoU（修复维度问题）"""
    if boxes1.dim() == 1:
        boxes1 = boxes1.unsqueeze(0)
    if boxes2.dim() == 1:
        boxes2 = boxes2.unsqueeze(0)

    boxes1 = boxes1.unsqueeze(1)  # [N, 1, 4]
    boxes2 = boxes2.unsqueeze(0)  # [1, M, 4]

    x1_inter = torch.max(boxes1[..., 0], boxes2[..., 0])
    y1_inter = torch.max(boxes1[..., 1], boxes2[..., 1])
    x2_inter = torch.min(boxes1[..., 2], boxes2[..., 2])
    y2_inter = torch.min(boxes1[..., 3], boxes2[..., 3])

    inter_width = torch.clamp(x2_inter - x1_inter, min=0)
    inter_height = torch.clamp(y2_inter - y1_inter, min=0)
    inter_area = inter_width * inter_height

    boxes1_area = (boxes1[..., 2] - boxes1[..., 0]) * (boxes1[..., 3] - boxes1[..., 1])
    boxes2_area = (boxes2[..., 2] - boxes2[..., 0]) * (boxes2[..., 3] - boxes2[..., 1])
    union_area = boxes1_area + boxes2_area - inter_area

    iou = inter_area / torch.clamp(union_area, min=1e-6)

    iou = iou.squeeze(0).squeeze(0) if iou.dim() > 2 else iou

    if iou.dim() == 0:
        iou = iou.unsqueeze(0).unsqueeze(0)
    elif iou.dim() == 1:
        iou = iou.unsqueeze(0 if boxes1.size(0) == 1 else 1)

    return iou


class DetectionEvaluator:
    """目标检测综合评估器"""

    def __init__(self, device='cpu', load_models=True):
        self.device = torch.device(device) if isinstance(device, str) else device
        self.bert_model = None
        self.bert_tokenizer = None

        self.detection_classes = ['car', 'truck', 'pedestrian', 'cyclist', 'traffic_light']
        self.num_classes = len(self.detection_classes)

        if load_models:
            self.load_models()

    def load_models(self):
        """加载评估模型"""
        print("正在加载评估模型...")
        try:
            print("  [1/1] 加载BERT (文本相似度)...")
            self.bert_tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
            self.bert_model = AutoModel.from_pretrained('bert-base-uncased').to(self.device)
            self.bert_model.eval()
            print("  ✓ BERT加载完成")
        except Exception as e:
            print(f"  ✗ BERT加载失败: {e}")
        print("评估器初始化完成\n")

    def compute_text_similarity(self, text1: str, text2: str) -> float:
        """计算文本语义相似度"""
        if self.bert_model is None:
            return 0.5

        try:
            with torch.no_grad():
                encoded1 = self.bert_tokenizer(
                    text1, return_tensors='pt', padding=True,
                    truncation=True, max_length=128
                ).to(self.device)

                encoded2 = self.bert_tokenizer(
                    text2, return_tensors='pt', padding=True,
                    truncation=True, max_length=128
                ).to(self.device)

                output1 = self.bert_model(**encoded1)
                output2 = self.bert_model(**encoded2)

                emb1 = output1.last_hidden_state[:, 0, :]
                emb2 = output2.last_hidden_state[:, 0, :]

                similarity = F.cosine_similarity(emb1, emb2, dim=1)
                return (similarity.item() + 1.0) / 2.0

        except Exception as e:
            print(f"文本相似度计算错误: {e}")
            return 0.5

    def compute_nli_accuracy(self, premise: str, hypothesis: str,
                             predicted_label: int, true_label: int) -> Dict[str, float]:
        """计算NLI推理精度"""
        accuracy = 1.0 if predicted_label == true_label else 0.0
        return {
            'accuracy': accuracy,
            'confidence': 0.8 if accuracy == 1.0 else 0.2,
            'predicted': predicted_label,
            'true': true_label
        }

    def compute_detection_iou(self,
                             pred_boxes: Union[torch.Tensor, List, np.ndarray],
                             true_boxes: Union[torch.Tensor, List, np.ndarray],
                             pred_labels: Optional[List[int]] = None,
                             true_labels: Optional[List[int]] = None) -> Dict[str, float]:
        """计算目标检测IoU及相关指标"""
        try:
            if isinstance(pred_boxes, torch.Tensor):
                pred_boxes = pred_boxes.cpu().numpy()
            elif isinstance(pred_boxes, list):
                pred_boxes = np.array(pred_boxes, dtype=np.float32) if pred_boxes else np.zeros((0, 4), dtype=np.float32)
            elif isinstance(pred_boxes, np.ndarray):
                pred_boxes = pred_boxes.astype(np.float32)

            if isinstance(true_boxes, torch.Tensor):
                true_boxes = true_boxes.cpu().numpy()
            elif isinstance(true_boxes, list):
                true_boxes = np.array(true_boxes, dtype=np.float32) if true_boxes else np.zeros((0, 4), dtype=np.float32)
            elif isinstance(true_boxes, np.ndarray):
                true_boxes = true_boxes.astype(np.float32)

            if pred_boxes.ndim == 1:
                pred_boxes = pred_boxes.reshape(1, -1)
            if true_boxes.ndim == 1:
                true_boxes = true_boxes.reshape(1, -1)

            num_pred = pred_boxes.shape[0]
            num_true = true_boxes.shape[0]

            if num_pred == 0 or num_true == 0:
                return {
                    'iou': 0.0,
                    'max_iou': 0.0,
                    'mean_iou': 0.0,
                    'precision': 0.0,
                    'recall': 0.0,
                    'f1_score': 0.0,
                    'num_predictions': num_pred,
                    'num_ground_truth': num_true
                }

            pred_boxes_tensor = torch.from_numpy(pred_boxes).cpu()
            true_boxes_tensor = torch.from_numpy(true_boxes).cpu()

            iou_matrix = compute_batch_iou(pred_boxes_tensor, true_boxes_tensor)

            if iou_matrix.dim() < 2:
                iou_matrix = iou_matrix.unsqueeze(0 if num_pred == 1 else 1)

            if iou_matrix.dim() >= 2 and iou_matrix.size(1) > 0:
                max_ious_per_pred, _ = iou_matrix.max(dim=1)
            else:
                max_ious_per_pred = iou_matrix.flatten()

            max_iou = float(max_ious_per_pred.max()) if len(max_ious_per_pred) > 0 else 0.0
            mean_iou = float(max_ious_per_pred.mean()) if len(max_ious_per_pred) > 0 else 0.0

            iou_threshold = 0.5
            matched_pred = (max_ious_per_pred > iou_threshold).sum().item()

            precision = matched_pred / num_pred if num_pred > 0 else 0.0
            recall = matched_pred / num_true if num_true > 0 else 0.0
            f1_score = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

            class_accuracy = 1.0
            if pred_labels is not None and true_labels is not None and matched_pred > 0:
                _, best_matches = iou_matrix.max(dim=1)
                correct_class = 0
                for i, true_idx in enumerate(best_matches):
                    if max_ious_per_pred[i] > iou_threshold:
                        if i < len(pred_labels) and true_idx < len(true_labels):
                            if pred_labels[i] == true_labels[true_idx]:
                                correct_class += 1
                class_accuracy = correct_class / matched_pred if matched_pred > 0 else 0.0

            return {
                'iou': mean_iou,
                'max_iou': max_iou,
                'mean_iou': mean_iou,
                'precision': precision,
                'recall': recall,
                'f1_score': f1_score,
                'class_accuracy': class_accuracy,
                'num_predictions': num_pred,
                'num_ground_truth': num_true
            }

        except Exception as e:
            print(f"检测IoU计算错误: {e}")
            import traceback
            traceback.print_exc()
            return {
                'iou': 0.0,
                'max_iou': 0.0,
                'mean_iou': 0.0,
                'precision': 0.0,
                'recall': 0.0,
                'f1_score': 0.0,
                'num_predictions': 0,
                'num_ground_truth': 0
            }

    def compute_image_similarity(self, image1: torch.Tensor, image2: torch.Tensor) -> float:
        """
        计算图像相似度（修复负数问题）

        ✨ 关键修复：
        1. 确保图像值域在[0, 1]
        2. 正确处理维度
        3. 添加详细调试
        """
        try:
            # ✨ 1. 标准化输入维度
            # 确保都是 [C, H, W] 格式
            if image1.dim() == 4:
                image1 = image1.squeeze(0)  # [1, C, H, W] -> [C, H, W]
            if image2.dim() == 4:
                image2 = image2.squeeze(0)

            if image1.dim() == 2:
                image1 = image1.unsqueeze(0)  # [H, W] -> [1, H, W]
            if image2.dim() == 2:
                image2 = image2.unsqueeze(0)

            # ✨ 2. 确保在同一设备
            device = image1.device
            if image2.device != device:
                image2 = image2.to(device)

            # ✨ 3. 关键修复：确保值域在[0, 1]
            # 检测并修正值域
            img1_min, img1_max = image1.min(), image1.max()
            img2_min, img2_max = image2.min(), image2.max()

            # 如果图像在[-1, 1]范围，转换到[0, 1]
            if img1_min < -0.01 or img1_max > 1.01:
                # 可能是[-1, 1]范围，转换到[0, 1]
                if img1_min >= -1.1 and img1_max <= 1.1:
                    image1 = (image1 + 1.0) / 2.0
                    image1 = torch.clamp(image1, 0, 1)
                else:
                    # 归一化到[0, 1]
                    image1 = (image1 - img1_min) / (img1_max - img1_min + 1e-8)

            if img2_min < -0.01 or img2_max > 1.01:
                if img2_min >= -1.1 and img2_max <= 1.1:
                    image2 = (image2 + 1.0) / 2.0
                    image2 = torch.clamp(image2, 0, 1)
                else:
                    image2 = (image2 - img2_min) / (img2_max - img2_min + 1e-8)

            # 确保最终在[0, 1]
            image1 = torch.clamp(image1, 0, 1)
            image2 = torch.clamp(image2, 0, 1)

            # ✨ 4. 调整尺寸匹配
            if image1.shape != image2.shape:
                image2 = F.interpolate(
                    image2.unsqueeze(0),
                    size=image1.shape[-2:],
                    mode='bilinear',
                    align_corners=False
                ).squeeze(0)

            # ✨ 5. 计算SSIM
            similarity = self._compute_ssim_safe(image1, image2)

            # ✨ 6. 确保返回值在[0, 1]
            similarity = float(np.clip(similarity, 0.0, 1.0))

            return similarity

        except Exception as e:
            print(f"图像相似度计算错误: {e}")
            import traceback
            traceback.print_exc()
            return 0.5

    def _compute_ssim_safe(self, image1: torch.Tensor, image2: torch.Tensor) -> float:
        """
        安全的SSIM计算（修复负数问题）
        假设输入已经是[C, H, W]格式且值域在[0, 1]
        """
        try:
            # SSIM常量
            C1 = (0.01) ** 2
            C2 = (0.03) ** 2

            # 转换为4D用于池化操作
            img1_4d = image1.unsqueeze(0)  # [1, C, H, W]
            img2_4d = image2.unsqueeze(0)

            # 使用平均池化计算局部均值（3x3窗口）
            mu1 = F.avg_pool2d(img1_4d, 3, 1, 1)
            mu2 = F.avg_pool2d(img2_4d, 3, 1, 1)

            mu1_sq = mu1 ** 2
            mu2_sq = mu2 ** 2
            mu1_mu2 = mu1 * mu2

            # 计算方差和协方差
            sigma1_sq = F.avg_pool2d(img1_4d ** 2, 3, 1, 1) - mu1_sq
            sigma2_sq = F.avg_pool2d(img2_4d ** 2, 3, 1, 1) - mu2_sq
            sigma12 = F.avg_pool2d(img1_4d * img2_4d, 3, 1, 1) - mu1_mu2

            # SSIM公式
            ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / \
                       ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

            # 返回平均SSIM
            ssim_value = ssim_map.mean().item()

            # ✨ SSIM理论范围是[-1, 1]，但良好的实现应该在[0, 1]
            # 如果出现负值，说明图像差异很大，映射到0
            if ssim_value < 0:
                print(f"    警告: SSIM为负({ssim_value:.4f})，图像差异极大，返回0")
                return 0.0

            return ssim_value

        except Exception as e:
            print(f"SSIM计算错误: {e}")
            # 降级到MSE相似度
            try:
                mse = F.mse_loss(image1, image2)
                # MSE转相似度：1 / (1 + MSE)
                similarity = 1.0 / (1.0 + mse.item())
                print(f"    降级使用MSE相似度: {similarity:.4f}")
                return similarity
            except:
                return 0.5

    def compute_comprehensive_metrics(self,
                                      original_data: Union[str, torch.Tensor],
                                      reconstructed_data: Union[str, torch.Tensor, List],
                                      data_type: str,
                                      metadata: Dict) -> Dict[str, float]:
        """计算综合评估指标"""
        metrics = {}

        if data_type == 'text':
            if isinstance(original_data, str) and isinstance(reconstructed_data, str):
                metrics['text_similarity'] = self.compute_text_similarity(original_data, reconstructed_data)
            else:
                metrics['text_similarity'] = 0.5

            if 'premise' in metadata and 'hypothesis' in metadata:
                nli_result = self.compute_nli_accuracy(
                    premise=metadata.get('premise', ''),
                    hypothesis=metadata.get('hypothesis', ''),
                    predicted_label=metadata.get('predicted_label', 0),
                    true_label=metadata.get('true_label', 0)
                )
                metrics['nli_accuracy'] = nli_result['accuracy']
                metrics['nli_confidence'] = nli_result['confidence']
            else:
                metrics['nli_accuracy'] = 0.0
                metrics['nli_confidence'] = 0.5

        elif data_type == 'detection':
            if isinstance(original_data, torch.Tensor) and isinstance(reconstructed_data, torch.Tensor):
                metrics['image_similarity'] = self.compute_image_similarity(original_data, reconstructed_data)
            else:
                metrics['image_similarity'] = 0.5

            if 'pred_boxes' in metadata and 'true_boxes' in metadata:
                detection_result = self.compute_detection_iou(
                    pred_boxes=metadata.get('pred_boxes', []),
                    true_boxes=metadata.get('true_boxes', []),
                    pred_labels=metadata.get('pred_labels', None),
                    true_labels=metadata.get('true_labels', None)
                )
                metrics['detection_iou'] = detection_result['iou']
                metrics['detection_precision'] = detection_result['precision']
                metrics['detection_recall'] = detection_result['recall']
                metrics['detection_f1'] = detection_result['f1_score']
                metrics['max_iou'] = detection_result['max_iou']
                metrics['mean_iou'] = detection_result['mean_iou']
            else:
                metrics['detection_iou'] = 0.0
                metrics['detection_precision'] = 0.0
                metrics['detection_recall'] = 0.0
                metrics['detection_f1'] = 0.0

        return metrics

    def get_model_info(self) -> dict:
        """获取模型信息"""
        return {
            'bert_loaded': self.bert_model is not None,
            'detection_classes': self.detection_classes,
            'num_classes': self.num_classes,
            'device': str(self.device)
        }


# 别名
class AccuracyEvaluator(DetectionEvaluator):
    pass