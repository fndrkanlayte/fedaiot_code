from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.plotting import write_accuracy_comparison, write_air_table
from fedssv.utils import load_config
from scripts.fig3_common import (
    AGGREGATORS,
    ATTACKS,
    run_name,
    write_benign_near_zero_stats,
    write_malicious_attack_detail,
    write_malicious_weight_summary,
)


PREFIX = "fig3_paper_like_fmnist"


def main() -> None:
    parser = argparse.ArgumentParser(description="Finalize Fashion-MNIST Fig. 3 paper-like outputs.")
    parser.add_argument("--config", default="configs/fig3_paper_like_fmnist.yaml")
    args = parser.parse_args()

    config = load_config(args.config)
    attack_rounds = [int(x) for x in config["attack_rounds"]]
    run_dirs = [Path("outputs") / "runs" / run_name(PREFIX, agg, attack) for attack in ATTACKS for agg in AGGREGATORS]
    missing = [str(run_dir) for run_dir in run_dirs if not (run_dir / "summary.json").exists()]
    if missing:
        raise FileNotFoundError("Missing completed runs: " + ", ".join(missing))

    summary_dir = Path("outputs") / "runs" / "fig3_paper_like_summary"
    summary_dir.mkdir(parents=True, exist_ok=True)
    write_air_table(run_dirs, summary_dir / "air_table.csv")
    write_malicious_attack_detail(run_dirs, summary_dir / "malicious_attack_detail.csv", attack_rounds, 2)
    write_benign_near_zero_stats(run_dirs, summary_dir / "benign_near_zero_stats.csv", attack_rounds, 0.01)
    for run_dir in run_dirs:
        write_malicious_weight_summary(run_dir, run_dir / "malicious_vs_benign_weight.csv")
    for attack in ATTACKS:
        dirs = [Path("outputs") / "runs" / run_name(PREFIX, agg, attack) for agg in AGGREGATORS]
        write_accuracy_comparison(
            dirs,
            summary_dir / f"{attack.replace('-', '_')}_accuracy_comparison.svg",
            f"{attack} accuracy vs round",
        )
    print(summary_dir)


if __name__ == "__main__":
    main()
