from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def read_by_key(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return {(row["round"], row["client_id"]): row for row in csv.DictReader(f)}


def main() -> None:
    parser = argparse.ArgumentParser(description="Merge client weights and update norms around an attack round.")
    parser.add_argument("run_dir")
    parser.add_argument("--attack-round", type=int, default=10)
    parser.add_argument("--window", type=int, default=2)
    parser.add_argument("--output")
    args = parser.parse_args()

    run_dir = Path(args.run_dir)
    weights = read_by_key(run_dir / "client_weights.csv")
    norms = read_by_key(run_dir / "update_norms.csv")
    rounds = {str(r) for r in range(args.attack_round - args.window, args.attack_round + args.window + 1)}
    rows = []
    for key in sorted(weights, key=lambda x: (int(x[0]), int(x[1]))):
        if key[0] not in rounds:
            continue
        weight_row = weights[key]
        norm_row = norms[key]
        rows.append(
            {
                "round": weight_row["round"],
                "client_id": weight_row["client_id"],
                "is_malicious": weight_row["is_malicious"],
                "shapley_value": weight_row["shapley_value"],
                "reputation": weight_row["reputation"],
                "weight": weight_row["weight"],
                "update_norm_before_attack": norm_row["update_norm_before_attack"],
                "update_norm_after_attack": norm_row["update_norm_after_attack"],
            }
        )

    output = Path(args.output) if args.output else run_dir / f"attack_round_{args.attack_round}_detail.csv"
    with output.open("w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "round",
            "client_id",
            "is_malicious",
            "shapley_value",
            "reputation",
            "weight",
            "update_norm_before_attack",
            "update_norm_after_attack",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(output)


if __name__ == "__main__":
    main()
