from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.plotting import _svg_chart
from fedssv.utils import load_config
from scripts.run_experiment import expand_experiments


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _run_dirs_from_config(config_path: str | None) -> list[Path]:
    if not config_path:
        return []
    configs = expand_experiments(load_config(config_path))
    return [Path("outputs") / "runs" / config["run_name"] for config in configs]


def _existing_run_dirs(config_path: str | None, explicit: list[str]) -> list[Path]:
    dirs = [Path(item) for item in explicit]
    dirs.extend(_run_dirs_from_config(config_path))
    existing = []
    for run_dir in dirs:
        if (run_dir / "metrics.csv").exists() and (run_dir / "summary.json").exists():
            existing.append(run_dir)
        else:
            print(f"skip missing run output: {run_dir}")
    return existing


def _label(run_dir: Path) -> str:
    summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    method = summary.get("method") or summary.get("aggregator") or run_dir.name
    attack = summary.get("attack") or summary.get("attack_settings", {}).get("type", "none")
    return f"{method}-{attack}"


def plot_accuracy(run_dirs: list[Path], output: Path, title: str) -> None:
    series = {}
    for run_dir in run_dirs:
        rows = _read_csv(run_dir / "metrics.csv")
        series[_label(run_dir)] = [(float(row["round"]), float(row["test_accuracy"])) for row in rows]
    if not series:
        print("no completed runs found; nothing to plot")
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    _svg_chart(series, title, output)
    print(output)


def _first_air(summary: dict[str, Any]) -> float | None:
    values = list(summary.get("air_summary", {}).values())
    for value in values:
        if value == "NA" or value == "":
            continue
        return float(value)
    return None


def _sweep_value(summary: dict[str, Any], key: str) -> float:
    config_path = Path("outputs") / "runs" / summary["run_name"] / "config.yaml"
    if config_path.exists():
        config = load_config(config_path)
        target: Any = config
        for part in key.split("."):
            target = target[part]
        return float(target)
    raise KeyError(f"Cannot infer sweep value {key} for {summary['run_name']}")


def plot_air_sweep(run_dirs: list[Path], output: Path, title: str, sweep_key: str) -> None:
    series: dict[str, list[tuple[float, float]]] = {}
    for run_dir in run_dirs:
        summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        air = _first_air(summary)
        if air is None:
            continue
        method = summary.get("method") or summary.get("aggregator") or "method"
        try:
            x_value = _sweep_value(summary, sweep_key)
        except Exception as exc:
            print(f"skip {run_dir}: {exc}")
            continue
        series.setdefault(str(method), []).append((x_value, air))
    for values in series.values():
        values.sort()
    if not series:
        print("no AIR sweep data found; nothing to plot")
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    _svg_chart(series, title, output)
    print(output)


def plot_fig8(run_dirs: list[Path], output_dir: Path) -> None:
    runtime_series: dict[str, list[tuple[float, float]]] = {"runtime": []}
    eval_series: dict[str, list[tuple[float, float]]] = {"utility_evaluations": []}
    accuracy_series: dict[str, list[tuple[float, float]]] = {"accuracy": []}
    for run_dir in run_dirs:
        summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
        config = load_config(run_dir / "config.yaml")
        clients = float(config.get("num_clients", 0))
        runtime = summary.get("runtime_summary", {})
        runtime_series["runtime"].append((clients, float(runtime.get("total_runtime_seconds", 0.0))))
        eval_series["utility_evaluations"].append((clients, float(runtime.get("total_utility_evaluation_count", 0.0))))
        accuracy_series["accuracy"].append((clients, float(summary.get("final_accuracy", 0.0))))
    if not run_dirs:
        print("no completed Fig.8 runs found; nothing to plot")
        return
    output_dir.mkdir(parents=True, exist_ok=True)
    _svg_chart(runtime_series, "Fig.8 MC-FedSSV runtime", output_dir / "fig8_runtime.svg")
    _svg_chart(eval_series, "Fig.8 utility evaluation count", output_dir / "fig8_utility_evaluations.svg")
    _svg_chart(accuracy_series, "Fig.8 accuracy", output_dir / "fig8_accuracy.svg")
    print(output_dir)


def write_table(run_dirs: list[Path], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["run_name", "dataset", "split", "method", "attack", "final_accuracy", "air_summary"])
        for run_dir in run_dirs:
            summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
            writer.writerow(
                [
                    summary.get("run_name"),
                    summary.get("dataset"),
                    summary.get("split_type"),
                    summary.get("method") or summary.get("aggregator"),
                    summary.get("attack"),
                    summary.get("final_accuracy"),
                    json.dumps(summary.get("air_summary", {})),
                ]
            )
    print(output)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate paper-style plots from completed run outputs.")
    parser.add_argument(
        "--figure",
        required=True,
        choices=["fig2", "fig3", "fig4", "fig5", "fig6", "fig7", "fig8", "table4"],
    )
    parser.add_argument("--config", help="Config used to infer expected run directories.")
    parser.add_argument("--runs", nargs="*", default=[], help="Explicit run directories.")
    parser.add_argument("--output", default="outputs/figures/plot.svg")
    parser.add_argument("--sweep-key", default="", help="For Fig.4/Fig.5, e.g. attacks.scaling_factor or malicious_ratio.")
    args = parser.parse_args()

    run_dirs = _existing_run_dirs(args.config, args.runs)
    output = Path(args.output)
    if args.figure in {"fig2", "fig3", "fig6", "fig7"}:
        plot_accuracy(run_dirs, output, f"{args.figure.upper()} accuracy vs round")
    elif args.figure in {"fig4", "fig5"}:
        if not args.sweep_key:
            raise ValueError("--sweep-key is required for Fig.4/Fig.5")
        plot_air_sweep(run_dirs, output, f"{args.figure.upper()} AIR sweep", args.sweep_key)
    elif args.figure == "fig8":
        plot_fig8(run_dirs, output if output.suffix == "" else output.parent)
    elif args.figure == "table4":
        write_table(run_dirs, output)


if __name__ == "__main__":
    main()
