from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.plotting import write_accuracy_comparison, write_air_table
from fedssv.server import run_experiment
from fedssv.utils import deepcopy_config, load_config


ATTACKS = ["scaling", "sign-flip", "gaussian", "gaussian-sfa"]
AGGREGATORS = ["fedavg", "fedssv"]


def run_name(aggregator: str, attack: str) -> str:
    return f"fig3_smoke_fmnist_{aggregator}_{attack.replace('-', '')}"


def build_config(base: dict, aggregator: str, attack: str) -> dict:
    config = deepcopy_config(base)
    config["run_name"] = run_name(aggregator, attack)
    config["aggregator"] = aggregator
    config["attacks"]["enabled"] = True
    config["attacks"]["type"] = attack
    return config


def write_malicious_weight_summary(run_dir: Path, output_path: Path) -> None:
    with (run_dir / "client_weights.csv").open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    by_round: dict[str, dict[str, list[float]]] = {}
    for row in rows:
        bucket = by_round.setdefault(row["round"], {"malicious": [], "benign": []})
        key = "malicious" if row["is_malicious"] == "True" else "benign"
        bucket[key].append(float(row["weight"]))
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["round", "malicious_average_weight", "benign_average_weight"])
        for round_id in sorted(by_round, key=int):
            values = by_round[round_id]
            mal = sum(values["malicious"]) / len(values["malicious"])
            benign = sum(values["benign"]) / len(values["benign"])
            writer.writerow([round_id, mal, benign])


def write_benign_near_zero_stats(run_dirs: list[Path], output_path: Path, attack_round: int, threshold: float) -> None:
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["run_name", "threshold", "non_attack_benign_near_zero_count", "rows"])
        for run_dir in run_dirs:
            with (run_dir / "client_weights.csv").open(newline="", encoding="utf-8") as rf:
                rows = list(csv.DictReader(rf))
            flagged = [
                {
                    "round": row["round"],
                    "client_id": row["client_id"],
                    "shapley_value": row["shapley_value"],
                    "weight": row["weight"],
                }
                for row in rows
                if int(row["round"]) != attack_round
                and row["is_malicious"] == "False"
                and float(row["weight"]) < threshold
            ]
            writer.writerow([run_dir.name, threshold, len(flagged), json.dumps(flagged)])


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Fig. 3 smoke reproduction.")
    parser.add_argument("--config", default="configs/fig3_smoke_fmnist.yaml")
    parser.add_argument("--only", choices=[f"{a}:{g}" for a in ATTACKS for g in AGGREGATORS])
    args = parser.parse_args()

    base = load_config(args.config)
    selected = []
    for attack in ATTACKS:
        for aggregator in AGGREGATORS:
            if args.only and args.only != f"{attack}:{aggregator}":
                continue
            config = build_config(base, aggregator, attack)
            summary = run_experiment(config)
            selected.append(Path("outputs") / "runs" / summary["run_name"])

    summary_dir = Path("outputs") / "runs" / "fig3_smoke_summary"
    summary_dir.mkdir(parents=True, exist_ok=True)
    if selected:
        write_air_table(selected, summary_dir / "air_table.csv")
        attack_round = int(base["attack_rounds"][0])
        for run_dir in selected:
            write_malicious_weight_summary(run_dir, run_dir / "malicious_vs_benign_weight.csv")
        write_benign_near_zero_stats(selected, summary_dir / "benign_near_zero_stats.csv", attack_round, 0.01)
    if not args.only:
        for attack in ATTACKS:
            dirs = [Path("outputs") / "runs" / run_name(agg, attack) for agg in AGGREGATORS]
            write_accuracy_comparison(
                dirs,
                summary_dir / f"{attack.replace('-', '_')}_accuracy_comparison.svg",
                f"{attack} accuracy vs round",
            )


if __name__ == "__main__":
    main()
