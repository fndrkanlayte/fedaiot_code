from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.plotting import write_air_table
from fedssv.server import run_experiment
from fedssv.utils import deepcopy_config, load_config


EXPERIMENTS = {
    "E1": {"run_name": "phase1_fmnist_fedavg_no_attack", "aggregator": "fedavg", "attack": "none"},
    "E2": {"run_name": "phase1_fmnist_fedssv_no_attack", "aggregator": "fedssv", "attack": "none"},
    "E3": {"run_name": "phase1_fmnist_fedavg_scaling", "aggregator": "fedavg", "attack": "scaling"},
    "E4": {"run_name": "phase1_fmnist_fedssv_scaling", "aggregator": "fedssv", "attack": "scaling"},
    "E5": {"run_name": "phase1_fmnist_fedavg_signflip", "aggregator": "fedavg", "attack": "sign-flip"},
    "E6": {"run_name": "phase1_fmnist_fedssv_signflip", "aggregator": "fedssv", "attack": "sign-flip"},
}


def config_for(base: dict, key: str) -> dict:
    exp = EXPERIMENTS[key]
    config = deepcopy_config(base)
    config["run_name"] = exp["run_name"]
    config["aggregator"] = exp["aggregator"]
    attack_type = exp["attack"]
    config["attacks"]["type"] = attack_type
    config["attacks"]["enabled"] = attack_type != "none"
    return config


def main() -> None:
    parser = argparse.ArgumentParser(description="Run phase-one FedSSV experiments.")
    parser.add_argument("--config", default="configs/phase1_fmnist.yaml")
    parser.add_argument("--experiment", default="all", choices=["all", *EXPERIMENTS.keys()])
    parser.add_argument("--utility-metric", choices=["val_accuracy", "negative_val_loss"])
    parser.add_argument("--shapley-max-batches", type=int, help="Override shapley.max_batches.")
    parser.add_argument("--run-name", help="Override run_name for a single experiment.")
    args = parser.parse_args()

    base = load_config(args.config)
    keys = list(EXPERIMENTS) if args.experiment == "all" else [args.experiment]
    run_dirs = []
    for key in keys:
        config = config_for(base, key)
        if args.run_name:
            if len(keys) != 1:
                raise ValueError("--run-name can only be used with a single experiment")
            config["run_name"] = args.run_name
        if args.utility_metric:
            config["shapley"]["utility_metric"] = args.utility_metric
        if args.shapley_max_batches is not None:
            config["shapley"]["max_batches"] = args.shapley_max_batches
        summary = run_experiment(config)
        run_dirs.append(Path("outputs") / "runs" / summary["run_name"])
    if len(run_dirs) > 1:
        phase_dir = Path("outputs") / "runs" / "phase1_summary"
        phase_dir.mkdir(parents=True, exist_ok=True)
        write_air_table(run_dirs, phase_dir / "air_table.csv")


if __name__ == "__main__":
    main()
