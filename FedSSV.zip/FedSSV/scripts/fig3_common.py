from __future__ import annotations

import csv
import json
from pathlib import Path


ATTACKS = ["scaling", "sign-flip", "gaussian", "gaussian-sfa"]
AGGREGATORS = ["fedavg", "fedssv"]


def run_name(prefix: str, aggregator: str, attack: str) -> str:
    return f"{prefix}_{aggregator}_{attack.replace('-', '')}"


def read_by_key(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return {(row["round"], row["client_id"]): row for row in csv.DictReader(f)}


def write_malicious_weight_summary(run_dir: Path, output_path: Path) -> None:
    with (run_dir / "client_weights.csv").open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    by_round: dict[str, dict[str, list[float]]] = {}
    for row in rows:
        bucket = by_round.setdefault(row["round"], {"malicious": [], "benign": []})
        key = "malicious" if row["is_malicious"] == "True" else "benign"
        bucket[key].append(float(row["weight"]))
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["round", "malicious_average_weight", "benign_average_weight"])
        for round_id in sorted(by_round, key=int):
            values = by_round[round_id]
            malicious_avg = sum(values["malicious"]) / len(values["malicious"])
            benign_avg = sum(values["benign"]) / len(values["benign"])
            writer.writerow([round_id, malicious_avg, benign_avg])


def write_benign_near_zero_stats(
    run_dirs: list[Path], output_path: Path, attack_rounds: list[int], threshold: float
) -> None:
    attack_round_set = set(attack_rounds)
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["run_name", "threshold", "non_attack_benign_near_zero_count", "rows"])
        for run_dir in run_dirs:
            with (run_dir / "client_weights.csv").open(newline="", encoding="utf-8") as rf:
                rows = list(csv.DictReader(rf))
            flagged = [
                {
                    "round": row["round"],
                    "client_id": row["client_id"],
                    "shapley_value": row["shapley_value"],
                    "weight": row["weight"],
                }
                for row in rows
                if int(row["round"]) not in attack_round_set
                and row["is_malicious"] == "False"
                and float(row["weight"]) < threshold
            ]
            writer.writerow([run_dir.name, threshold, len(flagged), json.dumps(flagged)])


def write_malicious_attack_detail(
    run_dirs: list[Path], output_path: Path, attack_rounds: list[int], window: int
) -> None:
    fieldnames = [
        "run_name",
        "attack_type",
        "aggregator",
        "round",
        "client_id",
        "is_malicious",
        "shapley_value",
        "reputation",
        "weight",
        "update_norm_before_attack",
        "update_norm_after_attack",
    ]
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for run_dir in run_dirs:
            summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
            weights = read_by_key(run_dir / "client_weights.csv")
            norms = read_by_key(run_dir / "update_norms.csv")
            for key in sorted(weights, key=lambda x: (int(x[0]), int(x[1]))):
                round_id = int(key[0])
                if all(abs(round_id - attack_round) > window for attack_round in attack_rounds):
                    continue
                weight_row = weights[key]
                if weight_row["is_malicious"] != "True":
                    continue
                norm_row = norms[key]
                writer.writerow(
                    {
                        "run_name": run_dir.name,
                        "attack_type": summary["attack_settings"]["type"],
                        "aggregator": summary["aggregator"],
                        "round": weight_row["round"],
                        "client_id": weight_row["client_id"],
                        "is_malicious": weight_row["is_malicious"],
                        "shapley_value": weight_row["shapley_value"],
                        "reputation": weight_row["reputation"],
                        "weight": weight_row["weight"],
                        "update_norm_before_attack": norm_row["update_norm_before_attack"],
                        "update_norm_after_attack": norm_row["update_norm_after_attack"],
                    }
                )
