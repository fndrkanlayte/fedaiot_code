from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.server import run_experiment
from fedssv.utils import deepcopy_config, load_config


SCENARIOS = [
    {
        "name": "fmnist_noniid_afedsv_scaling",
        "dataset": "Fashion-MNIST",
        "split": "non-iid",
        "aggregator": "afedsv",
        "attack": "scaling",
    },
    {
        "name": "fmnist_iid_trimmed_minmax",
        "dataset": "Fashion-MNIST",
        "split": "iid",
        "aggregator": "trimmed_mean",
        "attack": "min-max",
    },
    {
        "name": "fmnist_iid_multikrum_gaussian",
        "dataset": "Fashion-MNIST",
        "split": "iid",
        "aggregator": "multi_krum",
        "attack": "gaussian",
    },
    {
        "name": "cifar10_iid_fedssv_gaussiansfa",
        "dataset": "CIFAR-10",
        "split": "iid",
        "aggregator": "fedssv",
        "attack": "gaussian-sfa",
    },
]


def build_config(base: dict, scenario: dict) -> dict:
    config = deepcopy_config(base)
    config["run_name"] = f"full_logic_smoke_{scenario['name']}"
    config["dataset"] = scenario["dataset"]
    config["split"] = scenario["split"]
    config["aggregator"] = scenario["aggregator"]
    config["attacks"]["type"] = scenario["attack"]
    config["attacks"]["enabled"] = True
    if scenario["dataset"].lower().startswith("cifar"):
        config["max_train_samples"] = min(int(config["max_train_samples"]), 800)
        config["max_val_samples"] = min(int(config["max_val_samples"]), 200)
        config["max_test_samples"] = min(int(config["max_test_samples"]), 400)
    return config


def main() -> None:
    parser = argparse.ArgumentParser(description="Run tiny smoke tests for full reproduction logic.")
    parser.add_argument("--config", default="configs/full_logic_smoke.yaml")
    parser.add_argument("--only", choices=[scenario["name"] for scenario in SCENARIOS])
    args = parser.parse_args()

    base = load_config(args.config)
    for scenario in SCENARIOS:
        if args.only and scenario["name"] != args.only:
            continue
        run_experiment(build_config(base, scenario))


if __name__ == "__main__":
    main()
