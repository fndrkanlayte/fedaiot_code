from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.plotting import write_accuracy_comparison, write_air_table
from scripts.run_fig3_smoke import AGGREGATORS, ATTACKS, run_name, write_benign_near_zero_stats, write_malicious_weight_summary


def read_by_key(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as f:
        return {(row["round"], row["client_id"]): row for row in csv.DictReader(f)}


def write_malicious_attack_detail(run_dirs: list[Path], output_path: Path, attack_round: int, window: int) -> None:
    fieldnames = [
        "run_name",
        "attack_type",
        "aggregator",
        "round",
        "client_id",
        "is_malicious",
        "shapley_value",
        "reputation",
        "weight",
        "update_norm_before_attack",
        "update_norm_after_attack",
    ]
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for run_dir in run_dirs:
            summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
            weights = read_by_key(run_dir / "client_weights.csv")
            norms = read_by_key(run_dir / "update_norms.csv")
            for key in sorted(weights, key=lambda x: (int(x[0]), int(x[1]))):
                round_id = int(key[0])
                if abs(round_id - attack_round) > window:
                    continue
                weight_row = weights[key]
                if weight_row["is_malicious"] != "True":
                    continue
                norm_row = norms[key]
                writer.writerow(
                    {
                        "run_name": run_dir.name,
                        "attack_type": summary["attack_settings"]["type"],
                        "aggregator": summary["aggregator"],
                        "round": weight_row["round"],
                        "client_id": weight_row["client_id"],
                        "is_malicious": weight_row["is_malicious"],
                        "shapley_value": weight_row["shapley_value"],
                        "reputation": weight_row["reputation"],
                        "weight": weight_row["weight"],
                        "update_norm_before_attack": norm_row["update_norm_before_attack"],
                        "update_norm_after_attack": norm_row["update_norm_after_attack"],
                    }
                )


def main() -> None:
    attack_round = 15
    run_dirs = [Path("outputs") / "runs" / run_name(agg, attack) for attack in ATTACKS for agg in AGGREGATORS]
    summary_dir = Path("outputs") / "runs" / "fig3_smoke_summary"
    summary_dir.mkdir(parents=True, exist_ok=True)

    write_air_table(run_dirs, summary_dir / "air_table.csv")
    write_malicious_attack_detail(run_dirs, summary_dir / "malicious_attack_detail.csv", attack_round, 2)
    write_benign_near_zero_stats(run_dirs, summary_dir / "benign_near_zero_stats.csv", attack_round, 0.01)
    for run_dir in run_dirs:
        write_malicious_weight_summary(run_dir, run_dir / "malicious_vs_benign_weight.csv")
    for attack in ATTACKS:
        dirs = [Path("outputs") / "runs" / run_name(agg, attack) for agg in AGGREGATORS]
        write_accuracy_comparison(
            dirs,
            summary_dir / f"{attack.replace('-', '_')}_accuracy_comparison.svg",
            f"{attack} accuracy vs round",
        )
    print(summary_dir)


if __name__ == "__main__":
    main()
