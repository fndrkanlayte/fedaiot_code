from __future__ import annotations

import argparse
import itertools
import re
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.server import run_experiment
from fedssv.attacks import malicious_client_ids, planned_attack_groups
from fedssv.utils import deepcopy_config, load_config


def _slug(value: Any) -> str:
    text = str(value).lower().replace("fashion-mnist", "fmnist").replace("cifar-10", "cifar10")
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    return text or "none"


def _set_nested(config: dict[str, Any], dotted_key: str, value: Any) -> None:
    target = config
    parts = dotted_key.split(".")
    for part in parts[:-1]:
        target = target.setdefault(part, {})
    target[parts[-1]] = value


def _attack_variants(config: dict[str, Any]) -> list[dict[str, Any]]:
    if "attacks_matrix" in config:
        return list(config["attacks_matrix"])
    attack = deepcopy_config(config.get("attacks", {"enabled": False, "type": "none"}))
    return [attack]


def _sweep_variants(config: dict[str, Any]) -> list[tuple[str | None, Any | None]]:
    sweep = config.get("sweep")
    if not sweep:
        return [(None, None)]
    return [(str(sweep["parameter"]), value) for value in sweep.get("values", [])]


def expand_experiments(config: dict[str, Any], max_rounds_override: int | None = None) -> list[dict[str, Any]]:
    experiment_name = str(config.get("experiment_name", config.get("run_name", "experiment")))
    methods = config.get("methods") or config.get("aggregators") or [config.get("aggregator", "fedavg")]
    seeds = config.get("seeds") or [config.get("seed", 42)]
    attacks = _attack_variants(config)
    sweeps = _sweep_variants(config)
    run_name_pattern = config.get(
        "run_name_pattern",
        "{experiment}_{dataset}_{split}_{method}_{attack}{sweep_suffix}_seed{seed}",
    )

    expanded = []
    for method, seed, attack, (sweep_key, sweep_value) in itertools.product(methods, seeds, attacks, sweeps):
        run_config = deepcopy_config(config)
        for orchestration_key in ["methods", "aggregators", "seeds", "attacks_matrix", "sweep", "run_name_pattern"]:
            run_config.pop(orchestration_key, None)
        run_config["aggregator"] = method
        run_config["seed"] = int(seed)
        run_config["attacks"] = deepcopy_config(attack)
        attack_type = str(run_config["attacks"].get("type", "none"))
        run_config["attacks"]["enabled"] = bool(run_config["attacks"].get("enabled", attack_type != "none"))
        if sweep_key is not None:
            _set_nested(run_config, sweep_key, sweep_value)
            overrides = config.get("sweep_overrides", {}).get(str(sweep_value), {})
            for key, value in overrides.items():
                _set_nested(run_config, key, value)
        if max_rounds_override is not None:
            run_config["rounds"] = int(max_rounds_override)

        sweep_suffix = ""
        if sweep_key is not None:
            sweep_suffix = f"_{_slug(sweep_key.split('.')[-1])}{_slug(sweep_value)}"
        run_config["run_name"] = run_name_pattern.format(
            experiment=_slug(experiment_name),
            dataset=_slug(run_config.get("dataset", "dataset")),
            split=_slug(run_config.get("split", "iid")),
            method=_slug(method),
            attack=_slug(attack_type),
            sweep_suffix=sweep_suffix,
            seed=seed,
        )
        expanded.append(run_config)
    return expanded


def validate_config(config: dict[str, Any]) -> None:
    required = [
        "dataset",
        "num_clients",
        "rounds",
        "local_epochs",
        "batch_size",
        "lr",
        "malicious_ratio",
        "attack_rounds",
        "shapley",
        "fedssv",
    ]
    missing = [key for key in required if key not in config]
    if missing:
        raise ValueError(f"Missing required config keys: {missing}")
    if "utility_metric" not in config["shapley"]:
        raise ValueError("Missing shapley.utility_metric")
    if "method" not in config["shapley"]:
        raise ValueError("Missing shapley.method")


def print_matrix(configs: list[dict[str, Any]]) -> None:
    print(f"planned_runs={len(configs)}")
    for idx, config in enumerate(configs, start=1):
        attack = config.get("attacks", {}).get("type", "none")
        print(
            f"{idx:03d} run_name={config['run_name']} dataset={config['dataset']} "
            f"split={config.get('split', 'iid')} method={config['aggregator']} attack={attack} "
            f"clients={config['num_clients']} rounds={config['rounds']} seed={config['seed']} "
            f"shapley={config['shapley']['method']} max_batches={config['shapley'].get('max_batches')}"
        )
        if attack in {"gaussian-sfa", "gaussian_sfa"}:
            malicious = malicious_client_ids(int(config["num_clients"]), float(config.get("malicious_ratio", 0.0)))
            groups = planned_attack_groups(int(config["num_clients"]), malicious, config.get("attacks", {}))
            print(
                f"    gaussian_clients={groups.get('gaussian_attack_clients', [])} "
                f"sfa_clients={groups.get('sfa_attack_clients', [])} overlap={groups.get('overlap')}"
            )
        if str(config.get("split", "")).lower() in {"table_v_exact", "table-v-exact"}:
            print("    split_summary=Table V exact distribution, num_clients must be 10")
        if config.get("table_v_repeat_distribution", False):
            print(
                "    split_summary=Table V repeat distribution for scalability assumption "
                f"with_replacement={config.get('table_v_repeat_with_replacement', False)}"
            )


def main() -> None:
    parser = argparse.ArgumentParser(description="Unified paper reproduction runner.")
    parser.add_argument("--config", required=True, help="Path to a paper reproduction YAML config.")
    parser.add_argument("--dry-run", action="store_true", help="Validate config and print the run matrix without training.")
    parser.add_argument("--max-rounds-override", type=int, help="Override rounds for a tiny smoke/preflight run.")
    parser.add_argument("--only", help="Run only entries whose generated run_name contains this substring.")
    args = parser.parse_args()

    base = load_config(args.config)
    validate_config(base)
    configs = expand_experiments(base, args.max_rounds_override)
    if args.only:
        configs = [config for config in configs if args.only in config["run_name"]]
    print_matrix(configs)
    if args.dry_run:
        return
    for config in configs:
        run_experiment(config)


if __name__ == "__main__":
    main()
