from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedssv.server import run_experiment
from fedssv.utils import deepcopy_config, load_config
from scripts.fig3_common import AGGREGATORS, ATTACKS, run_name


PREFIX = "fig3_paper_like_fmnist"


def build_config(base: dict, aggregator: str, attack: str) -> dict:
    config = deepcopy_config(base)
    config["run_name"] = run_name(PREFIX, aggregator, attack)
    config["aggregator"] = aggregator
    config["attacks"]["enabled"] = True
    config["attacks"]["type"] = attack
    return config


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Fashion-MNIST Fig. 3 paper-like reproduction.")
    parser.add_argument("--config", default="configs/fig3_paper_like_fmnist.yaml")
    parser.add_argument("--only", choices=[f"{a}:{g}" for a in ATTACKS for g in AGGREGATORS])
    parser.add_argument("--rounds", type=int, help="Override rounds for preflight or resume checks.")
    parser.add_argument("--run-name-suffix", default="", help="Optional suffix for diagnostic runs.")
    args = parser.parse_args()

    base = load_config(args.config)
    for attack in ATTACKS:
        for aggregator in AGGREGATORS:
            if args.only and args.only != f"{attack}:{aggregator}":
                continue
            config = build_config(base, aggregator, attack)
            if args.rounds is not None:
                config["rounds"] = args.rounds
            if args.run_name_suffix:
                config["run_name"] = f"{config['run_name']}_{args.run_name_suffix}"
            run_experiment(config)


if __name__ == "__main__":
    main()
