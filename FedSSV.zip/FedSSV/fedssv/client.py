from __future__ import annotations

import torch
from torch import nn
from torch.utils.data import DataLoader

from .models import build_model
from .utils import clone_state_dict, state_dict_subtract


def train_client(
    global_state: dict[str, torch.Tensor],
    loader: DataLoader,
    device: torch.device,
    lr: float,
    momentum: float,
    local_epochs: int,
    input_channels: int = 1,
) -> tuple[dict[str, torch.Tensor], float]:
    model = build_model(input_channels=input_channels).to(device)
    model.load_state_dict(global_state)
    model.train()
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum)
    last_loss = 0.0
    for _ in range(local_epochs):
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(x), y)
            loss.backward()
            optimizer.step()
            last_loss = float(loss.item())
    local_state = clone_state_dict(model.state_dict())
    return state_dict_subtract(local_state, global_state), last_loss


def train_centralized(
    loader: DataLoader,
    test_loader: DataLoader,
    device: torch.device,
    lr: float,
    momentum: float,
    epochs: int,
    evaluate_fn,
    input_channels: int = 1,
) -> dict[str, float]:
    model = build_model(input_channels=input_channels).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum)
    losses = []
    for _ in range(epochs):
        model.train()
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(x), y)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.item()))
    test_metrics = evaluate_fn(model, test_loader, device)
    return {
        "final_train_loss": losses[-1] if losses else float("nan"),
        "test_loss": test_metrics["loss"],
        "test_accuracy": test_metrics["accuracy"],
    }
