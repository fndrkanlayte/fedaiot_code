from __future__ import annotations

import itertools
import math
import time
from typing import Callable

import torch
from .aggregators import aggregate_updates
from .models import build_model
from .utils import state_dict_add


def coalition_utility(
    base_state: dict[str, torch.Tensor],
    updates: list[dict[str, torch.Tensor]],
    coalition: tuple[int, ...],
    val_loader,
    device: torch.device,
    utility_metric: str,
    evaluate_fn: Callable,
    max_batches: int | None,
    input_channels: int = 1,
) -> float:
    model = build_model(input_channels=input_channels).to(device)
    if coalition:
        weights = [1.0 / len(coalition)] * len(coalition)
        selected_updates = [updates[i] for i in coalition]
        agg_update = aggregate_updates(selected_updates, weights)
        model.load_state_dict(state_dict_add(base_state, agg_update))
    else:
        model.load_state_dict(base_state)
    metrics = evaluate_fn(model, val_loader, device, max_batches=max_batches)
    if utility_metric == "val_accuracy":
        return float(metrics["accuracy"])
    if utility_metric == "negative_val_loss":
        return -float(metrics["loss"])
    raise ValueError(f"Unsupported utility_metric: {utility_metric}")


def exact_shapley(
    base_state: dict[str, torch.Tensor],
    updates: list[dict[str, torch.Tensor]],
    val_loader,
    device: torch.device,
    utility_metric: str,
    evaluate_fn: Callable,
    max_batches: int | None = None,
    input_channels: int = 1,
) -> list[float]:
    n = len(updates)
    utilities: dict[tuple[int, ...], float] = {}

    def u(coalition: tuple[int, ...]) -> float:
        key = tuple(sorted(coalition))
        if key not in utilities:
            utilities[key] = coalition_utility(
                base_state, updates, key, val_loader, device, utility_metric, evaluate_fn, max_batches, input_channels
            )
        return utilities[key]

    values = [0.0 for _ in range(n)]
    clients = tuple(range(n))
    factorial_n = math.factorial(n)
    for i in clients:
        others = [c for c in clients if c != i]
        for r in range(n):
            for subset in itertools.combinations(others, r):
                weight = math.factorial(r) * math.factorial(n - r - 1) / factorial_n
                with_i = tuple(sorted(subset + (i,)))
                values[i] += weight * (u(with_i) - u(tuple(sorted(subset))))
    return values


def mc_shapley(
    base_state: dict[str, torch.Tensor],
    updates: list[dict[str, torch.Tensor]],
    val_loader,
    device: torch.device,
    utility_metric: str,
    evaluate_fn: Callable,
    max_batches: int | None = None,
    permutations: int = 10,
    seed: int = 42,
    input_channels: int = 1,
) -> list[float]:
    n = len(updates)
    generator = torch.Generator().manual_seed(seed)
    values = [0.0 for _ in range(n)]
    for _ in range(permutations):
        order = torch.randperm(n, generator=generator).tolist()
        coalition: tuple[int, ...] = tuple()
        previous = coalition_utility(
            base_state, updates, coalition, val_loader, device, utility_metric, evaluate_fn, max_batches, input_channels
        )
        for client_id in order:
            coalition = tuple(sorted(coalition + (client_id,)))
            current = coalition_utility(
                base_state, updates, coalition, val_loader, device, utility_metric, evaluate_fn, max_batches, input_channels
            )
            values[client_id] += current - previous
            previous = current
    return [value / permutations for value in values]


def compute_shapley(
    method: str,
    base_state: dict[str, torch.Tensor],
    updates: list[dict[str, torch.Tensor]],
    val_loader,
    device: torch.device,
    utility_metric: str,
    evaluate_fn: Callable,
    max_batches: int | None = None,
    permutations: int = 10,
    seed: int = 42,
    input_channels: int = 1,
) -> list[float]:
    method = method.lower()
    if method == "exact":
        return exact_shapley(
            base_state, updates, val_loader, device, utility_metric, evaluate_fn, max_batches, input_channels
        )
    if method in {"mc", "mc-shapley", "monte_carlo"}:
        return mc_shapley(
            base_state,
            updates,
            val_loader,
            device,
            utility_metric,
            evaluate_fn,
            max_batches,
            permutations,
            seed,
            input_channels,
        )
    raise ValueError(f"Unsupported Shapley method: {method}")


def expected_utility_evaluations(method: str, num_clients: int, permutations: int = 10) -> int:
    method = method.lower()
    if method == "exact":
        return 2**num_clients
    if method in {"mc", "mc-shapley", "monte_carlo"}:
        return int(permutations) * (num_clients + 1)
    raise ValueError(f"Unsupported Shapley method: {method}")


def compute_shapley_with_stats(
    method: str,
    base_state: dict[str, torch.Tensor],
    updates: list[dict[str, torch.Tensor]],
    val_loader,
    device: torch.device,
    utility_metric: str,
    evaluate_fn: Callable,
    max_batches: int | None = None,
    permutations: int = 10,
    seed: int = 42,
    input_channels: int = 1,
) -> tuple[list[float], dict[str, float | int | str | None]]:
    started = time.time()
    values = compute_shapley(
        method,
        base_state,
        updates,
        val_loader,
        device,
        utility_metric,
        evaluate_fn,
        max_batches,
        permutations,
        seed,
        input_channels,
    )
    elapsed = time.time() - started
    stats = {
        "shapley_method": method,
        "utility_metric": utility_metric,
        "utility_evaluation_count": expected_utility_evaluations(method, len(updates), permutations),
        "shapley_runtime_seconds": elapsed,
        "max_batches": max_batches,
        "mc_permutations": permutations if method.lower() in {"mc", "mc-shapley", "monte_carlo"} else None,
    }
    return values, stats
