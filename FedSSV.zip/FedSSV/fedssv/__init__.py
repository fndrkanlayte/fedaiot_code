"""Minimal FedSSV phase-one reproduction package."""

