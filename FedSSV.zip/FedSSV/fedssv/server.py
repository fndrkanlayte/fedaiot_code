from __future__ import annotations

import csv
import time
from pathlib import Path
from typing import Any

from .aggregators import (
    afedsv_surrogate_weights,
    afedsv_weights,
    aggregate_updates,
    fedavg_weights,
    fedssv_weights,
    multikrum_update,
    trimmed_mean_update,
)
from .attacks import apply_attacks_to_updates, malicious_client_ids
from .client import train_centralized, train_client
from .datasets import load_dataset
from .metrics import air_from_metrics, evaluate
from .models import build_model
from .plotting import write_figures
from .shapley import compute_shapley_with_stats
from .utils import clone_state_dict, get_device, prepare_run_dir, save_json, set_seed, state_dict_add, update_norm


def _write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def run_experiment(config: dict[str, Any]) -> dict[str, Any]:
    set_seed(int(config["seed"]))
    device = get_device(config.get("device", "auto"))
    run_dir = prepare_run_dir(config)
    data = load_dataset(config)
    save_json(data.summary.get("client_label_distribution", data.summary.get("client_label_histograms", [])), run_dir / "client_label_distribution.json")
    if data.summary.get("table_v_check"):
        save_json(data.summary["table_v_check"], run_dir / "table_v_check.json")
    if data.summary.get("expanded_label_distribution"):
        save_json(data.summary["expanded_label_distribution"], run_dir / "expanded_label_distribution.json")
    input_channels = int(data.summary.get("input_channels", 1))
    malicious_ids = malicious_client_ids(int(config["num_clients"]), float(config["malicious_ratio"]))
    print(
        f'run={config["run_name"]} dataset={config["dataset"]} device={device} seed={config["seed"]} '
        f'clients={config["num_clients"]} rounds={config["rounds"]} attack_rounds={config["attack_rounds"]}'
    )
    for cid, count in enumerate(data.summary["client_sample_counts"]):
        print(f"client {cid}: samples={count}, labels={data.summary['client_label_histograms'][cid]}")

    centralized_result = None
    if config.get("centralized", {}).get("enabled", False):
        centralized_result = train_centralized(
            data.central_train_loader,
            data.test_loader,
            device,
            float(config["lr"]),
            float(config.get("momentum", 0.0)),
            int(config.get("centralized", {}).get("epochs", 1)),
            evaluate,
            input_channels,
        )
        print(f"centralized sanity: {centralized_result}")

    model = build_model(input_channels=input_channels).to(device)
    metrics_rows: list[dict[str, Any]] = []
    shapley_rows: list[dict[str, Any]] = []
    weight_rows: list[dict[str, Any]] = []
    norm_rows: list[dict[str, Any]] = []
    runtime_rows: list[dict[str, Any]] = []
    minmax_rows: list[dict[str, Any]] = []
    attack_group_assignment: dict[str, Any] | None = None
    afedsv_surrogate: list[float] | None = None

    for round_idx in range(1, int(config["rounds"]) + 1):
        start = time.time()
        base_state = clone_state_dict(model.state_dict())
        raw_updates = []
        norm_context = []
        train_start = time.time()
        for cid, loader in enumerate(data.client_loaders):
            update, _ = train_client(
                base_state,
                loader,
                device,
                float(config["lr"]),
                float(config.get("momentum", 0.0)),
                int(config["local_epochs"]),
                input_channels,
            )
            before_norm = update_norm(update)
            attack_applied = (
                bool(config.get("attacks", {}).get("enabled", False))
                and int(round_idx) in [int(x) for x in config.get("attack_rounds", [])]
                and cid in malicious_ids
            )
            raw_updates.append(update)
            norm_context.append((cid, before_norm, attack_applied))

        updates, attack_diagnostics = apply_attacks_to_updates(
            raw_updates,
            malicious_ids,
            config.get("attacks", {}),
            int(config["seed"]) + round_idx * 1009,
            base_state,
        )
        if attack_group_assignment is None:
            attack_group_assignment = attack_diagnostics.get("group_assignment", {})
        if attack_diagnostics.get("minmax"):
            minmax_row = {"round": round_idx, **attack_diagnostics["minmax"]}
            minmax_rows.append(minmax_row)
        per_client_attack = {
            int(row["client_id"]): row for row in attack_diagnostics.get("per_client", [])
        }
        for cid, before_norm, attack_applied in norm_context:
            after_norm = update_norm(updates[cid])
            attack_row = per_client_attack.get(cid, {})
            norm_rows.append(
                {
                    "round": round_idx,
                    "client_id": cid,
                    "is_malicious": cid in malicious_ids,
                    "attack_applied": attack_applied,
                    "actual_attack_type": attack_row.get("actual_attack_type", ""),
                    "attack_group": attack_row.get("attack_group", ""),
                    "gaussian_mode": attack_row.get("gaussian_mode", ""),
                    "gaussian_sigma": attack_row.get("gaussian_sigma", ""),
                    "noise_level": attack_row.get("noise_level", ""),
                    "std_reference": attack_row.get("std_reference", ""),
                    "sfa_applied": attack_row.get("sfa_applied", False),
                    "update_norm_before_attack": before_norm,
                    "update_norm_after_attack": after_norm,
                }
            )

        train_runtime = time.time() - train_start
        shapley_values, shapley_stats = compute_shapley_with_stats(
            config.get("shapley", {}).get("method", "exact"),
            base_state,
            updates,
            data.val_loader,
            device,
            config["shapley"]["utility_metric"],
            evaluate,
            config.get("shapley", {}).get("max_batches"),
            int(config.get("shapley", {}).get("mc_permutations", 10)),
            int(config["seed"]) + round_idx,
            input_channels,
        )
        for cid, value in enumerate(shapley_values):
            shapley_rows.append(
                {
                    "round": round_idx,
                    "client_id": cid,
                    "is_malicious": cid in malicious_ids,
                    "utility_metric": config["shapley"]["utility_metric"],
                    "shapley_value": value,
                }
            )

        aggregator = config["aggregator"].lower()
        selected_clients = list(range(len(updates)))
        aggregate_start = time.time()
        if aggregator == "fedssv":
            reputations, weights = fedssv_weights(shapley_values, config["fedssv"])
            agg_update = aggregate_updates(updates, weights)
        elif aggregator == "fedavg":
            weights = fedavg_weights(len(updates))
            reputations = [1.0] * len(updates)
            agg_update = aggregate_updates(updates, weights)
        elif aggregator == "afedsv":
            afedsv_config = config.get("afedsv", {})
            afedsv_variant = afedsv_config.get("variant", afedsv_config.get("mode", "historical_surrogate"))
            if afedsv_variant in {"legacy_positive_current", "afedsv_simple", "afedsv_nonnegative_current_sv"}:
                weights = afedsv_weights(shapley_values, float(config.get("fedssv", {}).get("epsilon", 1.0e-12)))
                reputations = [max(0.0, value) for value in shapley_values]
            else:
                afedsv_surrogate, weights = afedsv_surrogate_weights(
                    shapley_values,
                    afedsv_surrogate,
                    afedsv_config,
                )
                reputations = list(afedsv_surrogate)
            agg_update = aggregate_updates(updates, weights)
        elif aggregator in {"trimmed_mean", "trimmedmean"}:
            weights = fedavg_weights(len(updates))
            reputations = [1.0] * len(updates)
            agg_update = trimmed_mean_update(updates, float(config.get("aggregator_params", {}).get("trim_ratio", 0.2)))
        elif aggregator in {"multi_krum", "multikrum"}:
            malicious_count = len(malicious_ids)
            agg_update, selected_clients = multikrum_update(
                updates,
                malicious_count,
                config.get("aggregator_params", {}).get("krum_keep"),
            )
            weights = [0.0 for _ in updates]
            for selected in selected_clients:
                weights[selected] = 1.0 / len(selected_clients)
            reputations = [1.0 if idx in selected_clients else 0.0 for idx in range(len(updates))]
        else:
            raise ValueError(f"Unsupported aggregator: {config['aggregator']}")
        aggregate_runtime = time.time() - aggregate_start

        for cid, (sv, rep, weight) in enumerate(zip(shapley_values, reputations, weights)):
            weight_rows.append(
                {
                    "round": round_idx,
                    "client_id": cid,
                    "is_malicious": cid in malicious_ids,
                    "shapley_value": sv,
                    "reputation": rep,
                    "weight": weight,
                }
            )

        model.load_state_dict(state_dict_add(base_state, agg_update))
        eval_start = time.time()
        test_metrics = evaluate(model, data.test_loader, device)
        val_metrics = evaluate(model, data.val_loader, device)
        eval_runtime = time.time() - eval_start
        total_runtime = time.time() - start
        row = {
            "round": round_idx,
            "aggregator": config["aggregator"],
            "attack_type": config.get("attacks", {}).get("type", "none"),
            "test_loss": test_metrics["loss"],
            "test_accuracy": test_metrics["accuracy"],
            "val_loss": val_metrics["loss"],
            "val_accuracy": val_metrics["accuracy"],
            "air": "",
        }
        metrics_rows.append(row)
        runtime_rows.append(
            {
                "round": round_idx,
                "train_runtime_seconds": train_runtime,
                "shapley_runtime_seconds": shapley_stats["shapley_runtime_seconds"],
                "aggregate_runtime_seconds": aggregate_runtime,
                "eval_runtime_seconds": eval_runtime,
                "total_runtime_seconds": total_runtime,
                "utility_evaluation_count": shapley_stats["utility_evaluation_count"],
                "shapley_method": shapley_stats["shapley_method"],
                "utility_metric": shapley_stats["utility_metric"],
                "shapley_max_batches": shapley_stats["max_batches"],
                "mc_permutations": shapley_stats["mc_permutations"],
            }
        )
        print(
            f"round {round_idx:02d}: test_acc={test_metrics['accuracy']:.4f} "
            f"val_acc={val_metrics['accuracy']:.4f} weight_sum={sum(weights):.6f} elapsed={total_runtime:.1f}s"
        )

    attack_type = config.get("attacks", {}).get("type", "none")
    air_summary = air_from_metrics(metrics_rows, [int(x) for x in config.get("attack_rounds", [])], attack_type)
    for row in metrics_rows:
        air = air_summary.get(str(row["round"]), "")
        row["air"] = air

    _write_csv(run_dir / "metrics.csv", metrics_rows, ["round", "aggregator", "attack_type", "test_loss", "test_accuracy", "val_loss", "val_accuracy", "air"])
    _write_csv(run_dir / "shapley_values.csv", shapley_rows, ["round", "client_id", "is_malicious", "utility_metric", "shapley_value"])
    _write_csv(run_dir / "client_weights.csv", weight_rows, ["round", "client_id", "is_malicious", "shapley_value", "reputation", "weight"])
    _write_csv(
        run_dir / "update_norms.csv",
        norm_rows,
        [
            "round",
            "client_id",
            "is_malicious",
            "attack_applied",
            "actual_attack_type",
            "attack_group",
            "gaussian_mode",
            "gaussian_sigma",
            "noise_level",
            "std_reference",
            "sfa_applied",
            "update_norm_before_attack",
            "update_norm_after_attack",
        ],
    )
    if attack_group_assignment:
        save_json(attack_group_assignment, run_dir / "attack_group_assignment.json")
    if minmax_rows:
        _write_csv(
            run_dir / "minmax_diagnostics.csv",
            minmax_rows,
            [
                "round",
                "minmax_variant",
                "selected_gamma",
                "gamma_init",
                "gamma_max",
                "search_steps",
                "tolerance",
                "distance_metric",
                "constraint",
                "max_benign_pairwise_distance",
                "max_malicious_to_benign_distance",
                "distance_constraint_satisfied",
                "direction",
                "direction_norm",
                "malicious_update_norm",
                "benign_mean_norm",
            ],
        )
    _write_csv(
        run_dir / "runtime.csv",
        runtime_rows,
        [
            "round",
            "train_runtime_seconds",
            "shapley_runtime_seconds",
            "aggregate_runtime_seconds",
            "eval_runtime_seconds",
            "total_runtime_seconds",
            "utility_evaluation_count",
            "shapley_method",
            "utility_metric",
            "shapley_max_batches",
            "mc_permutations",
        ],
    )

    runtime_summary = {
        "total_runtime_seconds": sum(float(row["total_runtime_seconds"]) for row in runtime_rows),
        "total_shapley_runtime_seconds": sum(float(row["shapley_runtime_seconds"]) for row in runtime_rows),
        "total_utility_evaluation_count": sum(int(row["utility_evaluation_count"]) for row in runtime_rows),
    }

    summary = {
        "run_name": config["run_name"],
        "seed": config["seed"],
        "git_commit": None,
        "dataset": config["dataset"],
        "split_type": data.summary.get("split"),
        "aggregator": config["aggregator"],
        "method": config["aggregator"],
        "attack_settings": config.get("attacks", {}),
        "attack": config.get("attacks", {}).get("type", "none"),
        "attack_rounds": config.get("attack_rounds", []),
        "malicious_clients": malicious_ids,
        "validation_size": data.summary.get("val_size"),
        "shapley_method": config.get("shapley", {}).get("method", "exact"),
        "shapley_utility_metric": config["shapley"]["utility_metric"],
        "utility_metric": config["shapley"]["utility_metric"],
        "shapley_max_batches": config.get("shapley", {}).get("max_batches"),
        "fedssv_parameters": config["fedssv"],
        "afedsv_parameters": config.get("afedsv", {}),
        "aggregator_params": config.get("aggregator_params", {}),
        "gaussian_attack_parameters": {
            key: config.get("attacks", {}).get(key)
            for key in ["gaussian_mode", "gaussian_sigma", "noise_level", "std_reference", "per_layer"]
            if key in config.get("attacks", {})
        },
        "gaussian_sfa_parameters": {
            key: config.get("attacks", {}).get(key)
            for key in ["composition_mode", "gaussian_fraction", "sfa_fraction", "overlap", "assignment_strategy"]
            if key in config.get("attacks", {})
        },
        "attack_group_assignment": attack_group_assignment or {},
        "minmax_parameters": {
            key: config.get("attacks", {}).get(key)
            for key in ["minmax_variant", "direction", "gamma_init", "gamma_max", "search_steps", "distance_metric", "constraint", "tolerance"]
            if key in config.get("attacks", {})
        },
        "table_v_exact_passed": (data.summary.get("table_v_check") or {}).get("passed"),
        "table_v_repeat_distribution": bool(config.get("table_v_repeat_distribution", False)),
        "selected_clients_last_round": selected_clients,
        "centralized_sanity": centralized_result,
        "data": data.summary,
        "final_accuracy": metrics_rows[-1]["test_accuracy"],
        "air_summary": air_summary,
        "runtime_summary": runtime_summary,
        "implementation_assumptions": [
            "The code supports Fashion-MNIST/CIFAR-10, IID/non-IID shard splits, several attacks, and multiple aggregators.",
            "Smoke configs may limit train/validation/test samples; set max_*_samples to null for full data.",
            "Shapley supports exact and Monte Carlo methods; utility evaluation may cap validation batches via shapley.max_batches.",
            "AIR is computed as test_accuracy(round before attack) - test_accuracy(attack round); no-attack runs report AIR as NA.",
            "AFedSV uses a ShapleyFL-inspired historical surrogate contribution with configurable beta unless legacy_positive_current is explicitly selected.",
            "Gaussian/Gaussian-SFA dynamic noise uses a documented implementation assumption when the paper does not fully specify the dynamic standard-deviation formula.",
            "Min-max follows the optimized model-poisoning distance-constraint/gamma-search form; exact parity with the original attack code still requires cross-validation.",
            "Table-V non-IID uses a configurable fixed label distribution; shard split is only a general non-IID smoke option.",
            "FedSSV exponent values are clamped to [-50, 50] for numerical stability; this preserves ordering but is a numerical implementation detail beyond the paper formula.",
        ],
    }
    save_json(summary, run_dir / "summary.json")
    write_figures(run_dir)
    return summary
