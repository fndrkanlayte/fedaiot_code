from __future__ import annotations

import math
from typing import Any

import torch


def malicious_client_ids(num_clients: int, malicious_ratio: float) -> list[int]:
    count = max(1, int(math.ceil(num_clients * malicious_ratio))) if malicious_ratio > 0 else 0
    return list(range(count))


def apply_attack(
    update: dict[str, torch.Tensor],
    attack_type: str,
    scaling_factor: float,
    gaussian_std: float = 1.0,
    seed: int | None = None,
) -> dict[str, torch.Tensor]:
    config = {
        "enabled": True,
        "type": attack_type,
        "scaling_factor": scaling_factor,
        "gaussian_mode": "fixed_sigma",
        "gaussian_sigma": gaussian_std,
        "simple_negative_scaling_factor": scaling_factor,
    }
    return _apply_single_attack(update, config, seed, None)[0]


def planned_attack_groups(num_clients: int, malicious_ids: list[int], attack_config: dict[str, Any]) -> dict[str, Any]:
    attack_type = _attack_type(attack_config)
    if attack_type not in {"gaussian-sfa", "gaussian_sfa"}:
        return {
            "attack_type": attack_type,
            "malicious_clients": malicious_ids,
            "gaussian_attack_clients": malicious_ids if attack_type == "gaussian" else [],
            "sfa_attack_clients": malicious_ids if attack_type in {"sign-flip", "signflip", "sfa"} else [],
            "overlap": False,
            "assignment_strategy": attack_config.get("assignment_strategy", "deterministic_by_client_id"),
        }
    gaussian_ids, sfa_ids = _gaussian_sfa_groups(num_clients, malicious_ids, attack_config)
    return {
        "attack_type": attack_type,
        "composition_mode": attack_config.get("composition_mode", attack_config.get("composition", "split_groups")),
        "assignment_strategy": attack_config.get("assignment_strategy", "deterministic_by_client_id"),
        "overlap": bool(set(gaussian_ids) & set(sfa_ids)),
        "gaussian_attack_clients": gaussian_ids,
        "sfa_attack_clients": sfa_ids,
        "gaussian_fraction": attack_config.get("gaussian_fraction", attack_config.get("gaussian_ratio", 0.2)),
        "sfa_fraction": attack_config.get("sfa_fraction", attack_config.get("sfa_ratio", 0.2)),
    }


def apply_attacks_to_updates(
    updates: list[dict[str, torch.Tensor]],
    malicious_ids: list[int],
    attack_config: dict[str, Any],
    seed: int,
    base_state: dict[str, torch.Tensor] | None = None,
) -> tuple[list[dict[str, torch.Tensor]], dict[str, Any]]:
    attack_type = _attack_type(attack_config)
    attacked = [_clone_update(update) for update in updates]
    diagnostics = _empty_diagnostics(len(updates), malicious_ids, attack_config)
    if attack_type == "none" or not attack_config.get("enabled", False):
        return attacked, diagnostics

    if attack_type in {"gaussian-sfa", "gaussian_sfa"}:
        return _apply_gaussian_sfa(attacked, malicious_ids, attack_config, seed, base_state)
    if attack_type in {"min-max", "minmax"}:
        benign_ids = [idx for idx in range(len(updates)) if idx not in set(malicious_ids)]
        minmax_update, minmax_diag = _minmax_attack_update([updates[idx] for idx in benign_ids], attack_config)
        for cid in malicious_ids:
            attacked[cid] = minmax_update
            diagnostics["per_client"][cid].update(
                {
                    "actual_attack_type": "min-max",
                    "attack_group": "min-max",
                    "sfa_applied": False,
                    "gaussian_sigma": "",
                }
            )
        diagnostics["minmax"] = minmax_diag
        return attacked, diagnostics

    for cid in malicious_ids:
        attacked[cid], detail = _apply_single_attack(updates[cid], attack_config, seed + cid, base_state)
        diagnostics["per_client"][cid].update(detail)
    return attacked, diagnostics


def _attack_type(attack_config: dict[str, Any]) -> str:
    return str(attack_config.get("type", "none")).lower()


def _empty_diagnostics(num_clients: int, malicious_ids: list[int], attack_config: dict[str, Any]) -> dict[str, Any]:
    groups = planned_attack_groups(num_clients, malicious_ids, attack_config)
    return {
        "group_assignment": groups,
        "per_client": [
            {
                "client_id": cid,
                "is_malicious": cid in malicious_ids,
                "actual_attack_type": "",
                "attack_group": "",
                "gaussian_mode": "",
                "gaussian_sigma": "",
                "noise_level": "",
                "std_reference": "",
                "sfa_applied": False,
            }
            for cid in range(num_clients)
        ],
        "minmax": {},
    }


def _clone_update(update: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {key: value.detach().cpu().clone() for key, value in update.items()}


def _apply_single_attack(
    update: dict[str, torch.Tensor],
    attack_config: dict[str, Any],
    seed: int | None,
    base_state: dict[str, torch.Tensor] | None,
) -> tuple[dict[str, torch.Tensor], dict[str, Any]]:
    attack_type = _attack_type(attack_config)
    if attack_type == "none":
        return _clone_update(update), {}
    if attack_type == "scaling":
        return _scale_update(update, float(attack_config.get("scaling_factor", 1.0))), {
            "actual_attack_type": "scaling",
            "attack_group": "scaling",
            "sfa_applied": False,
        }
    if attack_type in {"sign-flip", "signflip", "sfa"}:
        return _scale_update(update, -1.0), {
            "actual_attack_type": "sfa",
            "attack_group": "sfa",
            "sfa_applied": True,
        }
    if attack_type == "gaussian":
        sigma, sigma_detail = resolve_gaussian_sigma(update, attack_config, base_state)
        return _add_gaussian_noise(update, sigma, seed), {
            "actual_attack_type": "gaussian",
            "attack_group": "gaussian",
            "gaussian_sigma": sigma,
            "gaussian_mode": sigma_detail["gaussian_mode"],
            "noise_level": sigma_detail["noise_level"],
            "std_reference": sigma_detail["std_reference"],
            "sfa_applied": False,
        }
    if attack_type in {"simple_negative_scaling", "negative-scaling"}:
        return _scale_update(update, -float(attack_config.get("simple_negative_scaling_factor", 100.0))), {
            "actual_attack_type": "simple_negative_scaling",
            "attack_group": "simple_negative_scaling",
            "sfa_applied": False,
        }
    raise ValueError(f"Unsupported single attack type: {attack_config.get('type')}")


def _apply_gaussian_sfa(
    updates: list[dict[str, torch.Tensor]],
    malicious_ids: list[int],
    attack_config: dict[str, Any],
    seed: int,
    base_state: dict[str, torch.Tensor] | None,
) -> tuple[list[dict[str, torch.Tensor]], dict[str, Any]]:
    mode = str(attack_config.get("composition_mode", attack_config.get("composition", "split_groups"))).lower()
    attacked = [_clone_update(update) for update in updates]
    diagnostics = _empty_diagnostics(len(updates), malicious_ids, attack_config)
    if mode in {"sequential_same_clients", "same_update"}:
        for cid in malicious_ids:
            flipped = _scale_update(updates[cid], -1.0)
            sigma, sigma_detail = resolve_gaussian_sigma(flipped, attack_config, base_state)
            attacked[cid] = _add_gaussian_noise(flipped, sigma, seed + cid)
            diagnostics["per_client"][cid].update(
                {
                    "actual_attack_type": "gaussian+sfa",
                    "attack_group": "sequential_same_clients",
                    "gaussian_sigma": sigma,
                    "gaussian_mode": sigma_detail["gaussian_mode"],
                    "noise_level": sigma_detail["noise_level"],
                    "std_reference": sigma_detail["std_reference"],
                    "sfa_applied": True,
                }
            )
        return attacked, diagnostics
    if mode != "split_groups":
        raise ValueError(f"Unsupported gaussian-sfa composition mode: {mode}")

    gaussian_ids, sfa_ids = _gaussian_sfa_groups(len(updates), malicious_ids, attack_config)
    for cid in gaussian_ids:
        sigma, sigma_detail = resolve_gaussian_sigma(updates[cid], attack_config, base_state)
        attacked[cid] = _add_gaussian_noise(updates[cid], sigma, seed + cid)
        diagnostics["per_client"][cid].update(
            {
                "actual_attack_type": "gaussian",
                "attack_group": "gaussian",
                "gaussian_sigma": sigma,
                "gaussian_mode": sigma_detail["gaussian_mode"],
                "noise_level": sigma_detail["noise_level"],
                "std_reference": sigma_detail["std_reference"],
                "sfa_applied": False,
            }
        )
    for cid in sfa_ids:
        attacked[cid] = _scale_update(updates[cid], -1.0)
        diagnostics["per_client"][cid].update(
            {
                "actual_attack_type": "sfa",
                "attack_group": "sfa",
                "sfa_applied": True,
            }
        )
    return attacked, diagnostics


def _gaussian_sfa_groups(
    num_clients: int,
    malicious_ids: list[int],
    attack_config: dict[str, Any],
) -> tuple[list[int], list[int]]:
    gaussian_fraction = float(attack_config.get("gaussian_fraction", attack_config.get("gaussian_ratio", 0.2)))
    sfa_fraction = float(attack_config.get("sfa_fraction", attack_config.get("sfa_ratio", 0.2)))
    gaussian_count = min(len(malicious_ids), int(math.ceil(num_clients * gaussian_fraction)))
    overlap = bool(attack_config.get("overlap", False))
    if overlap:
        sfa_count = min(len(malicious_ids), int(math.ceil(num_clients * sfa_fraction)))
        return malicious_ids[:gaussian_count], malicious_ids[:sfa_count]
    sfa_count = min(len(malicious_ids) - gaussian_count, int(math.ceil(num_clients * sfa_fraction)))
    return malicious_ids[:gaussian_count], malicious_ids[gaussian_count : gaussian_count + sfa_count]


def _scale_update(update: dict[str, torch.Tensor], factor: float) -> dict[str, torch.Tensor]:
    return {
        key: (value.detach().cpu() * factor if torch.is_floating_point(value) else value.detach().cpu().clone())
        for key, value in update.items()
    }


def _add_gaussian_noise(
    update: dict[str, torch.Tensor], gaussian_std: float, seed: int | None
) -> dict[str, torch.Tensor]:
    generator = torch.Generator()
    if seed is not None:
        generator.manual_seed(int(seed))
    attacked = {}
    for key, value in update.items():
        value = value.detach().cpu()
        if not torch.is_floating_point(value):
            attacked[key] = value.clone()
            continue
        noise = torch.randn(value.shape, generator=generator, dtype=value.dtype) * float(gaussian_std)
        attacked[key] = value + noise
    return attacked


def resolve_gaussian_sigma(
    update: dict[str, torch.Tensor],
    attack_config: dict[str, Any],
    base_state: dict[str, torch.Tensor] | None,
) -> tuple[float, dict[str, Any]]:
    mode = str(attack_config.get("gaussian_mode", "fixed_sigma")).lower()
    std_reference = str(attack_config.get("std_reference", attack_config.get("dynamic_std_scope", "model_parameters")))
    noise_level = attack_config.get("noise_level")
    if mode == "fixed_sigma":
        sigma = float(attack_config.get("gaussian_sigma", attack_config.get("gaussian_std", 1.0)))
    elif mode == "dynamic_model_std":
        tensors = base_state if base_state is not None else update
        sigma = float(attack_config.get("noise_level", 1.0)) * _tensor_collection_std(tensors)
        std_reference = "model_parameters"
    elif mode == "dynamic_update_std":
        sigma = float(attack_config.get("noise_level", 1.0)) * _tensor_collection_std(update)
        std_reference = "update"
    else:
        raise ValueError(f"Unsupported gaussian_mode: {mode}")
    return sigma, {
        "gaussian_mode": mode,
        "gaussian_sigma": sigma,
        "noise_level": "" if noise_level is None else noise_level,
        "std_reference": std_reference,
    }


def _tensor_collection_std(values: dict[str, torch.Tensor]) -> float:
    flat = [
        value.detach().cpu().float().reshape(-1)
        for value in values.values()
        if torch.is_floating_point(value)
    ]
    if not flat:
        return 0.0
    return float(torch.cat(flat).std(unbiased=False).item())


def _flatten_update(update: dict[str, torch.Tensor]) -> torch.Tensor:
    return torch.cat(
        [value.detach().cpu().float().reshape(-1) for value in update.values() if torch.is_floating_point(value)]
    )


def _unflatten_like(vector: torch.Tensor, template: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    result: dict[str, torch.Tensor] = {}
    offset = 0
    for key, value in template.items():
        value = value.detach().cpu()
        if not torch.is_floating_point(value):
            result[key] = value.clone()
            continue
        count = value.numel()
        result[key] = vector[offset : offset + count].reshape_as(value).to(dtype=value.dtype)
        offset += count
    return result


def _minmax_attack_update(
    benign_updates: list[dict[str, torch.Tensor]],
    attack_config: dict[str, Any],
) -> tuple[dict[str, torch.Tensor], dict[str, Any]]:
    if not benign_updates:
        raise ValueError("min-max attack requires at least one benign update")
    vectors = [_flatten_update(update) for update in benign_updates]
    benign_mean = torch.stack(vectors).mean(dim=0)
    direction = str(attack_config.get("direction", attack_config.get("perturbation_direction", "negative_mean_update"))).lower()
    if direction in {"negative_mean", "negative_mean_update"}:
        perturbation = -benign_mean
    elif direction in {"sign_negative_mean", "sign_negative_mean_update"}:
        perturbation = -torch.sign(benign_mean)
    else:
        raise ValueError(f"Unsupported min-max direction: {direction}")
    direction_norm = float(torch.linalg.vector_norm(perturbation).item())
    if direction_norm <= 0.0:
        perturbation = -torch.ones_like(benign_mean)
        direction_norm = float(torch.linalg.vector_norm(perturbation).item())
    perturbation = perturbation / direction_norm

    max_benign_distance = 0.0
    for left in vectors:
        for right in vectors:
            max_benign_distance = max(max_benign_distance, float(torch.linalg.vector_norm(left - right).item()))

    gamma_init = float(attack_config.get("gamma_init", 1.0))
    gamma_max = float(attack_config.get("gamma_max", attack_config.get("scaling_factor", 100.0)))
    tolerance = float(attack_config.get("tolerance", attack_config.get("gamma_tau", 1.0e-6)))
    search_steps = int(attack_config.get("search_steps", attack_config.get("gamma_max_iters", 20)))
    gamma = _search_minmax_gamma(
        benign_mean,
        perturbation,
        vectors,
        max_benign_distance,
        gamma_init,
        gamma_max,
        tolerance,
        search_steps,
    )
    malicious = benign_mean + gamma * perturbation
    max_malicious_distance = max(float(torch.linalg.vector_norm(malicious - vector).item()) for vector in vectors)
    diag = {
        "minmax_variant": attack_config.get("minmax_variant", "gamma_search"),
        "selected_gamma": gamma,
        "gamma_init": gamma_init,
        "gamma_max": gamma_max,
        "search_steps": search_steps,
        "tolerance": tolerance,
        "distance_metric": attack_config.get("distance_metric", "l2"),
        "constraint": attack_config.get("constraint", "max_distance_to_benign"),
        "max_benign_pairwise_distance": max_benign_distance,
        "max_malicious_to_benign_distance": max_malicious_distance,
        "distance_constraint_satisfied": max_malicious_distance <= max_benign_distance + tolerance,
        "direction": direction,
        "direction_norm": direction_norm,
        "malicious_update_norm": float(torch.linalg.vector_norm(malicious).item()),
        "benign_mean_norm": float(torch.linalg.vector_norm(benign_mean).item()),
    }
    return _unflatten_like(malicious, benign_updates[0]), diag


def _search_minmax_gamma(
    benign_mean: torch.Tensor,
    perturbation: torch.Tensor,
    benign_vectors: list[torch.Tensor],
    max_benign_distance: float,
    gamma_init: float,
    gamma_max: float,
    tolerance: float,
    search_steps: int,
) -> float:
    def satisfies(gamma: float) -> bool:
        candidate = benign_mean + gamma * perturbation
        max_distance = max(float(torch.linalg.vector_norm(candidate - vector).item()) for vector in benign_vectors)
        return max_distance <= max_benign_distance + tolerance

    high = max(gamma_init, tolerance)
    high = min(high, gamma_max)
    while high < gamma_max and satisfies(high):
        high = min(high * 2.0, gamma_max)
        if high == gamma_max:
            break
    low = 0.0
    if satisfies(high):
        low = high
    for _ in range(search_steps):
        mid = (low + high) / 2.0
        if satisfies(mid):
            low = mid
        else:
            high = mid
        if abs(high - low) <= tolerance:
            break
    return low
