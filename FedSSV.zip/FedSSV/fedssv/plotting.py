from __future__ import annotations

import csv
from pathlib import Path


COLORS = ["#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c", "#0891b2"]


def _polyline(points: list[tuple[float, float]], color: str) -> str:
    data = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
    return f'<polyline points="{data}" fill="none" stroke="{color}" stroke-width="2"/>'


def _svg_chart(series: dict[str, list[tuple[float, float]]], title: str, path: Path) -> None:
    width, height = 760, 420
    margin = 52
    all_points = [p for values in series.values() for p in values]
    if not all_points:
        return
    min_x, max_x = min(x for x, _ in all_points), max(x for x, _ in all_points)
    min_y, max_y = min(y for _, y in all_points), max(y for _, y in all_points)
    if max_y == min_y:
        max_y += 1.0
    if max_x == min_x:
        max_x += 1.0

    def sx(x: float) -> float:
        return margin + (x - min_x) / (max_x - min_x) * (width - 2 * margin)

    def sy(y: float) -> float:
        return height - margin - (y - min_y) / (max_y - min_y) * (height - 2 * margin)

    lines = []
    legends = []
    for idx, (name, values) in enumerate(series.items()):
        color = COLORS[idx % len(COLORS)]
        lines.append(_polyline([(sx(x), sy(y)) for x, y in values], color))
        legends.append(
            f'<rect x="{margin + idx * 145}" y="24" width="12" height="12" fill="{color}"/>'
            f'<text x="{margin + 18 + idx * 145}" y="35" font-size="12">{name}</text>'
        )
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
<rect width="100%" height="100%" fill="white"/>
<text x="{margin}" y="18" font-size="16" font-family="Arial">{title}</text>
{''.join(legends)}
<line x1="{margin}" y1="{height-margin}" x2="{width-margin}" y2="{height-margin}" stroke="#111"/>
<line x1="{margin}" y1="{margin}" x2="{margin}" y2="{height-margin}" stroke="#111"/>
<text x="{margin}" y="{height-14}" font-size="12" font-family="Arial">round</text>
<text x="8" y="{margin-12}" font-size="12" font-family="Arial">value</text>
{''.join(lines)}
</svg>'''
    path.write_text(svg, encoding="utf-8")


def write_figures(run_dir: Path) -> None:
    figures = run_dir / "figures"
    figures.mkdir(exist_ok=True)
    metrics_path = run_dir / "metrics.csv"
    if metrics_path.exists():
        with metrics_path.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        _svg_chart(
            {"test_accuracy": [(float(r["round"]), float(r["test_accuracy"])) for r in rows]},
            "Accuracy vs Round",
            figures / "accuracy_curve.svg",
        )
    weights_path = run_dir / "client_weights.csv"
    if weights_path.exists():
        with weights_path.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        series: dict[str, list[tuple[float, float]]] = {}
        for r in rows:
            series.setdefault(f'client_{r["client_id"]}', []).append((float(r["round"]), float(r["weight"])))
        _svg_chart(series, "Client Weight vs Round", figures / "client_weight_curve.svg")


def write_air_table(run_dirs: list[Path], output_path: Path) -> None:
    rows = []
    for run_dir in run_dirs:
        summary = run_dir / "summary.json"
        if not summary.exists():
            continue
        import json

        data = json.loads(summary.read_text(encoding="utf-8"))
        for attack_round, air in data.get("air_summary", {}).items():
            rows.append((data["run_name"], data.get("aggregator"), data.get("attack_settings", {}).get("type"), attack_round, air))
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["run_name", "aggregator", "attack_type", "attack_round", "air"])
        writer.writerows(rows)


def write_accuracy_comparison(run_dirs: list[Path], output_path: Path, title: str) -> None:
    series = {}
    for run_dir in run_dirs:
        metrics_path = run_dir / "metrics.csv"
        if not metrics_path.exists():
            continue
        with metrics_path.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        label = run_dir.name.split("_")[-1]
        if "fedavg" in run_dir.name:
            label = "FedAvg"
        elif "fedssv" in run_dir.name:
            label = "FedSSV"
        series[label] = [(float(r["round"]), float(r["test_accuracy"])) for r in rows]
    _svg_chart(series, title, output_path)
