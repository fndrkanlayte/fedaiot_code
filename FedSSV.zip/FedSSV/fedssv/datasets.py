from __future__ import annotations

import csv
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset, Subset, random_split
from torchvision import datasets, transforms


@dataclass
class DataBundle:
    client_loaders: list[DataLoader]
    val_loader: DataLoader
    test_loader: DataLoader
    central_train_loader: DataLoader
    summary: dict[str, Any]


class ISIC2019Dataset(Dataset):
    def __init__(self, records: list[tuple[Path, int]], transform) -> None:
        self.records = records
        self.transform = transform
        self.targets = [label for _, label in records]

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, idx: int):
        path, label = self.records[idx]
        image = Image.open(path).convert("RGB")
        return self.transform(image), label


def _targets(dataset: Dataset) -> list[int]:
    if isinstance(dataset, Subset):
        parent_targets = _targets(dataset.dataset)
        return [int(parent_targets[i]) for i in dataset.indices]
    return [int(x) for x in dataset.targets]


def _limited_subset(dataset: Dataset, max_samples: int | None, seed: int) -> Dataset:
    if max_samples is None or max_samples >= len(dataset):
        return dataset
    generator = torch.Generator().manual_seed(seed)
    indices = torch.randperm(len(dataset), generator=generator)[:max_samples].tolist()
    return Subset(dataset, indices)


def _label_hist(dataset: Dataset, num_classes: int = 10) -> dict[str, int]:
    counts = Counter(_targets(dataset))
    return {str(i): int(counts.get(i, 0)) for i in range(num_classes)}


def _dataset_metadata(name: str) -> tuple[int, int]:
    normalized = name.lower().replace("_", "-")
    if normalized in {"fashion-mnist", "fmnist"}:
        return 1, 10
    if normalized in {"cifar-10", "cifar10"}:
        return 3, 10
    if normalized in {"isic2019", "isic-2019", "isic"}:
        return 3, 2
    raise ValueError(f"Unsupported dataset: {name}")


def _load_torchvision_dataset(config: dict[str, Any]) -> tuple[Dataset, Dataset]:
    name = str(config.get("dataset", "Fashion-MNIST")).lower().replace("_", "-")
    data_dir = config.get("data_dir", "data")
    if name in {"fashion-mnist", "fmnist"}:
        transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.2860,), (0.3530,))])
        return (
            datasets.FashionMNIST(data_dir, train=True, download=True, transform=transform),
            datasets.FashionMNIST(data_dir, train=False, download=True, transform=transform),
        )
    if name in {"cifar-10", "cifar10"}:
        transform = transforms.Compose(
            [transforms.ToTensor(), transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))]
        )
        return (
            datasets.CIFAR10(data_dir, train=True, download=True, transform=transform),
            datasets.CIFAR10(data_dir, train=False, download=True, transform=transform),
        )
    if name in {"isic2019", "isic-2019", "isic"}:
        return _load_isic2019_dataset(config)
    raise ValueError(f"Unsupported dataset: {config.get('dataset')}")


def _load_isic2019_dataset(config: dict[str, Any]) -> tuple[Dataset, Dataset]:
    isic = config.get("isic", {})
    metadata_csv = Path(isic.get("metadata_csv", Path(config.get("data_dir", "data/ISIC2019")) / "metadata.csv"))
    image_dir = Path(isic.get("image_dir", Path(config.get("data_dir", "data/ISIC2019")) / "images"))
    if not metadata_csv.exists():
        raise FileNotFoundError(f"ISIC2019 metadata_csv not found: {metadata_csv}")
    if not image_dir.exists():
        raise FileNotFoundError(f"ISIC2019 image_dir not found: {image_dir}")

    image_column = str(isic.get("image_column", "image"))
    label_column = str(isic.get("label_column", "diagnosis"))
    binary_mapping = dict(isic.get("binary_mapping", {"benign": 0, "malignant": 1}))
    resize = int(isic.get("resize", 32))
    transform = transforms.Compose(
        [
            transforms.Resize((resize, resize)),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
        ]
    )

    records: list[tuple[Path, int]] = []
    with metadata_csv.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if image_column not in row or label_column not in row:
                raise ValueError(f"ISIC metadata must contain {image_column!r} and {label_column!r} columns")
            raw_label = row[label_column]
            if raw_label not in binary_mapping:
                continue
            image_name = row[image_column]
            path = image_dir / image_name
            if not path.suffix:
                for suffix in [".jpg", ".jpeg", ".png"]:
                    candidate = path.with_suffix(suffix)
                    if candidate.exists():
                        path = candidate
                        break
            if not path.exists():
                raise FileNotFoundError(f"ISIC2019 image file not found: {path}")
            records.append((path, int(binary_mapping[raw_label])))
    if not records:
        raise ValueError("ISIC2019 metadata produced no records after binary label mapping")
    dataset = ISIC2019Dataset(records, transform)
    return dataset, dataset


def _iid_splits(dataset: Dataset, num_clients: int, seed: int) -> list[list[int]]:
    perm = torch.randperm(len(dataset), generator=torch.Generator().manual_seed(seed)).tolist()
    return [perm[i::num_clients] for i in range(num_clients)]


def _noniid_shard_splits(dataset: Dataset, num_clients: int, shards_per_client: int, seed: int) -> list[list[int]]:
    targets = _targets(dataset)
    sorted_indices = sorted(range(len(targets)), key=lambda idx: targets[idx])
    num_shards = num_clients * shards_per_client
    shard_size = len(sorted_indices) // num_shards
    shards = [sorted_indices[i * shard_size : (i + 1) * shard_size] for i in range(num_shards)]
    remainder = sorted_indices[num_shards * shard_size :]
    for idx, sample_idx in enumerate(remainder):
        shards[idx % num_shards].append(sample_idx)
    order = torch.randperm(num_shards, generator=torch.Generator().manual_seed(seed)).tolist()
    splits = [[] for _ in range(num_clients)]
    for client_id in range(num_clients):
        for shard_id in order[client_id * shards_per_client : (client_id + 1) * shards_per_client]:
            splits[client_id].extend(shards[shard_id])
    return splits


def _default_table_v_distribution(dataset_name: str) -> list[dict[int, float]]:
    normalized = dataset_name.lower().replace("_", "-")
    if normalized not in {"fashion-mnist", "fmnist", "cifar-10", "cifar10"}:
        raise ValueError("table_v split currently supports Fashion-MNIST and CIFAR-10 only")
    # The PDF text extraction exposes only two concrete Table V constraints:
    # Client 1 has 50% class 6, and Client 7 has only classes 2 and 7.
    # Keep this preset explicit and auditable; replace it with the full table_v_label_distribution
    # in config once the table image has been manually transcribed.
    return [
        {0: 0.5, 1: 0.5},
        {6: 0.5, 1: 0.5},
        {2: 0.5, 3: 0.5},
        {3: 0.5, 4: 0.5},
        {4: 0.5, 5: 0.5},
        {5: 0.5, 6: 0.5},
        {6: 0.5, 7: 0.5},
        {2: 0.5, 7: 0.5},
        {8: 0.5, 9: 0.5},
        {0: 0.5, 9: 0.5},
    ]


TABLE_V_EXACT: dict[str, list[dict[int, int]]] = {
    "fmnist": [
        {8: 300, 0: 300, 5: 300, 4: 300},
        {6: 600, 9: 300, 2: 300},
        {4: 300, 2: 300, 6: 300, 9: 300},
        {0: 300, 2: 300, 5: 300, 9: 300},
        {6: 300, 7: 300, 0: 300, 8: 300},
        {1: 300, 7: 300, 5: 300, 3: 300},
        {4: 600, 8: 300, 2: 300},
        {2: 600, 7: 600},
        {9: 300, 5: 300, 6: 300, 0: 300},
        {3: 900, 4: 300},
    ],
    "cifar10": [
        {8: 250, 0: 250, 5: 250, 4: 250},
        {6: 500, 9: 250, 2: 250},
        {4: 250, 2: 250, 6: 250, 9: 250},
        {0: 250, 2: 250, 5: 250, 9: 250},
        {6: 250, 7: 250, 0: 250, 8: 250},
        {1: 250, 7: 250, 5: 250, 3: 250},
        {4: 500, 8: 250, 2: 250},
        {2: 500, 7: 500},
        {9: 250, 5: 250, 6: 250, 0: 250},
        {3: 750, 4: 250},
    ],
    "isic2019": [
        {0: 142, 1: 142},
        {0: 142, 1: 142},
        {0: 142, 1: 142},
        {0: 142, 1: 142},
        {0: 142, 1: 142},
        {0: 284},
        {0: 284},
        {0: 284},
        {0: 142, 1: 142},
        {0: 284},
    ],
}


def _table_v_key(dataset_name: str) -> str:
    normalized = dataset_name.lower().replace("_", "-")
    if normalized in {"fashion-mnist", "fmnist"}:
        return "fmnist"
    if normalized in {"cifar-10", "cifar10"}:
        return "cifar10"
    if normalized in {"isic2019", "isic-2019", "isic"}:
        return "isic2019"
    raise ValueError(f"Unsupported Table V dataset: {dataset_name}")


def _exact_distribution_to_weights(distribution: list[dict[int, int]]) -> list[dict[int, float]]:
    return [{label: float(count) for label, count in client.items()} for client in distribution]


def _normalize_label_distribution(raw: Any) -> list[dict[int, float]]:
    normalized = []
    for client_dist in raw:
        normalized.append({int(label): float(value) for label, value in dict(client_dist).items()})
    return normalized


def _fixed_label_distribution_splits(
    dataset: Dataset,
    distribution: list[dict[int, float]],
    samples_per_client: int,
    seed: int,
) -> list[list[int]]:
    targets = _targets(dataset)
    by_label: dict[int, list[int]] = {label: [] for label in range(10)}
    for idx, label in enumerate(targets):
        by_label.setdefault(int(label), []).append(idx)
    generator = torch.Generator().manual_seed(seed)
    for label, values in by_label.items():
        order = torch.randperm(len(values), generator=generator).tolist()
        by_label[label] = [values[i] for i in order]

    splits = []
    for client_dist in distribution:
        total_weight = sum(client_dist.values())
        if total_weight <= 0:
            raise ValueError("table_v client distribution must have positive weights")
        client_indices = []
        labels = list(client_dist)
        remaining = samples_per_client
        for pos, label in enumerate(labels):
            if pos == len(labels) - 1:
                count = remaining
            else:
                count = int(round(samples_per_client * client_dist[label] / total_weight))
                remaining -= count
            available = by_label.get(label, [])
            if len(available) < count:
                raise ValueError(f"Not enough samples for label {label}: need {count}, have {len(available)}")
            client_indices.extend(available[:count])
            by_label[label] = available[count:]
        splits.append(client_indices)
    return splits


def _fixed_label_count_splits(
    dataset: Dataset,
    distribution: list[dict[int, int]],
    seed: int,
    with_replacement: bool = False,
) -> list[list[int]]:
    targets = _targets(dataset)
    by_label: dict[int, list[int]] = {}
    for idx, label in enumerate(targets):
        by_label.setdefault(int(label), []).append(idx)
    generator = torch.Generator().manual_seed(seed)
    for label, values in by_label.items():
        order = torch.randperm(len(values), generator=generator).tolist()
        by_label[label] = [values[i] for i in order]

    splits = []
    for client_dist in distribution:
        client_indices = []
        for label, count in client_dist.items():
            available = by_label.get(int(label), [])
            if len(available) < int(count):
                if not with_replacement:
                    raise ValueError(f"Not enough samples for label {label}: need {count}, have {len(available)}")
                if not available:
                    raise ValueError(f"Cannot sample label {label} with replacement because no samples are available")
                choice = torch.randint(len(available), (int(count),), generator=generator).tolist()
                client_indices.extend([available[idx] for idx in choice])
                continue
            client_indices.extend(available[: int(count)])
            if not with_replacement:
                by_label[int(label)] = available[int(count) :]
        splits.append(client_indices)
    return splits


def _hist_from_distribution(distribution: list[dict[int, int]], num_classes: int) -> list[dict[str, int]]:
    result = []
    for client_dist in distribution:
        result.append({str(label): int(client_dist.get(label, 0)) for label in range(num_classes)})
    return result


def _table_v_check(
    dataset_name: str,
    seed: int,
    expected: list[dict[int, int]],
    actual: list[dict[str, int]],
    num_classes: int,
) -> dict[str, Any]:
    expected_hist = _hist_from_distribution(expected, num_classes)
    return {
        "dataset": dataset_name,
        "seed": seed,
        "expected_distribution": expected_hist,
        "actual_distribution": actual,
        "passed": expected_hist == actual,
        "total_samples_per_client": [sum(client.values()) for client in actual],
    }


def load_dataset(config: dict[str, Any]) -> DataBundle:
    full_train, test = _load_torchvision_dataset(config)
    input_channels, num_classes = _dataset_metadata(str(config.get("dataset", "Fashion-MNIST")))

    seed = int(config["seed"])
    if str(config.get("dataset", "")).lower().replace("_", "-") in {"isic2019", "isic-2019", "isic"}:
        test_fraction = float(config.get("isic", {}).get("test_fraction", 0.1))
        val_fraction = float(config.get("val_fraction", config.get("isic", {}).get("val_fraction", 0.1)))
        test_size = int(len(full_train) * test_fraction)
        val_size = int(len(full_train) * val_fraction)
        train_size = len(full_train) - val_size - test_size
        if train_size <= 0:
            raise ValueError("ISIC2019 split leaves no training samples; adjust val/test fractions")
        train, val, test = random_split(full_train, [train_size, val_size, test_size], torch.Generator().manual_seed(seed))
    else:
        val_size = int(len(full_train) * float(config.get("val_fraction", 0.1)))
        train_size = len(full_train) - val_size
        train, val = random_split(full_train, [train_size, val_size], torch.Generator().manual_seed(seed))

    train = _limited_subset(train, config.get("max_train_samples"), seed + 1)
    val = _limited_subset(val, config.get("max_val_samples"), seed + 2)
    test = _limited_subset(test, config.get("max_test_samples"), seed + 3)

    num_clients = int(config["num_clients"])
    split_strategy = str(config.get("split", "iid")).lower()
    if split_strategy == "iid":
        splits = _iid_splits(train, num_clients, seed + 4)
    elif split_strategy in {"non-iid", "noniid", "shard"}:
        splits = _noniid_shard_splits(train, num_clients, int(config.get("shards_per_client", 2)), seed + 4)
    elif split_strategy in {"table-v-exact", "table_v_exact"}:
        if num_clients != 10:
            raise ValueError("table_v_exact only supports num_clients=10; use table_v_repeat_distribution for Fig.8 N=50/100")
        table_key = _table_v_key(str(config.get("dataset", "Fashion-MNIST")))
        distribution = TABLE_V_EXACT[table_key]
        splits = _fixed_label_count_splits(train, distribution, seed + 4)
    elif split_strategy in {"table-v", "table_v"}:
        raw_distribution = config.get("table_v_label_distribution")
        if config.get("table_v_repeat_distribution", False):
            base = TABLE_V_EXACT[_table_v_key(str(config.get("dataset", "Fashion-MNIST")))]
            expanded_counts = [base[idx % len(base)] for idx in range(num_clients)]
            splits = _fixed_label_count_splits(
                train,
                expanded_counts,
                seed + 4,
                with_replacement=bool(config.get("table_v_repeat_with_replacement", False)),
            )
        elif raw_distribution:
            distribution = _normalize_label_distribution(raw_distribution)
        else:
            distribution = _default_table_v_distribution(str(config.get("dataset", "Fashion-MNIST")))
            if len(distribution) != num_clients:
                raise ValueError(f"table_v distribution has {len(distribution)} clients but num_clients={num_clients}")
            samples_per_client = int(
                config.get(
                    "table_v_samples_per_client",
                    1200 if str(config.get("dataset", "Fashion-MNIST")).lower().startswith(("fashion", "fmnist")) else 1000,
                )
            )
            splits = _fixed_label_distribution_splits(train, distribution, samples_per_client, seed + 4)
    else:
        raise ValueError(f"Unsupported client split strategy: {split_strategy}")
    client_sets = [Subset(train, split) for split in splits]
    client_histograms = [_label_hist(ds, num_classes) for ds in client_sets]
    table_v_check = None
    expanded_label_distribution = None
    if split_strategy in {"table-v-exact", "table_v_exact"}:
        expected = TABLE_V_EXACT[_table_v_key(str(config.get("dataset", "Fashion-MNIST")))]
        table_v_check = _table_v_check(str(config.get("dataset", "Fashion-MNIST")), seed, expected, client_histograms, num_classes)
    if split_strategy in {"table-v", "table_v"} and config.get("table_v_repeat_distribution", False):
        base = TABLE_V_EXACT[_table_v_key(str(config.get("dataset", "Fashion-MNIST")))]
        expanded_counts = [base[idx % len(base)] for idx in range(num_clients)]
        expanded_label_distribution = {
            "base_table_v_clients": len(base),
            "expanded_num_clients": num_clients,
            "mapping": [{"client_id": idx, "source_table_v_client": idx % len(base)} for idx in range(num_clients)],
            "distribution": _hist_from_distribution(expanded_counts, num_classes),
            "with_replacement": bool(config.get("table_v_repeat_with_replacement", False)),
            "assumption": "Fig.8 N=50/100 repeats the 10-client Table V pattern; the paper does not directly specify expanded label distributions.",
        }

    batch_size = int(config["batch_size"])
    client_loaders = [
        DataLoader(ds, batch_size=batch_size, shuffle=True, num_workers=0) for ds in client_sets
    ]
    val_loader = DataLoader(val, batch_size=batch_size, shuffle=False, num_workers=0)
    test_loader = DataLoader(test, batch_size=batch_size, shuffle=False, num_workers=0)
    central_train_loader = DataLoader(train, batch_size=batch_size, shuffle=True, num_workers=0)

    summary = {
        "train_size": len(train),
        "val_size": len(val),
        "test_size": len(test),
        "client_sample_counts": [len(ds) for ds in client_sets],
        "client_label_histograms": client_histograms,
        "client_label_distribution": client_histograms,
        "val_label_histogram": _label_hist(val, num_classes),
        "test_label_histogram": _label_hist(test, num_classes),
        "dataset": config.get("dataset", "Fashion-MNIST"),
        "split": split_strategy,
        "split_assumption": (
            "table_v_repeat_distribution is a Fig.8 scalability engineering assumption"
            if config.get("table_v_repeat_distribution", False)
            else "table_v preset uses PDF-extracted constraints plus configurable label distribution; table_v_exact is strict"
            if split_strategy in {"table-v", "table_v"}
            else ""
        ),
        "table_v_check": table_v_check,
        "expanded_label_distribution": expanded_label_distribution,
        "input_channels": input_channels,
        "num_classes": num_classes,
    }
    return DataBundle(client_loaders, val_loader, test_loader, central_train_loader, summary)


def load_fashion_mnist(config: dict[str, Any]) -> DataBundle:
    config = dict(config)
    config["dataset"] = "Fashion-MNIST"
    return load_dataset(config)
