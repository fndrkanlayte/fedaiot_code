from __future__ import annotations

import torch
from torch import nn
from torch.utils.data import DataLoader


@torch.no_grad()
def evaluate(model: nn.Module, loader: DataLoader, device: torch.device, max_batches: int | None = None) -> dict[str, float]:
    model.eval()
    criterion = nn.CrossEntropyLoss(reduction="sum")
    total_loss = 0.0
    total_correct = 0
    total = 0
    for batch_idx, (x, y) in enumerate(loader):
        if max_batches is not None and batch_idx >= max_batches:
            break
        x = x.to(device)
        y = y.to(device)
        logits = model(x)
        total_loss += float(criterion(logits, y).item())
        total_correct += int((logits.argmax(dim=1) == y).sum().item())
        total += int(y.numel())
    if total == 0:
        return {"loss": float("nan"), "accuracy": float("nan")}
    return {"loss": total_loss / total, "accuracy": total_correct / total}


def air_from_metrics(rows: list[dict], attack_rounds: list[int], attack_type: str) -> dict[str, float | str]:
    if attack_type == "none":
        return {str(attack_round): "NA" for attack_round in attack_rounds}
    by_round = {int(row["round"]): row for row in rows}
    airs = {}
    for attack_round in attack_rounds:
        before = by_round.get(attack_round - 1)
        at = by_round.get(attack_round)
        if before is None or at is None:
            continue
        airs[str(attack_round)] = float(before["test_accuracy"]) - float(at["test_accuracy"])
    return airs
