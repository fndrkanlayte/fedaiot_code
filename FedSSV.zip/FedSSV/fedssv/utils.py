from __future__ import annotations

import copy
import json
import os
import random
from pathlib import Path
from typing import Any

import torch
import yaml


def load_config(path: str | Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def save_yaml(config: dict[str, Any], path: str | Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, sort_keys=False)


def save_json(data: dict[str, Any], path: str | Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def set_seed(seed: int) -> None:
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_device(name: str = "auto") -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(name)


def prepare_run_dir(config: dict[str, Any]) -> Path:
    run_dir = Path("outputs") / "runs" / str(config["run_name"])
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "figures").mkdir(exist_ok=True)
    save_yaml(config, run_dir / "config.yaml")
    return run_dir


def state_dict_subtract(a: dict[str, torch.Tensor], b: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {k: a[k].detach().cpu() - b[k].detach().cpu() for k in a}


def state_dict_add(base: dict[str, torch.Tensor], update: dict[str, torch.Tensor], scale: float = 1.0) -> dict[str, torch.Tensor]:
    result = {}
    for k in base:
        base_value = base[k].detach().cpu()
        if not torch.is_floating_point(base_value):
            result[k] = base_value.clone()
        else:
            result[k] = base_value + update[k].detach().cpu() * scale
    return result


def clone_state_dict(state: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
    return {k: v.detach().cpu().clone() for k, v in state.items()}


def weighted_average_updates(
    updates: list[dict[str, torch.Tensor]], weights: list[float]
) -> dict[str, torch.Tensor]:
    result: dict[str, torch.Tensor] = {}
    for key in updates[0]:
        acc = torch.zeros_like(updates[0][key], dtype=torch.float32)
        for update, weight in zip(updates, weights):
            acc += update[key].float() * float(weight)
        result[key] = acc
    return result


def update_norm(update: dict[str, torch.Tensor]) -> float:
    total = torch.tensor(0.0)
    for value in update.values():
        total += torch.sum(value.float() ** 2)
    return float(torch.sqrt(total).item())


def deepcopy_config(config: dict[str, Any]) -> dict[str, Any]:
    return copy.deepcopy(config)
