from __future__ import annotations

import math

import torch

from .utils import weighted_average_updates


def fedavg_weights(num_clients: int) -> list[float]:
    return [1.0 / num_clients] * num_clients


def fedssv_weights(shapley_values: list[float], config: dict) -> tuple[list[float], list[float]]:
    threshold = float(config["negative_threshold"])
    scale_factor = float(config["scale_factor"])
    epsilon = float(config["epsilon"])
    transform = config.get("reputation_transform", "exp")
    if transform != "exp":
        raise ValueError(f"Unsupported reputation_transform for phase one: {transform}")

    reputations = []
    for sv in shapley_values:
        exponent = sv * scale_factor if sv < threshold else sv
        # Clamp avoids floating underflow/overflow while preserving the intended ordering.
        exponent = max(min(exponent, 50.0), -50.0)
        reputations.append(math.exp(exponent))
    total = sum(reputations) + epsilon
    weights = [rep / total for rep in reputations]
    return reputations, weights


def aggregate_updates(updates: list[dict[str, torch.Tensor]], weights: list[float]) -> dict[str, torch.Tensor]:
    return weighted_average_updates(updates, weights)


def afedsv_weights(shapley_values: list[float], epsilon: float = 1.0e-12) -> list[float]:
    shifted = [max(0.0, value) for value in shapley_values]
    total = sum(shifted)
    if total <= epsilon:
        return fedavg_weights(len(shapley_values))
    return [value / (total + epsilon) for value in shifted]


def normalized_shapley_contributions(
    shapley_values: list[float],
    epsilon: float = 1.0e-12,
    transform: str = "shift_min",
) -> list[float]:
    if transform == "positive":
        values = [max(0.0, value) for value in shapley_values]
    elif transform == "shift_min":
        min_value = min(shapley_values) if shapley_values else 0.0
        values = [value - min_value for value in shapley_values]
    else:
        raise ValueError(f"Unsupported AFedSV current_value_transform: {transform}")
    total = sum(values)
    if total <= epsilon:
        return fedavg_weights(len(shapley_values))
    return [value / (total + epsilon) for value in values]


def afedsv_surrogate_weights(
    shapley_values: list[float],
    previous_surrogate: list[float] | None,
    config: dict,
) -> tuple[list[float], list[float]]:
    epsilon = float(config.get("epsilon", 1.0e-12))
    beta = float(config.get("beta", 0.9))
    nonnegative = bool(config.get("nonnegative", True))
    transform = str(config.get("current_value_transform", "positive" if nonnegative else "shift_min"))
    current = normalized_shapley_contributions(shapley_values, epsilon, transform)
    init_strategy = str(config.get("init_strategy", "uniform"))
    if previous_surrogate is None and init_strategy == "uniform":
        previous_surrogate = fedavg_weights(len(shapley_values))
    if previous_surrogate is None:
        surrogate = current
    else:
        surrogate = [
            beta * float(previous) + (1.0 - beta) * float(now)
            for previous, now in zip(previous_surrogate, current)
        ]
    total = sum(surrogate)
    if total <= epsilon:
        weights = fedavg_weights(len(shapley_values))
    else:
        weights = [value / (total + epsilon) for value in surrogate]
    return surrogate, weights


def _flatten_update(update: dict[str, torch.Tensor]) -> torch.Tensor:
    return torch.cat([value.detach().cpu().float().reshape(-1) for value in update.values() if torch.is_floating_point(value)])


def trimmed_mean_update(updates: list[dict[str, torch.Tensor]], trim_ratio: float) -> dict[str, torch.Tensor]:
    trim = int(len(updates) * trim_ratio)
    result: dict[str, torch.Tensor] = {}
    for key in updates[0]:
        values = [update[key].detach().cpu() for update in updates]
        if not torch.is_floating_point(values[0]):
            result[key] = values[0].clone()
            continue
        stacked = torch.stack([value.float() for value in values], dim=0)
        sorted_values, _ = torch.sort(stacked, dim=0)
        if trim > 0 and 2 * trim < len(updates):
            sorted_values = sorted_values[trim:-trim]
        result[key] = sorted_values.mean(dim=0)
    return result


def multikrum_update(updates: list[dict[str, torch.Tensor]], num_malicious: int, keep: int | None = None) -> tuple[dict[str, torch.Tensor], list[int]]:
    n = len(updates)
    if n < 3:
        return aggregate_updates(updates, fedavg_weights(n)), list(range(n))
    keep = keep or max(1, n - num_malicious - 2)
    keep = max(1, min(keep, n))
    vectors = [_flatten_update(update) for update in updates]
    scores = []
    neighbor_count = max(1, min(n - num_malicious - 2, n - 1))
    for idx, vector in enumerate(vectors):
        distances = []
        for other_idx, other in enumerate(vectors):
            if idx == other_idx:
                continue
            distances.append(float(torch.sum((vector - other) ** 2).item()))
        distances.sort()
        scores.append((sum(distances[:neighbor_count]), idx))
    selected = [idx for _, idx in sorted(scores)[:keep]]
    selected_updates = [updates[idx] for idx in selected]
    return aggregate_updates(selected_updates, fedavg_weights(len(selected_updates))), selected
