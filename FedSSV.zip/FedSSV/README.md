# FedSSV Reproduction

This repository is a PyTorch reproduction workspace for the paper **FedSSV: Client Contribution for Secure Federated Learning Aggregation Using Scaled Shapley Values**.

The current goal is reproducibility engineering: code paths, configs, run entrypoints, logging, and plotting scripts for the paper figures. Full paper-like training results are not claimed unless the corresponding configs have actually been run.

## Current Status

Core Reproduction is complete in a small Fashion-MNIST setting. Existing outputs show FedAvg/FedSSV, exact Shapley, scaled Shapley reputation, scaling/sign-flip attacks, logging, AIR, and figures working under smoke settings.

Fig. 3 smoke reproduction is complete for Fashion-MNIST with 5 clients, 30 rounds, one attack round, and limited validation batches. These smoke results are useful interface and mechanism checks, but they are not full paper-like results.

Full paper-like reproduction entrypoints are now present for Fig. 2 through Fig. 8 and optional Table IV. AFedSV, Gaussian/Gaussian-SFA, min-max, and Table V non-IID have been upgraded toward paper-aligned implementations. The full experiments still need to be run explicitly.

## Methods And Baselines

| Config method | Paper role | Notes |
| --- | --- | --- |
| `fedavg` | FedAvg baseline | Equal client weighting in the current implementation. |
| `fedssv` | Proposed FedSSV | Uses per-round Shapley values and scaled exponential reputation. |
| `afedsv` | AFedSV baseline | ShapleyFL-inspired historical surrogate FedSV weighting with configurable `afedsv.beta`; exact parity still needs cross-checking against the ShapleyFL code. |
| `trimmed_mean` | Robust aggregation baseline | Used for Fig. 7 style comparison. |
| `multi_krum` | Robust aggregation baseline | Used for Fig. 7 style comparison. |
| `fedssv` with `shapley.method: mc` | MC-FedSSV | Used for Fig. 8 scalability configs. |

## Core Reproduction

Dry-run only:

```powershell
python scripts/run_experiment.py --config configs/fmnist_core.yaml --dry-run
```

Run the core matrix:

```powershell
python scripts/run_experiment.py --config configs/fmnist_core.yaml
```

Legacy phase-one scripts remain in `scripts/run_phase1.py`, but the final entrypoint is `scripts/run_experiment.py`.

## Paper Figure Entrypoints

Use `--dry-run` first to inspect the matrix without training:

```powershell
python scripts/run_experiment.py --config configs/fig3_fmnist_scaling.yaml --dry-run
```

Run commands:

```powershell
python scripts/run_experiment.py --config configs/fig2_fmnist_iid.yaml
python scripts/run_experiment.py --config configs/fig2_fmnist_noniid.yaml
python scripts/run_experiment.py --config configs/fig2_cifar10_iid.yaml
python scripts/run_experiment.py --config configs/fig2_cifar10_noniid.yaml

python scripts/run_experiment.py --config configs/fig3_fmnist_scaling.yaml
python scripts/run_experiment.py --config configs/fig3_fmnist_signflip.yaml
python scripts/run_experiment.py --config configs/fig3_fmnist_gaussian.yaml
python scripts/run_experiment.py --config configs/fig3_fmnist_gaussiansfa.yaml

python scripts/run_experiment.py --config configs/fig4_scaling_strength.yaml
python scripts/run_experiment.py --config configs/fig4_gaussian_strength.yaml

python scripts/run_experiment.py --config configs/fig5_scaling_malicious_ratio.yaml
python scripts/run_experiment.py --config configs/fig5_gaussian_malicious_ratio.yaml

python scripts/run_experiment.py --config configs/fig6_minmax_fmnist_iid.yaml
python scripts/run_experiment.py --config configs/fig6_minmax_fmnist_noniid.yaml
python scripts/run_experiment.py --config configs/fig6_minmax_cifar10_iid.yaml
python scripts/run_experiment.py --config configs/fig6_minmax_cifar10_noniid.yaml

python scripts/run_experiment.py --config configs/fig7_robust_baselines.yaml
python scripts/run_experiment.py --config configs/fig8_mc_fedssv_scalability.yaml
```

Optional Table IV entry:

```powershell
python scripts/run_experiment.py --config configs/table4_isic2019.yaml --dry-run
```

`table4_isic2019.yaml` is optional and requires external ISIC2019 files. The loader expects a metadata CSV and image directory; it does not download or fabricate data.

## Tiny Smoke Or Preflight

To validate a config with one round only:

```powershell
python scripts/run_experiment.py --config configs/fig3_fmnist_scaling.yaml --max-rounds-override 1 --only fedavg
```

Do not report this as a paper result. It only checks the interface.

## Plotting

Plotting assumes result CSV files already exist. Missing runs are skipped with a message; no synthetic results are created.

```powershell
python scripts/plot_results.py --figure fig2 --config configs/fig2_fmnist_iid.yaml --output outputs/figures/fig2_fmnist_iid.svg
python scripts/plot_results.py --figure fig3 --config configs/fig3_fmnist_scaling.yaml --output outputs/figures/fig3_fmnist_scaling.svg
python scripts/plot_results.py --figure fig4 --config configs/fig4_scaling_strength.yaml --sweep-key attacks.scaling_factor --output outputs/figures/fig4_scaling_strength.svg
python scripts/plot_results.py --figure fig4 --config configs/fig4_gaussian_strength.yaml --sweep-key attacks.noise_level --output outputs/figures/fig4_gaussian_strength.svg
python scripts/plot_results.py --figure fig5 --config configs/fig5_scaling_malicious_ratio.yaml --sweep-key malicious_ratio --output outputs/figures/fig5_scaling_malicious_ratio.svg
python scripts/plot_results.py --figure fig5 --config configs/fig5_gaussian_malicious_ratio.yaml --sweep-key malicious_ratio --output outputs/figures/fig5_gaussian_malicious_ratio.svg
python scripts/plot_results.py --figure fig6 --config configs/fig6_minmax_fmnist_iid.yaml --output outputs/figures/fig6_minmax_fmnist_iid.svg
python scripts/plot_results.py --figure fig7 --config configs/fig7_robust_baselines.yaml --output outputs/figures/fig7_robust_baselines.svg
python scripts/plot_results.py --figure fig8 --config configs/fig8_mc_fedssv_scalability.yaml --output outputs/figures/fig8
python scripts/plot_results.py --figure table4 --config configs/table4_isic2019.yaml --output outputs/figures/table4_isic2019.csv
```

## Paper Setting Mapping

Most paper-like configs use 10 clients, 100 rounds, local epochs 5, batch size 128, malicious ratio 0.2, and attack rounds `[30, 70]` unless the figure definition uses a single attack round for AIR sweeps. Fashion-MNIST and CIFAR-10 configs use learning rate 0.1. The optional ISIC2019 config uses learning rate 0.001.

FedSSV uses `negative_threshold: -0.01`, `scale_factor: 1000`, `reputation_transform: exp`, and `epsilon: 1.0e-12`. Do not change these to improve results; they are part of the reproduction target.

Exact Shapley is configured for N=10 paper-like runs. MC-Shapley is configured for Fig. 8 scalability. `shapley.max_batches` is always config-controlled and is `null` in paper-like configs.

## Output Files

Each completed run writes:

```text
outputs/runs/{run_name}/
  config.yaml
  metrics.csv
  shapley_values.csv
  client_weights.csv
  update_norms.csv
  runtime.csv
  summary.json
  client_label_distribution.json
  figures/
```

Runs may also write `table_v_check.json`, `attack_group_assignment.json`, `minmax_diagnostics.csv`, and `expanded_label_distribution.json` when the corresponding feature is active.

`summary.json` records run settings, malicious clients, AIR, runtime summary, Shapley method, utility metric, validation size, max batches, FedSSV/AFedSV parameters, Gaussian/Gaussian-SFA settings, min-max settings, Table V checks, and implementation assumptions.

## Implementation Assumptions

Gaussian attack: paper-like configs support `gaussian_mode: fixed_sigma` with `gaussian_sigma: 600` for Fig. 3 and `gaussian_mode: dynamic_model_std` with `noise_level` for Fig. 4/Fig. 5. The dynamic mode assumes sigma is `noise_level * std(model_parameters)` because the paper states the standard deviation is dynamically computed from the model parameter distribution but does not provide an implementation formula.

Gaussian-SFA: the implementation supports `composition_mode: split_groups`, where one malicious group performs Gaussian attack and another performs SFA/sign-flip. Paper-like Fig. 3 config uses `gaussian_fraction: 0.2`, `sfa_fraction: 0.2`, `overlap: false`, and `malicious_ratio: 0.4` to encode the paper text "Gaussian (20%, noise level 5) + SFA (20%)". The older sequential same-client composition is still available as an explicit non-paper assumption.

AFedSV: the default implementation now maintains historical surrogate contributions inspired by ShapleyFL/AFedSV Algorithm 1. It updates `surrogate_t = beta * surrogate_{t-1} + (1 - beta) * current_contribution_t`, initializes from uniform weights, applies configurable nonnegative handling, and normalizes surrogate values into aggregation weights. The exact current-round normalized partial FedSV formula should still be cross-checked with the ShapleyFL repository. The legacy simplified implementation is available only as `variant: afedsv_nonnegative_current_sv` / `legacy_positive_current`.

Min-max: paper-like configs now use a distance-constrained gamma-search attack following the optimized model poisoning / Min-Max formulation: malicious updates are constructed from the benign-update mean plus a searched perturbation while keeping the maximum distance to benign updates within the maximum benign-benign distance. Diagnostics are written to `minmax_diagnostics.csv`. The old negative scaling behavior is only available as `simple_negative_scaling` and should not be reported as paper-like min-max.

Non-IID split: `split: non-iid` / shard remains available only for general smoke checks. Paper-like non-IID configs now use `split: table_v_exact`, which implements the manually transcribed Table V distributions for FMNIST, CIFAR-10, and ISIC2019 and writes `table_v_check.json`. Fig.8 N=50/100 uses `table_v_repeat_distribution` with replacement, which is a scalability engineering assumption not directly specified by the paper Table V.

ISIC2019: Table IV support expects user-provided data under the paths in `configs/table4_isic2019.yaml`, including `metadata_csv`, `image_dir`, `image_column`, `label_column`, and binary label mapping. Missing files produce clear errors at dataset-load time; dry-run config validation does not require the dataset.

Dataset split sizes: current loader creates validation data by splitting the torchvision training split and can cap validation/test with `max_val_samples` and `max_test_samples`. This is auditable, but it is not yet a byte-for-byte reproduction of the paper's reported dataset preprocessing counts.

Shapley utility: current configs use `val_accuracy` by default and support `negative_val_loss`. The exact utility definition used by the paper should be kept auditable in config and summary.

Exponent clamp: FedSSV clamps exponent values to `[-50, 50]` for numerical stability. This is an implementation detail beyond the paper formula and is documented in run summaries.

Validation `max_batches`: smoke configs may cap Shapley utility evaluation for speed. Paper-like configs set `max_batches: null`.

## Config Audit

Inspect all official configs without training:

```powershell
python scripts/run_experiment.py --config configs/fig8_mc_fedssv_scalability.yaml --dry-run
```

For a complete audit table, use the config list in `configs/` together with `--dry-run`; no training starts in dry-run mode.

## Important Caveat

Smoke results are not full paper reproduction results. To reproduce the paper figures, run the corresponding configs, then generate plots from the completed outputs. The repository should not claim Fig. 2-Fig. 8 or Table IV results until those runs exist under `outputs/runs/`.
