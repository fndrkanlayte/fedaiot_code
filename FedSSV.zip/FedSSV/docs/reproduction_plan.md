# FedSSV 两阶段复现计划

论文：FedSSV: Client Contribution for Secure Federated Learning Aggregation Using Scaled Shapley Values

目标：先复现 FedSSV 的最小核心流程，再逐步复现论文主要实验图。开发阶段可以继续使用 `phase1` / `phase2` 命名以便快速推进，但最终交付前需要重命名为更清晰的 Core Reproduction 与 Figure Reproduction。

本计划暂不写代码，只作为后续开发任务列表。

---

## 总体原则

- 使用 PyTorch。
- 第一阶段固定使用 Fashion-MNIST。
- 第一阶段只做最小但完整的 FL 闭环，不一开始引入 CIFAR-10、ISIC2019、MC-FedSSV 或复杂调度框架。
- 所有攻击轮统一使用列表字段 `attack_rounds`，例如 `[10]` 或 `[30, 70]`。
- Shapley utility 必须做成可配置项，第一阶段默认使用 `val_accuracy`，但保留切换到 `negative_val_loss` 的能力。
- FedSSV 的阈值、缩放因子、reputation 变换和数值稳定参数都必须来自 config，不在代码中硬编码。
- 所有实验必须通过 `run_name` 区分输出目录。
- 先做 smoke reproduction，趋势正确后再做 paper-like reproduction。

---

## 推荐项目结构

```text
FedSSV/
  docs/
    FedSSV_...pdf
    reproduction_plan.md

  configs/
    phase1_fmnist.yaml          # 开发期名称，交付前改为 fmnist_core.yaml
    phase2_fmnist.yaml          # 开发期名称，交付前拆为 fmnist_fig3.yaml / fmnist_fig2.yaml
    phase2_cifar10.yaml

  fedssv/
    __init__.py
    datasets.py                 # 数据加载、train/val/test 切分、客户端划分
    models.py                   # 轻量 CNN
    client.py                   # 本地训练
    server.py                   # 联邦训练主循环
    attacks.py                  # scaling/sign-flip/gaussian/gaussian-sfa/min-max
    aggregators.py              # FedAvg/FedSSV/AFedSV/TrimmedMean/MultiKrum
    shapley.py                  # exact Shapley 与 MC-Shapley
    metrics.py                  # accuracy/loss/AIR/utility
    utils.py                    # seed/device/state_dict/update 工具

  scripts/
    run_phase1.py               # 开发期名称，交付前改为 run_core.py
    run_experiment.py
    plot_results.py

  outputs/
    runs/
      {run_name}/
        config.yaml
        metrics.csv
        shapley_values.csv
        client_weights.csv
        update_norms.csv
        summary.json
        figures/

  tests/
    test_aggregators.py
    test_attacks.py
    test_shapley.py

  README.md
  requirements.txt
```

---

# 阶段一：FedSSV 核心流程复现

阶段一目标：构建一个最小但完整的联邦学习框架，实现 FedAvg、恶意客户端攻击、exact Shapley、scaled Shapley 和 FedSSV 聚合，并在 Fashion-MNIST 上验证 FedSSV 在攻击下优于 FedAvg。

## 阶段一统一默认配置

阶段一所有任务统一使用以下配置，避免参数混用：

```yaml
run_name: phase1_fmnist_core
dataset: Fashion-MNIST
num_clients: 5
rounds: 20
attack_rounds: [10]
local_epochs: 1
batch_size: 128
malicious_ratio: 0.2
seed: 42

shapley:
  method: exact
  utility_metric: val_accuracy        # 可选：val_accuracy, negative_val_loss

fedssv:
  negative_threshold: -0.01
  scale_factor: 1000                  # 即论文中的 K
  reputation_transform: exp           # 第一版只需要 exp，但保留配置入口
  epsilon: 1.0e-12                    # 数值稳定用

attacks:
  enabled: false
  type: none
  scaling_factor: 100
```

完成阶段一前，不再使用 `rounds=5-10`、`attack_round=5`、`attack_round=10` 这种混合写法；统一为 `rounds=20` 和 `attack_rounds: [10]`。

---

## 1. 环境与配置读取

任务：

- 建立最小配置读取机制。
- 支持 `run_name`。
- 每次实验创建输出目录：`outputs/runs/{run_name}/`。
- 把实际运行配置完整保存为 `config.yaml`。

预期输出：

- `outputs/runs/{run_name}/config.yaml`
- 控制台打印 dataset、device、seed、num_clients、rounds、attack_rounds。

完成标准：

- 单次运行能创建独立输出目录。
- 同一个 `run_name` 的输出不会与其他实验混淆。
- config 中包含 Shapley、FedSSV、attack 参数。

调试检查点：

- 检查是否所有攻击轮都来自 `attack_rounds` 列表。
- 检查 FedSSV 参数是否从 config 读取，而不是写死在代码中。

---

## 2. 数据加载与 IID 客户端划分

任务：

- 加载 Fashion-MNIST。
- 划分 train/validation/test。
- validation set 用于 Shapley utility。
- test set 只用于最终 global model evaluation。
- 实现 IID client split。
- 输出每个 client 的 label histogram。

预期输出：

- `summary.json` 中包含数据集大小、client 样本数、label 分布。
- 控制台打印每个客户端样本数。

完成标准：

- `num_clients=5`。
- 每个客户端样本数接近一致。
- 每个客户端基本覆盖 10 类。
- train/val/test 无重叠。

调试检查点：

- validation/test 不能被分配给 client 训练。
- label 范围必须是 `0-9`。

---

## 3. 轻量 CNN 与集中式训练 sanity check

任务：

- 实现轻量 CNN：
  - 两个 Conv block；
  - BatchNorm；
  - ReLU；
  - MaxPool；
  - 一个全连接层；
  - 输出 10 类 logits。
- 先做 centralized sanity check，确认模型和数据正常。

预期输出：

- centralized train loss。
- centralized test accuracy。

完成标准：

- Fashion-MNIST accuracy 明显高于随机猜测。
- 几轮训练后 accuracy 至少超过 `70%`。
- loss 有下降趋势。

调试检查点：

- 如果 accuracy 长期约 `10%`，检查 label、loss、输出维度。
- 使用 `CrossEntropyLoss` 时模型最后不手动 `log_softmax`。

---

## 4. FedAvg 最小闭环

任务：

- 实现联邦训练流程：
  1. server 初始化 global model；
  2. 每轮广播 global weights；
  3. client 从 global weights 开始本地训练；
  4. client 上传 `update = local_weights - global_weights`；
  5. server 用 FedAvg 聚合；
  6. 在 test set 上评估 global model。
- 阶段一 FedAvg 可先使用等权平均。

预期输出：

- `metrics.csv`
- 每轮包含 round、aggregator、test_loss、test_accuracy。

完成标准：

- 无攻击时 FedAvg 能收敛。
- `rounds=20` 后 Fashion-MNIST accuracy 明显提升。
- global model 参数每轮确实变化。

调试检查点：

- client update norm 必须非零。
- 聚合权重之和必须为 1。
- 每个 client 每轮必须从同一个 global model 开始训练。

---

## 5. 攻击模块：scaling 与 sign-flip

任务：

- 使用 `attack_rounds` 控制攻击轮。
- 支持 malicious client selection：
  - `malicious_ratio=0.2`
  - `num_clients=5`
  - 即 1 个恶意客户端。
- 先实现：
  - scaling attack：`update *= scaling_factor`
  - sign-flip attack：`update *= -1`

预期输出：

- `update_norms.csv`
- 每轮每个 client 的 update norm。
- 攻击轮记录 attack type、malicious client id、attack parameters。

完成标准：

- 攻击只在 `attack_rounds: [10]` 生效。
- FedAvg 在 scaling 或 sign-flip 攻击轮出现可观察 accuracy drop。
- malicious update norm 在 scaling attack 下明显增大。

调试检查点：

- 攻击发生在本地训练之后、server 聚合之前。
- 不直接修改 global model。
- 所有攻击逻辑都支持多个 attack rounds。

---

## 6. Shapley utility 可配置化

任务：

- exact Shapley 不把 utility 写死为 validation accuracy。
- 在 config 中支持：
  - `utility_metric: val_accuracy`
  - `utility_metric: negative_val_loss`
- 阶段一默认使用 `val_accuracy`。
- utility 计算统一封装为函数，例如：
  - 输入：global model、coalition updates、validation loader、utility_metric；
  - 输出：一个 scalar utility。

预期输出：

- `shapley_values.csv`
- debug 模式下可选保存 coalition utility。
- `summary.json` 记录本次使用的 utility metric。

完成标准：

- `utility_metric=val_accuracy` 可以正常运行。
- `utility_metric=negative_val_loss` 至少能通过 smoke test。
- test set 不参与 Shapley utility 计算。

调试检查点：

- empty coalition 的 utility 是当前 global model 在 validation set 上的 utility。
- 子集模型评估时不能修改真实 global model。
- 如果 Shapley 全接近 0，检查 validation set 是否太小或 update 是否太弱。

---

## 7. exact Shapley value 贡献评估

任务：

- 对每轮 client updates 计算 exact Shapley。
- 对每个 client `i`，枚举所有不包含 `i` 的子集 `S`。
- 边际贡献为 `U(S union {i}) - U(S)`。
- 第一阶段使用 `num_clients=5`，exact Shapley 每轮 coalition 数量可控。

预期输出：

- `shapley_values.csv`
- 每行至少包含：round、client_id、is_malicious、shapley_value、utility_metric。

完成标准：

- Shapley values 不是全零。
- 无攻击场景下各客户端 Shapley 不应极端失衡。
- 攻击轮恶意客户端的 Shapley 通常更低，理想情况下为负。

调试检查点：

- coalition update 的聚合方式要明确：阶段一可用等权平均。
- Shapley 评估中的 coalition model 不得污染真实训练状态。

---

## 8. FedSSV 参数配置化与聚合

任务：

- FedSSV 所有关键参数从 config 读取：
  - `negative_threshold`
  - `scale_factor`
  - `reputation_transform`
  - `epsilon`
- 按论文公式实现第一版：
  - 若 `SV_i < negative_threshold`，`Rep_i = exp(SV_i * scale_factor)`
  - 否则，`Rep_i = exp(SV_i)`
- 权重归一化：
  - `C_i = Rep_i / (sum(Rep_j) + epsilon)`
- 用 `C_i` 聚合 client updates。

预期输出：

- `client_weights.csv`
- 每行至少包含：round、client_id、is_malicious、shapley_value、reputation、weight。

完成标准：

- 所有 client weights 之和接近 1。
- 无 NaN/Inf。
- 攻击轮 malicious client 权重明显低于 benign clients。
- FedSSV 在攻击场景下 AIR 小于 FedAvg。

调试检查点：

- 打印 reputation min/max。
- 如果所有 reputation 下溢，需要通过 `epsilon` 或稳定 softmax 写法处理。
- 不允许把 `-0.01`、`1000`、`exp` 直接硬编码在聚合逻辑中。

---

## 9. 阶段一核心实验矩阵

统一配置：

```yaml
dataset: Fashion-MNIST
num_clients: 5
rounds: 20
attack_rounds: [10]
local_epochs: 1
malicious_ratio: 0.2
shapley.utility_metric: val_accuracy
fedssv.negative_threshold: -0.01
fedssv.scale_factor: 1000
fedssv.reputation_transform: exp
fedssv.epsilon: 1.0e-12
```

实验：

| 实验 | run_name | Attack | Aggregator | 完成标准 |
| --- | --- | --- | --- | --- |
| E1 | `phase1_fmnist_fedavg_no_attack` | none | FedAvg | 正常收敛 |
| E2 | `phase1_fmnist_fedssv_no_attack` | none | FedSSV | 不明显劣于 FedAvg |
| E3 | `phase1_fmnist_fedavg_scaling` | scaling | FedAvg | 攻击轮 accuracy 下降 |
| E4 | `phase1_fmnist_fedssv_scaling` | scaling | FedSSV | AIR 小于 FedAvg |
| E5 | `phase1_fmnist_fedavg_signflip` | sign-flip | FedAvg | 攻击轮 accuracy 下降 |
| E6 | `phase1_fmnist_fedssv_signflip` | sign-flip | FedSSV | AIR 小于 FedAvg |

每个 run 必须保存：

- `config.yaml`
- `metrics.csv`
- `shapley_values.csv`
- `client_weights.csv`
- `update_norms.csv`
- `figures/`
- `summary.json` 或该 run 的 `README.md`

阶段一验收标准：

- FedAvg 无攻击能正常收敛。
- FedSSV 无攻击不明显劣于 FedAvg。
- FedAvg 在攻击轮有明显下降。
- FedSSV 攻击轮 AIR 小于 FedAvg。
- FedSSV 的权重日志能解释恶意客户端被压低。

---

# 阶段二：论文主要实验图复现

阶段二目标：按照论文实验设置复现主要实验趋势。优先保证趋势与机制一致，再追求完整图表。

论文核心设置：

```yaml
num_clients: 10
rounds: 100
attack_rounds: [30, 70]
local_epochs: 5
batch_size: 128
malicious_ratio: 0.2
lr:
  fmnist: 0.1
  cifar10: 0.1
fedssv:
  negative_threshold: -0.01
  scale_factor: 1000
  reputation_transform: exp
  epsilon: 1.0e-12
```

---

## P0：Fig. 3 smoke reproduction

先做 Fig. 3 的 smoke 版本，避免直接跑 10 clients、100 rounds、local_epochs=5 导致调试周期太长。

配置：

```yaml
run_name: phase2_fmnist_fig3_smoke
dataset: Fashion-MNIST
num_clients: 5
rounds: 30
attack_rounds: [15]
local_epochs: 1
malicious_ratio: 0.2
shapley.utility_metric: val_accuracy
```

任务：

- 在 Fashion-MNIST 上比较：
  - FedAvg；
  - FedSSV；
  - AFedSV 可后置。
- 攻击类型：
  - scaling；
  - sign-flip；
  - Gaussian；
  - Gaussian-SFA。

预期输出：

- 每种攻击的 accuracy-vs-round 曲线。
- AIR 表格。
- Shapley 和 client weight 日志。

完成标准：

- 至少 scaling 和 sign-flip 下，FedSSV 比 FedAvg 更稳。
- 攻击轮 malicious client weight 下降。
- 所有输出按 `run_name` 分目录保存。

---

## P1：Fig. 3 paper-like reproduction

smoke reproduction 趋势正确后，再执行 paper-like 版本。

配置：

```yaml
run_name: phase2_fmnist_fig3_paper_like
dataset: Fashion-MNIST
num_clients: 10
rounds: 100
attack_rounds: [30, 70]
local_epochs: 5
batch_size: 128
malicious_ratio: 0.2
shapley.utility_metric: val_accuracy
fedssv.scale_factor: 1000
```

任务：

- 复现论文 Fig. 3 的 Fashion-MNIST 部分。
- 方法：
  - FedAvg；
  - AFedSV；
  - FedSSV。
- 攻击：
  - scaling factor 100；
  - Gaussian；
  - sign-flip；
  - Gaussian-SFA。

预期输出：

- Fig. 3 风格 accuracy-vs-round 曲线。
- AIR 表格。
- 每个 attack round 的 client weights。

完成标准：

- FedSSV 在攻击轮 accuracy drop 小于 FedAvg 和 AFedSV。
- FedSSV 曲线在攻击后恢复更快或更稳定。

风险点：

- exact Shapley 在 10 clients 下每轮需要较多 validation evaluation，需记录耗时。
- 若运行太慢，可先减少 validation size 做 debug，再恢复论文设置。

---

## P1：Fig. 2 无攻击收敛对比

任务：

- 复现无攻击场景：
  - FMNIST IID；
  - FMNIST non-IID；
  - CIFAR-10 IID；
  - CIFAR-10 non-IID。
- 方法：
  - FedAvg；
  - FedSSV；
  - AFedSV。
- `attack_rounds: []`。

预期输出：

- Fig. 2 风格 accuracy-vs-round 曲线。
- 无攻击时 FedSSV 与 FedAvg/AFedSV 收敛趋势接近。

完成标准：

- FMNIST IID 目标趋势接近 90%。
- FMNIST non-IID 低于 IID。
- CIFAR-10 不追求 SOTA，轻量 CNN 下约 60%-65% 属合理范围。

---

## P1：AFedSV baseline

任务：

- 实现 AFedSV 的历史累计/自适应 Shapley 权重机制。
- 在 no attack、scaling、Gaussian-SFA 下与 FedAvg、FedSSV 比较。

预期输出：

- 三种方法同图对比。
- `summary.json` 记录 AFedSV 的实现假设。

完成标准：

- AFedSV 无攻击能正常收敛。
- 攻击下 AFedSV 不稳定优于 FedSSV。

风险点：

- 论文对 AFedSV 细节可能不足，需要明确记录近似实现。

---

## P2：Fig. 4 攻击强度敏感性

任务：

- scaling factor：
  - `20, 40, 60, 80, 100`
- Gaussian noise level：
  - `3, 4, 5, 6, 7`
- `attack_rounds: [30]`
- malicious ratio: `0.2`
- 指标：AIR。
- 方法：
  - FedAvg；
  - AFedSV；
  - FedSSV。

预期输出：

- AIR vs scaling factor。
- AIR vs Gaussian noise level。

完成标准：

- FedAvg/AFedSV 的 AIR 随攻击强度增加。
- FedSSV 的 AIR 保持较低。

调试检查点：

- AIR 统一计算为 `acc_before_attack - acc_at_attack_round`。
- 若 round 从 0 开始，必须明确 `attack_rounds` 的语义。

---

## P2：Fig. 5 恶意客户端比例敏感性

任务：

- malicious ratio：
  - `0.1, 0.2, 0.3, 0.4, 0.5`
- 10 clients 下对应 1 到 5 个恶意客户端。
- 攻击：
  - scaling；
  - Gaussian。
- `attack_rounds: [30]`
- 指标：AIR。

预期输出：

- AIR vs malicious ratio 曲线。

完成标准：

- FedAvg 随恶意比例增加明显变差。
- FedSSV 曲线更平缓。

---

## P3：Fig. 6 min-max attack

任务：

- 实现 min-max attack。
- 数据集：
  - FMNIST；
  - CIFAR-10。
- 设置：
  - IID；
  - non-IID；
  - `attack_rounds: [30, 70]`；
  - malicious ratio: `0.2`。
- 方法：
  - FedAvg；
  - AFedSV；
  - FedSSV。

预期输出：

- IID/non-IID 下 min-max accuracy-vs-round 曲线。

完成标准：

- min-max 确实能让 FedAvg 下降。
- FedSSV 能降低攻击影响。

风险点：

- min-max 实现细节可能与论文不完全一致，必须在 `summary.json` 中记录实现版本。

---

## P3：Fig. 7 Trimmed Mean 与 Multi-Krum

任务：

- 实现 Trimmed Mean。
- 实现 Multi-Krum。
- 在 non-IID + min-max 下比较：
  - FedAvg；
  - AFedSV；
  - FedSSV；
  - Trimmed Mean；
  - Multi-Krum。

预期输出：

- Fig. 7 风格 accuracy 曲线。
- AIR 对比表。

完成标准：

- Trimmed Mean 和 Multi-Krum 能独立运行。
- 与 FedSSV 使用相同 client updates、malicious clients 和 `attack_rounds`。

---

## P4：Fig. 8 MC-FedSSV

任务：

- 实现 MC-Shapley：
  - 采样 `M` 个 permutation；
  - 每个 permutation 递增计算 coalition utility；
  - 对每个 client 平均 marginal contribution。
- 实验：
  - exact FedSSV, `N=10`；
  - MC-FedSSV, `N=10, 50, 100`；
  - `M=10`；
  - non-IID；
  - min-max；
  - `attack_rounds: [30, 70]`。

预期输出：

- MC-FedSSV accuracy-vs-round 曲线。
- exact vs MC 运行时间对比。
- 每轮 utility evaluation 次数。

完成标准：

- MC-FedSSV 比 exact Shapley 明显更快。
- N=50/100 能跑通。
- 近似后趋势不明显差于 exact FedSSV。

---

## P5：ISIC2019 与 Table IV

任务：

- 下载和预处理 ISIC2019。
- 转为 benign/malignant 二分类。
- resize 到 `32x32`。
- 构建 IID/non-IID split。
- 在 min-max attack 下比较：
  - FedAvg；
  - AFedSV；
  - FedSSV。

预期输出：

- Table IV 风格结果表。
- IID/non-IID attack round accuracy。

完成标准：

- 数据预处理可复现。
- 类别映射清楚。
- FedSSV 在 attack round 表现优于 baseline。

建议：

- ISIC2019 放最后做，不作为前期主线。

---

# 统一输出规范

每个实验必须使用唯一 `run_name`，并输出到：

```text
outputs/runs/{run_name}/
```

每个 run 至少保存：

```text
config.yaml
metrics.csv
shapley_values.csv
client_weights.csv
update_norms.csv
summary.json
figures/
```

字段要求：

- `metrics.csv`
  - round
  - aggregator
  - attack_type
  - test_loss
  - test_accuracy
  - val_loss
  - val_accuracy
  - air，可在 attack round 或后处理阶段生成
- `shapley_values.csv`
  - round
  - client_id
  - is_malicious
  - utility_metric
  - shapley_value
- `client_weights.csv`
  - round
  - client_id
  - is_malicious
  - shapley_value
  - reputation
  - weight
- `update_norms.csv`
  - round
  - client_id
  - is_malicious
  - attack_applied
  - update_norm_before_attack
  - update_norm_after_attack
- `summary.json`
  - run_name
  - seed
  - git commit，如可用
  - dataset
  - aggregator
  - attack settings
  - Shapley utility metric
  - FedSSV parameters
  - final accuracy
  - AIR summary
  - implementation assumptions

---

# 具体实现顺序

1. 初始化项目结构和依赖。
2. 实现配置读取和 `run_name` 输出目录。
3. 实现 Fashion-MNIST 数据加载。
4. 实现 IID client split。
5. 实现轻量 CNN。
6. 做 centralized sanity check。
7. 实现 FedAvg。
8. 跑 `phase1_fmnist_fedavg_no_attack`。
9. 实现 scaling attack，使用 `attack_rounds: [10]`。
10. 跑 `phase1_fmnist_fedavg_scaling`。
11. 实现可配置 Shapley utility。
12. 实现 exact Shapley。
13. 验证 `utility_metric=val_accuracy`。
14. smoke test `utility_metric=negative_val_loss`。
15. 实现 FedSSV 配置化参数与聚合。
16. 跑 `phase1_fmnist_fedssv_scaling`。
17. 加入 sign-flip attack。
18. 完成阶段一 6 个核心实验。
19. 生成阶段一 accuracy 曲线、AIR 表、client weight 曲线。
20. 执行 Fig. 3 smoke reproduction。
21. 加入 Gaussian 和 Gaussian-SFA。
22. 执行 Fig. 3 paper-like reproduction。
23. 加入 non-IID split。
24. 复现 Fig. 2。
25. 加入 CIFAR-10。
26. 补 AFedSV。
27. 复现 Fig. 4 和 Fig. 5。
28. 实现 min-max attack。
29. 复现 Fig. 6。
30. 实现 Trimmed Mean 和 Multi-Krum。
31. 复现 Fig. 7。
32. 实现 MC-FedSSV。
33. 复现 Fig. 8。
34. 最后考虑 ISIC2019/Table IV。
35. 执行交付前重命名与 README 整理。

---

# 关键风险点与调试检查点

## 1. Shapley 计算过慢

风险：

- exact Shapley 对 10 clients 每轮需要评估 1024 个 coalition。

检查点：

- 阶段一固定 5 clients。
- Fig. 3 先做 smoke reproduction。
- 保存每轮 Shapley 计算耗时。
- 后续用 MC-FedSSV 解决扩展性。

## 2. utility 选择影响 Shapley

风险：

- `val_accuracy` 和 `negative_val_loss` 可能得到不同排序。

检查点：

- 阶段一默认 `val_accuracy`。
- 代码结构保留 `negative_val_loss`。
- `summary.json` 必须记录本次 utility metric。

## 3. attack_rounds 语义不统一

风险：

- 如果部分代码使用 `attack_round`，后续多攻击轮会混乱。

检查点：

- 所有配置只使用 `attack_rounds`。
- 攻击判断统一写成 round 是否在 `attack_rounds` 中。

## 4. FedSSV 参数硬编码

风险：

- 阈值、K、epsilon 写死会影响后续敏感性实验。

检查点：

- `negative_threshold`、`scale_factor`、`reputation_transform`、`epsilon` 必须从 config 读取。
- `client_weights.csv` 中记录实际使用后的 reputation 和 weight。

## 5. 数值稳定性

风险：

- `exp(SV*K)` 可能下溢。

检查点：

- 检查 NaN/Inf。
- 打印 reputation min/max。
- 归一化使用 `epsilon`。

## 6. non-IID 误罚诚实客户端

风险：

- 诚实但数据偏斜的 client 可能 Shapley 偏低。

检查点：

- 保存 label distribution。
- 分析 Shapley 与 label distribution 的关系。
- 不要过早调大 `scale_factor`。

## 7. AFedSV 和 min-max 实现细节不唯一

风险：

- 论文描述可能不足以完全复现。

检查点：

- 在 `summary.json` 和 README 中记录实现假设。
- 不把近似实现结果表述成严格复现。

---

# 优先实现与后置内容

## 优先实现

- Fashion-MNIST。
- 配置读取。
- `run_name` 输出目录。
- IID split。
- 轻量 CNN。
- FedAvg。
- scaling attack。
- sign-flip attack。
- exact Shapley。
- configurable utility metric。
- configurable FedSSV parameters。
- FedSSV。
- CSV 日志和 figures。

## 第二批实现

- Gaussian attack。
- Gaussian-SFA。
- Fig. 3 smoke reproduction。
- Fig. 3 paper-like reproduction。
- non-IID split。
- Fig. 2。

## 第三批实现

- CIFAR-10。
- AFedSV。
- Fig. 4。
- Fig. 5。
- min-max attack。

## 最后实现

- Trimmed Mean。
- Multi-Krum。
- MC-FedSSV。
- N=50/100 扩展实验。
- ISIC2019。
- 多 seed 统计。

## 不建议一开始实现

- 分布式多进程。
- wandb/mlflow。
- 复杂 trainer 抽象。
- 复杂 checkpoint 系统。
- 一次性复现所有图。
- 一开始就上 CIFAR-10 或 ISIC2019。

---

# 交付前重命名步骤

开发阶段可以继续使用 `phase1` / `phase2`，但最终交付前需要做一次命名清理，避免 README 和命令显得像临时实验脚手架。

必须执行：

- `configs/phase1_fmnist.yaml` 重命名为 `configs/fmnist_core.yaml`。
- `configs/phase2_fmnist.yaml` 拆分或重命名为：
  - `configs/fmnist_fig3.yaml`
  - `configs/fmnist_fig2.yaml`
- `scripts/run_phase1.py` 重命名为 `scripts/run_core.py`。
- README 中减少 `phase1` / `phase2` 表述，改为：
  - Core Reproduction
  - Figure Reproduction
- README 中保留说明：
  - Core Reproduction 对应最小 FedSSV 主链路；
  - Figure Reproduction 对应论文图表复现；
  - 开发期旧名称如果仍出现在历史输出目录中，只作为 run_name 记录，不作为最终用户入口。

交付前最终 README 应优先展示：

```text
Core Reproduction:
  python scripts/run_core.py --config configs/fmnist_core.yaml

Figure Reproduction:
  python scripts/run_experiment.py --config configs/fmnist_fig3.yaml
  python scripts/run_experiment.py --config configs/fmnist_fig2.yaml
```

---

# 最终交付物

完成全部计划后，项目应包含：

- 可运行的 PyTorch FedSSV 复现代码。
- Core Reproduction：
  - Fashion-MNIST；
  - 5 clients；
  - 20 rounds；
  - FedAvg vs FedSSV；
  - scaling/sign-flip；
  - exact Shapley；
  - configurable utility；
  - configurable FedSSV parameters。
- Figure Reproduction：
  - Fig. 2；
  - Fig. 3 smoke；
  - Fig. 3 paper-like；
  - Fig. 4；
  - Fig. 5；
  - Fig. 6；
  - Fig. 7；
  - Fig. 8。
- 每个 run 的完整输出目录。
- README 中说明：
  - 如何运行 Core Reproduction；
  - 如何运行 Figure Reproduction；
  - 与论文设置的对应关系；
  - 与论文不完全一致的实现假设。

