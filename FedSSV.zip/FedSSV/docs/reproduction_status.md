# FedSSV 复现进度说明

更新日期：2026-05-20

本文档用于说明当前仓库已经复现到什么程度。重点区分三类内容：

- 已实现并实际跑通的实验；
- 已准备脚本但未完整跑完的实验；
- 尚未实现或尚未执行的后续计划。

本文档中的实验结果均来自当前 `outputs/runs/` 下的实际输出，不包含伪造或推测结果。


目前完成了 FedAvg 和 FedSSV 在 Fashion-MNIST 小规模实验，没有全量跑，租不到服务器
## 当前已实现能力

目前代码已经实现：

- Fashion-MNIST 数据加载；
- CIFAR-10 数据加载；
- train / validation / test 划分；
- IID client split；
- non-IID shard client split；
- 轻量 CNN；
- centralized sanity check；
- FedAvg；
- AFedSV；
- Trimmed Mean；
- Multi-Krum；
- exact Shapley；
- MC-Shapley；
- FedSSV；
- 可配置 Shapley utility：
  - `val_accuracy`
  - `negative_val_loss`
- 可配置 FedSSV 参数：
  - `negative_threshold`
  - `scale_factor`
  - `reputation_transform`
  - `epsilon`
- 攻击方法：
  - `scaling`
  - `sign-flip`
  - `gaussian`
  - `gaussian-sfa`
  - `min-max` 近似实现
- 结果日志：
  - `metrics.csv`
  - `shapley_values.csv`
  - `client_weights.csv`
  - `update_norms.csv`
  - `summary.json`
- accuracy 曲线和 client weight 曲线；
- AIR 统计逻辑：
  - 有攻击实验：`attack round 前一轮 accuracy - attack round accuracy`
  - 无攻击实验：AIR 记为 `NA`

## 主要运行入口

阶段一核心复现：

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'; python scripts/run_phase1.py --config configs/phase1_fmnist.yaml --experiment all
```

Fig. 3 smoke reproduction：

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'; python scripts/run_fig3_smoke.py --config configs/fig3_smoke_fmnist.yaml
$env:PYTHONDONTWRITEBYTECODE='1'; python scripts/finalize_fig3_smoke.py
```

Fig. 3 paper-like reproduction 入口已经准备好，但完整实验未跑完：

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'; python scripts/run_fig3_paper_like.py --config configs/fig3_paper_like_fmnist.yaml
$env:PYTHONDONTWRITEBYTECODE='1'; python scripts/finalize_fig3_paper_like.py
```

全量逻辑 smoke 测试：

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'; python scripts/run_full_logic_smoke.py --config configs/full_logic_smoke.yaml
```

## 已完成：阶段一核心复现

阶段一配置：

- Fashion-MNIST；
- 5 clients；
- 20 rounds；
- `attack_rounds: [10]`；
- `local_epochs: 1`；
- `malicious_ratio: 0.2`；
- exact Shapley；
- `shapley.utility_metric: val_accuracy`；
- scaling 复核版使用 `shapley.max_batches: 5`。

阶段一 AIR 结果：

| run | 聚合方法 | 攻击 | AIR |
| --- | --- | --- | --- |
| `phase1_fmnist_fedavg_no_attack` | FedAvg | none | NA |
| `phase1_fmnist_fedssv_no_attack` | FedSSV | none | NA |
| `phase1_fmnist_fedavg_scaling_mb5` | FedAvg | scaling | 0.7525 |
| `phase1_fmnist_fedssv_scaling_mb5` | FedSSV | scaling | 0.0435 |
| `phase1_fmnist_fedavg_signflip` | FedAvg | sign-flip | 0.0040 |
| `phase1_fmnist_fedssv_signflip` | FedSSV | sign-flip | 0.0015 |

主要输出：

- `outputs/runs/phase1_summary/air_table.csv`
- 每个 run 的完整输出位于：`outputs/runs/{run_name}/`

阶段一观察：

- FedAvg 在无攻击情况下可以正常收敛；
- scaling attack 会造成明显的 FedAvg accuracy drop；
- FedSSV 在 scaling attack round 会显著压低 malicious client weight；
- scaling 和 sign-flip 下，FedSSV 的 AIR 都小于 FedAvg；
- FedSSV 在非攻击轮也可能把某些 benign client 的 weight 压到接近 0。这个现象来自固定阈值和放大系数下的 Shapley 权重机制，目前作为复现观察记录，没有通过调参隐藏。

## 已完成：Fig. 3 smoke reproduction

Fig. 3 smoke 配置：

- Fashion-MNIST；
- 5 clients；
- 30 rounds；
- `attack_rounds: [15]`；
- `local_epochs: 1`；
- `malicious_ratio: 0.2`；
- exact Shapley；
- `shapley.utility_metric: val_accuracy`；
- `shapley.max_batches: 5`；
- FedSSV 参数：
  - `negative_threshold: -0.01`
  - `scale_factor: 1000`
  - `reputation_transform: exp`

对比方法：

- FedAvg；
- FedSSV。

攻击类型：

- scaling；
- sign-flip；
- gaussian；
- gaussian-sfa。

AIR 结果：

| 攻击 | FedAvg AIR | FedSSV AIR |
| --- | ---: | ---: |
| scaling | 0.7565 | -0.0030 |
| sign-flip | 0.0000 | -0.0030 |
| gaussian | 0.7565 | -0.0030 |
| gaussian-sfa | 0.7565 | -0.0030 |

主要输出：

- `outputs/runs/fig3_smoke_summary/air_table.csv`
- `outputs/runs/fig3_smoke_summary/malicious_attack_detail.csv`
- `outputs/runs/fig3_smoke_summary/benign_near_zero_stats.csv`
- `outputs/runs/fig3_smoke_summary/scaling_accuracy_comparison.svg`
- `outputs/runs/fig3_smoke_summary/sign_flip_accuracy_comparison.svg`
- `outputs/runs/fig3_smoke_summary/gaussian_accuracy_comparison.svg`
- `outputs/runs/fig3_smoke_summary/gaussian_sfa_accuracy_comparison.svg`
- 每个 run 下还有 `malicious_vs_benign_weight.csv`

Fig. 3 smoke 观察：

- scaling、gaussian、gaussian-sfa 在 smoke 设置下都会造成 FedAvg 明显掉点；
- FedSSV 在这些攻击下基本保持稳定；
- sign-flip 在当前 smoke 设置下没有造成明显 FedAvg accuracy drop，这一点如实记录，没有为了制造趋势而调参；
- FedSSV 仍然存在非攻击轮 benign client weight 接近 0 的情况，这延续了阶段一复核中观察到的 false-positive 风险。

## 已准备但未完成：Fig. 3 paper-like reproduction

paper-like 配置已经写好：

- Fashion-MNIST；
- 10 clients；
- 100 rounds；
- `attack_rounds: [30, 70]`；
- `local_epochs: 5`；
- `batch_size: 128`；
- `malicious_ratio: 0.2`；
- exact Shapley；
- full validation set；
- FedSSV 参数：
  - `negative_threshold: -0.01`
  - `scale_factor: 1000`
  - `reputation_transform: exp`

已准备脚本：

- `scripts/run_fig3_paper_like.py`
- `scripts/finalize_fig3_paper_like.py`

实际做过的 preflight：

| 环境 | run | rounds | device | 单轮耗时 | final accuracy |
| --- | --- | ---: | --- | ---: | ---: |
| CPU PyTorch | `fig3_paper_like_fmnist_fedavg_scaling_preflight` | 1 | cpu | 2089.8s | 0.8552 |
| CUDA PyTorch | `fig3_paper_like_fmnist_fedavg_scaling_gpu_preflight` | 1 | cuda | 1674.1s | 0.8550 |

完整 paper-like Fig. 3 未执行完成，原因是：

- 10 clients 下 exact Shapley 每轮需要 `2^10 = 1024` 次 coalition utility evaluation；
- 完整 Fig. 3 paper-like 需要 8 个 run；
- 每个 run 100 rounds；
- 总计 800 rounds；
- RTX 2060 GPU preflight 下单轮约 1674.1 秒；
- 粗略估算完整运行时间约 372 小时，即约 15.5 天，还不包含额外开销。

因此，当前仓库不声称已经完成 paper-like Fig. 3，只说明 paper-like 入口、配置和 preflight 已完成。

## 已完成：全量逻辑 smoke 测试

为了让仓库先具备“全量代码路径”，但不启动无法收尾的完整论文实验，新增了一个很小的 smoke matrix：

- `configs/full_logic_smoke.yaml`
- `scripts/run_full_logic_smoke.py`

该 smoke 只验证新增逻辑能跑通，不用于论文结论。

已跑通的 smoke 场景：

| run | 数据集 | split | 聚合方法 | 攻击 | final accuracy |
| --- | --- | --- | --- | --- | ---: |
| `full_logic_smoke_fmnist_noniid_afedsv_scaling` | Fashion-MNIST | non-IID | AFedSV | scaling | 0.1094 |
| `full_logic_smoke_fmnist_iid_trimmed_minmax` | Fashion-MNIST | IID | Trimmed Mean | min-max | 0.4531 |
| `full_logic_smoke_fmnist_iid_multikrum_gaussian` | Fashion-MNIST | IID | Multi-Krum | gaussian | 0.4336 |
| `full_logic_smoke_cifar10_iid_fedssv_gaussiansfa` | CIFAR-10 | IID | FedSSV | gaussian-sfa | 0.1800 |

这些结果只说明：

- CIFAR-10 数据加载路径可用；
- non-IID shard split 可用；
- AFedSV 聚合路径可用；
- Trimmed Mean 聚合路径可用；
- Multi-Krum 聚合路径可用；
- MC-Shapley 路径可用；
- min-max、gaussian、gaussian-sfa 攻击路径可用；
- 所有新增逻辑至少能完成短 FL 闭环并输出标准 CSV/summary。

这些 smoke run 的轮数和样本数很小，因此不能用于声称论文图表趋势。

## 当前环境

本机有 NVIDIA GeForce RTX 2060。PyTorch 已经从 CPU-only wheel 替换为 CUDA 版本：

```text
torch 2.5.1+cu121
torchvision 0.20.1+cu121
cuda_available True
device_name NVIDIA GeForce RTX 2060
```

安装 CUDA 版 PyTorch 时 pip 提示过一个依赖冲突：

```text
datasets 4.8.4 requires fsspec[http]<=2026.2.0,>=2023.1.0, but installed fsspec 2026.4.0
```

当前 FedSSV 复现代码不依赖 HuggingFace `datasets`，所以这个 warning 没有影响已完成实验。

## 尚未完整执行

以下内容已有部分代码入口，但还没有按论文完整设置执行：

- Fig. 4 攻击强度敏感性；
- Fig. 5 恶意客户端比例敏感性；
- CIFAR-10 完整复现；
- non-IID 完整复现；
- min-max 完整攻击实验；
- Trimmed Mean 完整对比；
- Multi-Krum 完整对比；
- MC-FedSSV 完整实验；
- ISIC2019。

## 推荐下一步

如果目标是继续推进论文复现，同时保持实验诚实，建议下一步优先实现 MC-Shapley 或者更系统地记录 utility evaluation 耗时，用近似 Shapley 支撑大规模实验。

如果必须坚持 `10 clients + full validation + exact Shapley + 100 rounds x 8 runs`，当前 RTX 2060 环境运行完整 Fig. 3 paper-like reproduction 的成本过高，不适合作为常规实验流程。
