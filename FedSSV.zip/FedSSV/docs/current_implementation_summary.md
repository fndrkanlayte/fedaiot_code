# FedSSV 当前代码实现清单与不足总结

## 1. 总体状态

当前仓库已经完成 **FedSSV 主方法、主要 baseline、主要攻击、数据划分、Fig.2-Fig.8 config/运行入口/绘图入口/审计输出** 的代码层面复现准备。FedSSV 的 exact Shapley、validation accuracy utility、scaled reputation/weight 公式基本对齐论文。

但当前还没有完成完整论文实验运行。已有真实结果主要是 phase1 core、Fig.3 smoke 和 1-round preflight，不能表述为 full reproduction。当前主要不足不是大块代码缺失，而是若干 baseline/attack 的实现仍带有 implementation assumptions，且正式实验尚未运行。

## 2. 已实现的 baseline / method 清单

| Method / Baseline | 是否实现 | 实现位置 | 是否 paper-like 默认 | 是否已轻量验证 | 是否已有真实实验结果 | 适用论文图 | 当前不足 / assumption |
| --- | --- | --- | --- | --- | --- | --- | --- |
| FedAvg | 是 | `fedssv/aggregators.py`, `server.py` | 是 | 是 | 是，phase1/Fig.3 smoke/preflight | Fig.2-Fig.7 | 当前为等权平均，不是样本数加权 FedAvg |
| FedSSV | 是 | `fedssv/aggregators.py`, `shapley.py`, `server.py` | 是 | 是 | 是，phase1/Fig.3 smoke | Fig.2-Fig.8 | Shapley utility、reputation、weight 基本对齐；exponent clamp 是数值稳定细节 |
| AFedSV | 是 | `fedssv/aggregators.py`, `server.py` | 是，historical surrogate | 是 | 只有 tiny smoke/入口级 | Fig.2-Fig.7 | 已升级为 historical surrogate FedSV；current partial FedSV 细节仍需和 ShapleyFL 官方代码逐行核对 |
| AFedSV simple legacy | 是 | `afedsv_weights()` | 否 | 是 | 有旧 smoke 路径 | 不作为论文 baseline | 仅保留 debug/legacy，不能称 paper-like |
| Trimmed Mean | 是 | `fedssv/aggregators.py` | Fig.7 baseline | 入口级 | 只有 tiny smoke | Fig.7 | 尚未运行 Fig.7 paper-like |
| Multi-Krum | 是 | `fedssv/aggregators.py` | Fig.7 baseline | 入口级 | 只有 tiny smoke | Fig.7 | 尚未运行 Fig.7 paper-like |
| MC-FedSSV | 是 | `fedssv/shapley.py`, `fig8` config | 是，Fig.8 | 是 | 只有入口/轻量验证 | Fig.8 | N=50/100 non-IID 扩展使用 repeat assumption |

## 3. 已实现的 attack 清单

| Attack | 是否实现 | 实现位置 | paper-like config | 是否已轻量验证 | 是否已有真实实验结果 | 适用论文图 | 当前不足 / assumption |
| --- | --- | --- | --- | --- | --- | --- | --- |
| scaling | 是 | `fedssv/attacks.py` | factor=100 | 是 | 是，phase1/Fig.3 smoke | Fig.3-Fig.5 | 基本对齐 |
| sign-flip / SFA | 是 | `fedssv/attacks.py` | update 乘以 -1 | 是 | 是，phase1/Fig.3 smoke | Fig.3 | 当前 smoke 中攻击较弱 |
| Gaussian | 是 | `fedssv/attacks.py` | Fig.3 fixed_sigma=600；Fig.4/5 dynamic_model_std | 是 | 是，Fig.3 smoke 旧实现 | Fig.3-Fig.5 | dynamic std 使用 `noise_level * std(model_parameters)`，仍是 assumption |
| Gaussian-SFA | 是 | `fedssv/attacks.py` | split_groups，Gaussian 20% + SFA 20% | 是 | 是，Fig.3 smoke 旧实现 | Fig.3 | split_groups 根据论文文字实现，仍需原作者代码确认 |
| min-max | 是 | `fedssv/attacks.py` | gamma-search / distance-constraint | 是 | 只有 tiny smoke/旧路径 | Fig.6-Fig.8/Table IV | 已从负缩放升级；仍需和 optimized model poisoning 原实现对齐 |
| simple_negative_scaling | 是 | `fedssv/attacks.py` | 否 | 是 | 旧 smoke 近似路径 | debug only | 不应作为 paper-like min-max |

## 4. 已实现的数据集与数据划分

| Dataset / Split | 是否实现 | 实现位置 | 适用论文图 | 是否已验证 | 输出审计文件 | 当前不足 / assumption |
| --- | --- | --- | --- | --- | --- | --- |
| Fashion-MNIST IID | 是 | `fedssv/datasets.py` | Fig.2/Fig.3/Fig.4/Fig.5/Fig.6 | 是 | `client_label_distribution.json` | 基本可用 |
| Fashion-MNIST table_v_exact | 是 | `datasets.py` | Fig.2 non-IID, Fig.6, Fig.7 | fake histogram 验证 | `table_v_check.json` | 按用户提供 Table V 实现 |
| CIFAR-10 IID | 是 | `datasets.py` | Fig.2/Fig.6 | config 验证 | `client_label_distribution.json` | 未跑 full |
| CIFAR-10 table_v_exact | 是 | `datasets.py` | Fig.2 non-IID, Fig.6 | fake/config 验证 | `table_v_check.json` | 按用户提供 Table V 实现 |
| ISIC2019 loader | 是 | `datasets.py` | Table IV | missing-data error 验证 | `table_v_check.json` 若运行 | 需要用户准备 metadata/image_dir；列名和标签映射可能需按本地数据调整 |
| table_v_repeat_distribution | 是 | `datasets.py` | Fig.8 N=50/100 | dry-run 验证 | `expanded_label_distribution.json` | scalability engineering assumption |
| shard/general non-IID | 是 | `datasets.py` | smoke/general | 旧 smoke 跑过 | label hist | 不作为 paper-like non-IID |

## 5. 当前 paper-like configs 覆盖情况

| Config | 对应论文图 | Dataset | Split | Clients | Rounds | Attack | Methods | Shapley | Utility | Remaining assumption |
| --- | --- | --- | --- | ---: | ---: | --- | --- | --- | --- | --- |
| `fmnist_core.yaml` | Core | FMNIST | iid | 5 | 20 | none/scaling/sign-flip | FedAvg/FedSSV | exact | val_accuracy | smoke/core |
| `fig2_fmnist_iid.yaml` | Fig.2 | FMNIST | iid | 10 | 100 | none | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig2_fmnist_noniid.yaml` | Fig.2 | FMNIST | table_v_exact | 10 | 100 | none | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig2_cifar10_iid.yaml` | Fig.2 | CIFAR-10 | iid | 10 | 100 | none | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig2_cifar10_noniid.yaml` | Fig.2 | CIFAR-10 | table_v_exact | 10 | 100 | none | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig3_fmnist_scaling.yaml` | Fig.3 | FMNIST | iid | 10 | 100 | scaling | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig3_fmnist_signflip.yaml` | Fig.3 | FMNIST | iid | 10 | 100 | sign-flip | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig3_fmnist_gaussian.yaml` | Fig.3 | FMNIST | iid | 10 | 100 | Gaussian sigma=600 | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig3_fmnist_gaussiansfa.yaml` | Fig.3 | FMNIST | iid | 10 | 100 | Gaussian-SFA | FedAvg/AFedSV/FedSSV | exact | val_accuracy | split_groups assumption |
| `fig4_scaling_strength.yaml` | Fig.4 | FMNIST | iid | 10 | 100 | scaling sweep | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig4_gaussian_strength.yaml` | Fig.4 | FMNIST | iid | 10 | 100 | Gaussian noise sweep | FedAvg/AFedSV/FedSSV | exact | val_accuracy | dynamic std assumption |
| `fig5_scaling_malicious_ratio.yaml` | Fig.5 | FMNIST | iid | 10 | 100 | scaling ratio sweep | FedAvg/AFedSV/FedSSV | exact | val_accuracy | none |
| `fig5_gaussian_malicious_ratio.yaml` | Fig.5 | FMNIST | iid | 10 | 100 | Gaussian ratio sweep | FedAvg/AFedSV/FedSSV | exact | val_accuracy | dynamic std assumption |
| `fig6_minmax_fmnist_iid.yaml` | Fig.6 | FMNIST | iid | 10 | 100 | min-max | FedAvg/AFedSV/FedSSV | exact | val_accuracy | min-max parity |
| `fig6_minmax_fmnist_noniid.yaml` | Fig.6 | FMNIST | table_v_exact | 10 | 100 | min-max | FedAvg/AFedSV/FedSSV | exact | val_accuracy | min-max parity |
| `fig6_minmax_cifar10_iid.yaml` | Fig.6 | CIFAR-10 | iid | 10 | 100 | min-max | FedAvg/AFedSV/FedSSV | exact | val_accuracy | min-max parity |
| `fig6_minmax_cifar10_noniid.yaml` | Fig.6 | CIFAR-10 | table_v_exact | 10 | 100 | min-max | FedAvg/AFedSV/FedSSV | exact | val_accuracy | min-max parity |
| `fig7_robust_baselines.yaml` | Fig.7 | FMNIST | table_v_exact | 10 | 100 | min-max | +Trimmed/MultiKrum | exact | val_accuracy | min-max parity |
| `fig8_mc_fedssv_scalability.yaml` | Fig.8 | FMNIST | exact/repeat | 10/50/100 | 100 | min-max | FedSSV | MC | val_accuracy | repeat distribution |
| `table4_isic2019.yaml` | Table IV | ISIC2019 | table_v_exact | 10 | 100 | min-max | FedAvg/AFedSV/FedSSV | exact | val_accuracy | external data required |

## 6. 当前输出与审计文件

默认输出：
- `config.yaml`：保存实际运行配置。
- `metrics.csv`：round-level loss/accuracy/AIR。
- `shapley_values.csv`：每轮每 client 的 Shapley。
- `client_weights.csv`：reputation/aggregation weight。
- `update_norms.csv`：攻击前后 norm、actual attack type、Gaussian sigma、SFA 标记等。
- `runtime.csv`：训练、Shapley、聚合、评估耗时和 utility evaluation count。
- `summary.json`：总配置、攻击、AFedSV/FedSSV 参数、assumptions、AIR/runtime summary。
- `client_label_distribution.json`：每个 client 的 label histogram。
- `figures/`：基础 accuracy/weight 图。

条件输出：
- `table_v_check.json`：Table V expected vs actual，是否 passed。
- `attack_group_assignment.json`：Gaussian/Gaussian-SFA client 分组。
- `minmax_diagnostics.csv`：gamma、distance constraint、direction norm 等。
- `expanded_label_distribution.json`：Fig.8 N=50/100 repeat 映射与假设。

## 7. 已经通过的轻量验证

| 验证项 | 状态 |
| --- | --- |
| import check | 已通过 |
| config parsing | 已通过，所有正式 config 可展开 |
| dry-run | 已通过，含 Fig.3 Gaussian-SFA、Fig.8、Table IV |
| AFedSV fake shapley test | 已通过 |
| Gaussian fixed sigma test | 已通过 |
| Gaussian dynamic model std test | 已通过 |
| Gaussian-SFA group assignment test | 已通过 |
| min-max fake tensor test | 已通过 |
| Table V exact histogram check | 已通过，fake FMNIST |
| ISIC2019 missing-data error check | 已通过 |
| `plot_results.py` 缺结果 skip 检查 | 已通过 |

## 8. 已有真实实验结果与未运行实验

### 8.1 已有真实结果

| Run name | Dataset | Clients | Rounds | Method | Attack | Result summary | 是否论文级 |
| --- | --- | ---: | ---: | --- | --- | --- | --- |
| `phase1_fmnist_fedavg_no_attack` | FMNIST | 5 | 20 | FedAvg | none | final acc 0.8710 | 否 |
| `phase1_fmnist_fedssv_no_attack` | FMNIST | 5 | 20 | FedSSV | none | final acc 0.8725 | 否 |
| `phase1_fmnist_fedavg_scaling_mb5` | FMNIST | 5 | 20 | FedAvg | scaling | AIR 0.7525 | 否 |
| `phase1_fmnist_fedssv_scaling_mb5` | FMNIST | 5 | 20 | FedSSV | scaling | AIR 0.0435 | 否 |
| `phase1_fmnist_fedavg_signflip` | FMNIST | 5 | 20 | FedAvg | sign-flip | AIR 0.0040 | 否 |
| `phase1_fmnist_fedssv_signflip` | FMNIST | 5 | 20 | FedSSV | sign-flip | AIR 0.0015 | 否 |
| `fig3_smoke_fmnist_fedavg_*` | FMNIST | 5 | 30 | FedAvg | scaling/signflip/Gaussian/Gaussian-SFA | smoke AIR 表存在 | 否 |
| `fig3_smoke_fmnist_fedssv_*` | FMNIST | 5 | 30 | FedSSV | scaling/signflip/Gaussian/Gaussian-SFA | FedSSV smoke 稳定，恶意权重被压低 | 否 |
| `fig3_paper_like_fmnist_fedavg_scaling_preflight` | FMNIST | 10 | 1 | FedAvg | scaling | 1-round preflight | 否 |
| `fig3_paper_like_fmnist_fedavg_scaling_gpu_preflight` | FMNIST | 10 | 1 | FedAvg | scaling | 1-round GPU preflight | 否 |

### 8.2 尚未运行的正式实验

尚未运行：
- Fig.2 full；
- Fig.3 paper-like；
- Fig.4；
- Fig.5；
- Fig.6；
- Fig.7；
- Fig.8；
- Table IV / ISIC2019。

这些目前是 code/config/dry-run ready，不是已经完成论文结果复现。

## 9. 当前仍然存在的代码层面不足

| 优先级 | 不足 | 是否需继续改代码 | 说明 |
| --- | --- | --- | --- |
| 高 | AFedSV current partial FedSV 细节未逐行核对 | 可能需要 | historical surrogate 已实现，但 ShapleyFL 官方细节需核验 |
| 高 | min-max 与原 optimized model poisoning 实现未逐行对齐 | 可能需要 | gamma-search 已实现，但仍需 reference parity |
| 中 | Gaussian dynamic std 公式不完全确定 | 多半只需说明 | 当前为 `noise_level * std(model_parameters)` |
| 中 | Gaussian-SFA split_groups 需原作者代码确认 | 多半只需说明 | 已按论文文字实现 Gaussian 20% + SFA 20% |
| 中 | ISIC2019 metadata/label 命名依赖用户数据 | 可能需适配 | loader 已有入口，但真实数据格式可能不同 |
| 中 | Fig.8 repeat distribution 是工程假设 | 只需说明 | 论文 Table V 只给 10 clients |
| 低 | FedSSV exponent clamp | 只需说明 | 数值稳定细节，不来自论文公式 |

## 10. 目前可以怎么对外表述

当前项目已完成 FedSSV 主方法与主要实验入口的代码复现，Fig.2-Fig.8 的 configs、统一运行入口、绘图入口和审计输出已基本补齐；AFedSV、Gaussian/Gaussian-SFA、min-max、Table V non-IID、ISIC2019 loader 也已升级到更 paper-aligned 的实现。但完整论文实验结果尚未运行，部分 baseline/attack 仍带有明确标注的 implementation assumptions，不能将 smoke result 表述为 full reproduction。

## 11. 下一步建议

如果继续完善代码，优先：
- 核对 ShapleyFL 官方 AFedSV 实现；
- 核对 optimized model poisoning / min-max 官方或参考实现；
- 如有原作者代码，核对 Gaussian dynamic std 和 Gaussian-SFA 分组逻辑。

如果开始跑实验，建议：
1. 先跑 `configs/fmnist_core.yaml`，验证新输出字段和主链路。
2. 再跑 `fig3_fmnist_scaling.yaml` 的 FedAvg / FedSSV 子集。
3. 之后再补 AFedSV、Gaussian、Gaussian-SFA。
4. 暂时不要直接跑完整 Fig.4-Fig.8 sweep，也不要先跑 CIFAR-10 full 或 ISIC2019 full。

简短结论：**代码层面已经基本可以收口进入受控实验阶段，但 AFedSV/min-max/Gaussian 相关 assumption 仍建议在正式论文级声明前继续核对。**
